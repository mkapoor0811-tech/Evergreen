/** @type {import('tailwindcss').Config} */
module.exports = {
    darkMode: ["class"],
    content: ["./index.html", "./src/**/*.{ts,tsx,js,jsx}"],
  theme: {
  	extend: {
  		borderRadius: {
  			lg: 'var(--radius)',
  			md: 'calc(var(--radius) - 2px)',
  			sm: 'calc(var(--radius) - 4px)'
  		},
  		colors: {
  			// One colour per section of the app: its tiles, card headers, icons and
  			// main button. White text sits at 4.5:1 or better on each of these.
  			section: {
  				blue: '#2B5A8C',
  				blueDark: '#22496F',
  				plum: '#6B4A8A',
  				plumDark: '#573B70',
  				green: '#3F7A4E',
  				greenDark: '#326340',
  				amber: '#A8650A',
  				amberDark: '#8A5208',
  				navy: '#2E3A59',
  				navyDark: '#232D46',
  				teal: '#2F5F5B',
  				tealDark: '#264C49',
  				coral: '#AC5744',
  				coralDark: '#8E4838',
  				ochre: '#8A5E10',
  				ochreDark: '#6E4A0C'
  			},
  			earth: {
  				cream: '#FBF6EC',
  				paper: '#F4EBD9',
  				terracotta: '#C05B3F',
  				terracottaDark: '#A2462D',
  				lagoon: '#1F5E5B',
  				lagoonDark: '#154744',
  				marigold: '#D99A2B',
  				marigoldDark: '#A9761A',
  				plum: '#6E3B5C',
  				plumDark: '#57304A',
  				sage: '#7C8F6B',
  				sageDark: '#5D6E4E',
  				navy: '#2B3A55',
  				navyDark: '#1F2B40'
  			},
  			background: 'hsl(var(--background))',
  			foreground: 'hsl(var(--foreground))',
  			card: {
  				DEFAULT: 'hsl(var(--card))',
  				foreground: 'hsl(var(--card-foreground))'
  			},
  			popover: {
  				DEFAULT: 'hsl(var(--popover))',
  				foreground: 'hsl(var(--popover-foreground))'
  			},
  			primary: {
  				DEFAULT: 'hsl(var(--primary))',
  				foreground: 'hsl(var(--primary-foreground))'
  			},
  			secondary: {
  				DEFAULT: 'hsl(var(--secondary))',
  				foreground: 'hsl(var(--secondary-foreground))'
  			},
  			muted: {
  				DEFAULT: 'hsl(var(--muted))',
  				foreground: 'hsl(var(--muted-foreground))'
  			},
  			accent: {
  				DEFAULT: 'hsl(var(--accent))',
  				foreground: 'hsl(var(--accent-foreground))'
  			},
  			destructive: {
  				DEFAULT: 'hsl(var(--destructive))',
  				foreground: 'hsl(var(--destructive-foreground))'
  			},
  			border: 'hsl(var(--border))',
  			input: 'hsl(var(--input))',
  			ring: 'hsl(var(--ring))',
  			chart: {
  				'1': 'hsl(var(--chart-1))',
  				'2': 'hsl(var(--chart-2))',
  				'3': 'hsl(var(--chart-3))',
  				'4': 'hsl(var(--chart-4))',
  				'5': 'hsl(var(--chart-5))'
  			},
  			sidebar: {
  				DEFAULT: 'hsl(var(--sidebar-background))',
  				foreground: 'hsl(var(--sidebar-foreground))',
  				primary: 'hsl(var(--sidebar-primary))',
  				'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
  				accent: 'hsl(var(--sidebar-accent))',
  				'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
  				border: 'hsl(var(--sidebar-border))',
  				ring: 'hsl(var(--sidebar-ring))'
  			}
  		},
  		fontFamily: {
  			heading: ['var(--font-heading)'],
  			body: ['var(--font-body)'],
  			display: ['var(--font-display)'],
  			mono: ['var(--font-mono)']
  		},
  		// Small text is lifted to body size so nothing on screen reads as fine print.
  		fontSize: {
  			xs: ['0.9rem', { lineHeight: '1.4' }],
  			sm: ['1rem', { lineHeight: '1.45' }]
  		},
  		keyframes: {
  			'accordion-down': {
  				from: {
  					height: '0'
  				},
  				to: {
  					height: 'var(--radix-accordion-content-height)'
  				}
  			},
  			'accordion-up': {
  				from: {
  					height: 'var(--radix-accordion-content-height)'
  				},
  				to: {
  					height: '0'
  				}
  			}
  		},
  		animation: {
  			'accordion-down': 'accordion-down 0.2s ease-out',
  			'accordion-up': 'accordion-up 0.2s ease-out'
  		}
  	}
  },
  plugins: [require("tailwindcss-animate")],
}
