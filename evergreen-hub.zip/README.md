# Evergreen

A calm, high-contrast companion app for older adults. It keeps the day's medicines,
visits, meals and check-ins in one place, reminds people of what is next, and lets
family or a caregiver see that everything is on track.

Everything is designed for a person who may have low vision, shaky hands, or find
apps confusing: large text (never below 20px), tap targets of at least 56px,
plain-language headings, and a Read Aloud button on nearly every screen.

---

## Running it locally

```bash
npm install
npm run dev
```

Publish changes back to Base44 from the Builder, or with the Base44 CLI. A change
pushed to the repository is also reflected in the Base44 Builder.

---

## How the app is put together

| Where | What lives there |
| --- | --- |
| `src/App.jsx` | Every route. A page that has no route here is unreachable. |
| `src/pages/` | One file per screen. Each starts with a comment saying what it does. |
| `src/components/` | The pieces screens are built from. `src/components/ui/` is the shadcn library. |
| `src/lib/` | Settings, translations, dates, and the small helpers screens share. |
| `base44/entities/` | The database: one JSON schema per kind of record. |

### The shared building blocks

Every screen is meant to be assembled from these, rather than restyling from scratch:

- **`SectionCard`** – the one card style: dark teal header bar over a white body.
  Pass `collapsible` for a secondary section that folds away until tapped.
- **`AppCard`** – a link card that jumps to another screen.
- **`ActionButton`** – the one button: `primary` (teal), `secondary` (light gray),
  `danger` (rust red, Emergency only).
- **`PageHeader`** – the big screen title at the top of a page.
- **`ReadAloudButton`** / **`ScreenReadAloud`** – read a piece of text, or the whole
  screen, out loud using the browser's own voice.
- **`VoiceButton`** – let someone speak instead of typing.
- **`TimeField`** / **`TimeEditDialog`** – the large time picker.

### Where settings and wording live

- **`src/lib/appConfig.js`** – the app's name and tagline, the text sizes, the
  language list and the voice accents, and the keys used to remember settings on
  the device. Change the app's name or tagline here.
- **`src/index.css`** – the colour and text-size values, and the print of the
  background. Change a colour here.
- **`tailwind.config.js`** – maps those values to class names (`bg-earth-lagoon`).
- **`src/lib/translations/`** – all screen wording, one file per language
  (English, Spanish, Hindi, Chinese, Tagalog, Vietnamese). English also reads the
  app name and tagline from `appConfig.js`.

### Accessibility rules the code follows

- Body text is 20px at the smallest; the person can raise it in Settings.
- Nothing tappable is smaller than 56px.
- Simple mode replaces the bottom bar with four very large buttons.
- High contrast mode removes the decorative texture and tilts.
- Motion (fade-ins, floats, breathing circles) stops when the device asks for
  reduced motion.
- Every screen can be read out loud, and voice mode announces each screen as it opens.

---

## The screens

**Today**

| Route | Screen |
| --- | --- |
| `/` | Today – the day's schedule, what is next, and a one-tap mood check. |
| `/welcome` | The first screen shown on opening the app. |
| `/onboarding` | A few questions to set the app up for this person. |
| `/emergency` | The red emergency screen: call for help, and tell family. |

**Health** (tab: Health)

| Route | Screen |
| --- | --- |
| `/health` | Health hub – the way in to medicines, visits, food and exercise. |
| `/medications` | Today's pills, taken or skipped, with refill counts and how each one felt. |
| `/appointments` | Upcoming visits, and preparing for and writing up a visit. |
| `/appointments/calendar` | The month view of visits. |
| `/appointments/past` | Visits that have already happened, with their write-ups. |
| `/appointments/:id` | One visit in full: questions to ask, what to bring, the recap. |
| `/appointments/:id/prepare` | Getting ready for a visit. |
| `/appointments/:id/recap` | Writing up what the doctor said. |
| `/diet` | Today's meals, the weekly meal planner, food checks and portion guide. |
| `/exercise` | Gentle routines by ability, with a video or written steps. |
| `/groceries` | The shopping list, pantry basics and recipe ideas. |
| `/health-summary` | A one-page summary to show a doctor. |

**Safety** (tab: Safety)

| Route | Screen |
| --- | --- |
| `/safety` | Safety hub. |
| `/check-in` | The daily check-in, the streak, and asking for help. |
| `/scam-checker` | Check whether a message or call is a scam. |
| `/emergency-profile` | Allergies, doctors and emergency contacts, ready to show. |
| `/emergency-readiness` | What to do in a power cut or other emergency, with a checklist. |

**Learn** (tab: Learn)

| Route | Screen |
| --- | --- |
| `/learn` | Learn hub. |
| `/learn/topics` | Short, plain-language topics. |
| `/daily-boost` | A daily habit, word, quote, garden tip and reflection. |
| `/breathe` | Guided breathing. |
| `/garden` | A gentle daily garden tip. |
| `/tech-help` | Lessons for using a phone or computer. |
| `/tech-help/lesson/:lessonId` | One lesson. |
| `/tech-help/dictionary` | What a tech word means. |
| `/tech-help/practice` | Practice a skill. |
| `/term-explainer` | Explain a medical word in plain language. |

**Family** (tab: Family)

| Route | Screen |
| --- | --- |
| `/family` | The people who help: emergency and family contacts. |
| `/family-dashboard` | What family sees: check-ins, alerts, medicines, appetite, visits. |
| `/settings` | Text size, language, high contrast, simple mode, voice mode, day times. |
| `/about` | About the app. |

Signing in uses `/login`, `/register`, `/forgot-password` and `/reset-password`.

---

## How data is saved

Records are stored in the app's database, defined in `base44/entities/`. Each file
there is the schema for one kind of record, and also says who is allowed to read
and change it.

| Entity | Holds |
| --- | --- |
| `Medication` | A medicine: dose, time, instructions, pill count, and the days taken. |
| `DoseLog` | One dose taken or skipped, with how it felt and any symptoms. |
| `Appointment` | A visit: who, when, questions to ask, what to bring, and the recap. |
| `CareRoutine` | Check-ups that come round again (dentist, eye test) and when they are due. |
| `Grocery` | Shopping list items and whether they were bought. |
| `DietLog` | What was eaten today, and the day's mood. |
| `MealPlan` | The weekly meal planner: one row per day and meal slot. |
| `AppetiteLog` | Whether appetite was good, less than usual, or very little. |
| `Exercise` | A routine: ability level, minutes, and the days it was done. |
| `ExerciseVideo` | The video library shown on the exercise screen. |
| `CheckIn` | The daily check-in, and any request for help. |
| `EmergencyAlert` | An emergency raised from the red screen, and whether it was handled. |
| `CaregiverSetting` | The caregiver's email and phone, alert times, allergies, doctors and contacts. |
| `DailyFact` | The daily "did you know" facts. |
| `GardenDay` | Which garden tips were done, day by day. |
| `ReadinessCheck` | Ticks on the emergency readiness checklist. |
| `TechProgress` | Which tech lessons have been finished. |
| `User` | The signed-in person and their role (built in — not created by hand). |

A few things are deliberately kept on the device instead of the database, because
they are about this phone rather than this person: text size, language, high
contrast, simple mode, voice mode, the check-in deadline, and the meal / wake-up /
bedtime times. `src/lib/appConfig.js` lists the keys they are stored under.

Nothing is ever deleted without being asked for: Settings has a "Delete all my
data" button, and that is the only place data is cleared.