// Tech help: one lesson, which can be read out loud.
import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import ReadAloudButton from '@/components/ReadAloudButton';
import AskFamilyButton from '@/components/techhelp/AskFamilyButton';
import { TECH_LESSONS } from '@/lib/techHelpData';
import { ChevronLeft, ChevronRight, Check, Lightbulb } from 'lucide-react';
import { todayLocal } from '@/lib/localDate';

export default function TechHelpLesson() {
  const { t } = useAppSettings();
  const { lessonId } = useParams();
  const lesson = TECH_LESSONS.find((l) => l.id === lessonId);
  const [stepIndex, setStepIndex] = useState(0);
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    if (!lesson) return;
    base44.entities.TechProgress.filter({ lesson_id: lesson.id }, { limit: 1 })
      .then((page) => setCompleted(page.items.length > 0 && page.items[0].completed === true))
      .catch(() => {});
  }, [lesson]);

  if (!lesson) {
    return (
      <div>
        <PageHeader title={t('techHelp')} backTo="/tech-help" />
        <p className="text-lg text-foreground">{t('lessonNotFound')}</p>
      </div>
    );
  }

  const step = lesson.steps[stepIndex];
  const isLast = stepIndex === lesson.steps.length - 1;
  const isFirst = stepIndex === 0;

  const markComplete = async () => {
    setCompleted(true);
    const page = await base44.entities.TechProgress.filter({ lesson_id: lesson.id }, { limit: 1 });
    if (page.items.length > 0) {
      await base44.entities.TechProgress.update(page.items[0].id, { completed: true, completed_date: todayLocal() });
    } else {
      await base44.entities.TechProgress.create({ lesson_id: lesson.id, completed: true, completed_date: todayLocal() });
    }
  };

  return (
    <div>
      <PageHeader title={lesson.title} backTo="/tech-help" />

      <p className="text-lg text-muted-foreground mb-4">{lesson.intro}</p>

      <div className="mb-5 p-6 rounded-3xl bg-card border border-border">
        <p className="text-sm font-bold text-muted-foreground mb-3">
          {t('step')} {stepIndex + 1} / {lesson.steps.length}
        </p>
        <p className="text-2xl text-foreground leading-snug mb-4">{step.text}</p>
        {step.tip && (
          <div className="flex items-start gap-3 p-4 rounded-2xl bg-accent/10 border border-accent/30">
            <Lightbulb className="w-6 h-6 text-accent shrink-0 mt-0.5" strokeWidth={2} />
            <p className="text-foreground">{step.tip}</p>
          </div>
        )}
        <div className="mt-5">
          <ReadAloudButton text={step.text} />
        </div>
      </div>

      <div className="flex gap-3 mb-6">
        <button
          onClick={() => setStepIndex((i) => Math.max(0, i - 1))}
          disabled={isFirst}
          className="flex-1 flex items-center justify-center gap-2 bg-card border border-border text-foreground font-bold py-4 rounded-2xl min-h-[60px] disabled:opacity-40"
        >
          <ChevronLeft className="w-6 h-6" strokeWidth={2} />
          {t('previousStep')}
        </button>
        {isLast ? (
          <button
            onClick={markComplete}
            disabled={completed}
            className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground font-bold py-4 rounded-2xl min-h-[60px] disabled:opacity-60"
          >
            <Check className="w-6 h-6" strokeWidth={3} />
            {completed ? t('completed') : t('markComplete')}
          </button>
        ) : (
          <button
            onClick={() => setStepIndex((i) => Math.min(lesson.steps.length - 1, i + 1))}
            className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground font-bold py-4 rounded-2xl min-h-[60px]"
          >
            {t('nextStep')}
            <ChevronRight className="w-6 h-6" strokeWidth={2} />
          </button>
        )}
      </div>

      {!isLast && (
        <button
          onClick={markComplete}
          disabled={completed}
          className="w-full mb-6 flex items-center justify-center gap-2 bg-card border border-border text-foreground font-bold py-4 rounded-2xl min-h-[56px] disabled:opacity-60"
        >
          <Check className="w-5 h-5" strokeWidth={3} />
          {completed ? t('completed') : t('markComplete')}
        </button>
      )}

      <AskFamilyButton />
    </div>
  );
}