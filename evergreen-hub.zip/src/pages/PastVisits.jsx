// Past visits: visits that have already happened, with their write-ups.
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import VisitRow from '@/components/appointments/VisitRow';
import VisitNotes from '@/components/appointments/VisitNotes';
import { todayLocal } from '@/lib/localDate';

/** Past visits live here so they never clutter the main screen. */
export default function PastVisits() {
  const { t } = useAppSettings();
  const [appts, setAppts] = useState(null);

  useEffect(() => {
    base44.entities.Appointment
      .filter({ date: { $lt: todayLocal() } }, { sort: '-date', limit: 100 })
      .then(({ items }) => setAppts(items));
  }, []);

  return (
    <div>
      <PageHeader title={t('pastVisits')} />

      {appts === null ? (
        <p className="text-center text-muted-foreground py-8">{t('loading')}</p>
      ) : appts.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">{t('noPastVisits')}</p>
      ) : (
        <div className="space-y-4">
          {appts.map((appt) => (
            <VisitRow key={appt.id} appt={appt}>
              <VisitNotes appt={appt} />
            </VisitRow>
          ))}
        </div>
      )}
    </div>
  );
}