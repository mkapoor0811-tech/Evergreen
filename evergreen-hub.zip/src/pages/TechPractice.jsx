// Tech help: practise a skill step by step.
import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import PracticeCard from '@/components/techhelp/PracticeCard';
import { ChevronLeft, PhoneCall, Users, MessageSquare, Wifi, Camera } from 'lucide-react';

const ACTIVITIES = [
  { id: 'answer-call', title: 'Answer a phone call', prompt: 'Pretend your phone is ringing. Tap the green button to answer.', icon: PhoneCall },
  { id: 'call-contact', title: 'Call someone', prompt: 'Tap a name below to call them.', icon: Users },
  { id: 'send-text', title: 'Send a text message', prompt: 'Type a short message and tap Send.', icon: MessageSquare },
  { id: 'wifi', title: 'Turn on Wi-Fi', prompt: 'Tap the button to turn Wi-Fi on.', icon: Wifi },
  { id: 'photo', title: 'Take a photo', prompt: 'Tap the round button to take a pretend photo.', icon: Camera },
];

export default function TechPractice() {
  const { t } = useAppSettings();
  const [activeId, setActiveId] = useState(null);
  const active = ACTIVITIES.find((a) => a.id === activeId);

  return (
    <div>
      <PageHeader title={t('practiceMode')} backTo="/tech-help" />
      <p className="text-lg text-muted-foreground mb-6">{t('practiceModeDesc')}</p>

      {active ? (
        <div>
          <button
            onClick={() => setActiveId(null)}
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground font-bold mb-4"
          >
            <ChevronLeft className="w-5 h-5" strokeWidth={2} />
            {t('practiceMode')}
          </button>
          <div className="p-6 rounded-3xl bg-card border border-border">
            <h2 className="font-heading text-2xl text-foreground mb-4">{active.title}</h2>
            <PracticeCard activity={active} />
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {ACTIVITIES.map((a) => {
            const Icon = a.icon;
            return (
              <button
                key={a.id}
                onClick={() => setActiveId(a.id)}
                className="w-full flex items-center gap-4 rounded-2xl bg-card border border-border px-5 py-4 hover:border-primary/40 transition text-left"
              >
                <span className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="w-6 h-6 text-primary" strokeWidth={2} />
                </span>
                <span className="font-heading text-lg text-foreground">{a.title}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}