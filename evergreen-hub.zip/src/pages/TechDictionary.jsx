// Tech dictionary: what a tech word means, in plain language.
import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import ReadAloudButton from '@/components/ReadAloudButton';
import VoiceButton from '@/components/VoiceButton';
import { TECH_DICTIONARY } from '@/lib/techHelpData';
import { Search } from 'lucide-react';

export default function TechDictionary() {
  const { t } = useAppSettings();
  const [query, setQuery] = useState('');

  const q = query.trim().toLowerCase();
  const results = q
    ? TECH_DICTIONARY.filter((e) => e.term.toLowerCase().includes(q) || e.meaning.toLowerCase().includes(q))
    : TECH_DICTIONARY;

  return (
    <div>
      <PageHeader title={t('techDictionary')} backTo="/tech-help" />

      <div className="flex gap-2 mb-3">
        <div className="relative flex-1">
          <Search className="w-5 h-5 text-muted-foreground absolute left-4 top-1/2 -translate-y-1/2" strokeWidth={2} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('searchWords')}
            className="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-border focus:border-primary outline-none text-lg bg-card"
          />
        </div>
      </div>

      <div className="mb-6">
        <VoiceButton
          label={t('addByVoice')}
          prompt={t('searchWords')}
          onResult={(text) => setQuery(text)}
        />
      </div>

      {results.length === 0 ? (
        <p className="text-lg text-muted-foreground text-center py-8">{t('noWords')}</p>
      ) : (
        <div className="space-y-3">
          {results.map((entry) => (
            <div key={entry.term} className="p-5 rounded-2xl bg-card border border-border">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="font-heading text-xl text-foreground">{entry.term}</h2>
                  <p className="text-lg text-muted-foreground mt-1">{entry.meaning}</p>
                </div>
              </div>
              <div className="mt-3">
                <ReadAloudButton text={`${entry.term}. ${entry.meaning}`} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}