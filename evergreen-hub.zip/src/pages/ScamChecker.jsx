// Scam checker: paste a message and find out whether it looks like a scam.
import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import { ShieldAlert, ShieldCheck, AlertTriangle, Loader2 } from 'lucide-react';
import RiskGuide from '@/components/scam/RiskGuide';
import ReportToFamilyButton from '@/components/scam/ReportToFamilyButton';
import VoiceButton from '@/components/VoiceButton';

const LEVEL_STYLES = {
  high: { card: 'bg-earth-terracotta/10 border-earth-terracotta/50', badge: 'bg-earth-terracotta', text: 'text-earth-terracottaDark', labelKey: 'riskHigh', icon: AlertTriangle },
  medium: { card: 'bg-earth-marigold/15 border-earth-marigold/50', badge: 'bg-earth-marigold', text: 'text-earth-marigoldDark', labelKey: 'riskMedium', icon: ShieldAlert },
  low: { card: 'bg-earth-sage/15 border-earth-sage/50', badge: 'bg-earth-sage', text: 'text-earth-sageDark', labelKey: 'riskLow', icon: ShieldCheck },
};

export default function ScamChecker() {
  const { t, language } = useAppSettings();
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const check = async (override) => {
    const value = (typeof override === 'string' ? override : text).trim();
    if (!value) return;
    setLoading(true);
    setResult(null);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a scam and fraud detection assistant helping senior citizens. Analyze the following message or description of a call/text. Consider common scam patterns: phishing, fake prizes/lottery, IRS/tax scams, tech support scams, grandparent scams, romance scams, fake charity, investment scams, requests for gift cards or wire transfers, and pressure to act immediately.

Decide an overall risk level: "high" if it clearly matches a scam pattern, "medium" if it looks suspicious or has some warning signs, "low" if it looks like a normal message.

Give 2 to 4 short plain-language reasons for the rating, each one under 8 words, written the way a person would say it out loud — for example "asks for gift cards", "creates false urgency", "asks for your password", "unknown sender".

Respond in ${language === 'es' ? 'Spanish' : language === 'hi' ? 'Hindi' : language === 'zh' ? 'Chinese' : 'English'} using simple, plain language a senior citizen can understand.

Message to analyze:
"""
${value}
"""`,
        response_json_schema: {
          type: 'object',
          properties: {
            risk_level: { type: 'string', enum: ['low', 'medium', 'high'] },
            reasons: {
              type: 'array',
              items: { type: 'string' },
              description: 'Short plain-language reasons for the risk rating',
            },
            warning: { type: 'string', description: 'One or two plain sentences explaining the rating' },
            advice: { type: 'string', description: 'What the person should do next' },
          },
          required: ['risk_level', 'reasons'],
        },
      });
      setResult(res);
    } catch (e) {
      setResult({ error: true, risk_level: 'medium', reasons: [], warning: '', advice: '' });
    }
    setLoading(false);
  };

  const handleVoiceResult = (transcript) => {
    setText(transcript);
    check(transcript);
  };

  const style = result && !result.error ? (LEVEL_STYLES[result.risk_level] || LEVEL_STYLES.medium) : null;
  const RiskIcon = style ? style.icon : ShieldAlert;

  return (
    <div>
      <PageHeader title={t('scamChecker')} description={t('scamCheckerDesc')} />

      <div className="p-5 bg-earth-marigold/15 border-2 border-earth-marigold/40 rounded-3xl mb-5">
        <p className="text-foreground font-semibold">{t('pasteMessage')}</p>
      </div>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={5}
        className="w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-marigold outline-none text-lg resize-none"
        placeholder="Paste here..."
      />

      <div className="mt-4">
        <VoiceButton
          label={t('addByVoice')}
          prompt={t('scamSpeakPrompt')}
          onResult={handleVoiceResult}
        />
      </div>

      <button
        onClick={() => check()}
        disabled={loading || !text.trim()}
        className="w-full mt-4 flex items-center justify-center gap-2 bg-earth-navy hover:bg-earth-navyDark text-white font-bold py-4 rounded-2xl transition min-h-[56px] disabled:opacity-50"
      >
        {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <ShieldAlert className="w-6 h-6" strokeWidth={2.5} />}
        {loading ? t('analyzing') : t('checkIt')}
      </button>

      <p className="mt-3 p-4 rounded-2xl bg-earth-marigold/15 border-2 border-earth-marigold/40 text-foreground font-semibold">
        {t('scamDisclaimer')}
      </p>

      {result && result.error && (
        <div className="mt-5 p-6 rounded-3xl border-2 bg-secondary/60 border-border">
          <p className="text-foreground font-semibold">{t('scamError')}</p>
        </div>
      )}

      {result && !result.error && (
        <div className={`mt-5 p-6 rounded-3xl border-2 ${style.card}`}>
          <div className="flex items-center gap-4 mb-3">
            <div className={`w-14 h-14 blob ${style.badge} flex items-center justify-center shrink-0`}>
              <RiskIcon className="w-8 h-8 text-white" strokeWidth={2.5} />
            </div>
            <div>
              <p className="text-sm font-bold text-muted-foreground uppercase tracking-wide">{t('riskLevel')}</p>
              <h3 className={`font-heading text-2xl ${style.text}`}>{t(style.labelKey)}</h3>
            </div>
          </div>

          {result.reasons?.length > 0 && (
            <div className="mt-4">
              <p className="font-bold text-foreground mb-2">{t('whyThisRating')}</p>
              <ul className="flex flex-wrap gap-2">
                {result.reasons.map((reason, i) => (
                  <li key={i} className="rounded-full bg-card/80 border border-border px-4 py-1.5 font-semibold text-foreground">
                    {reason}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {result.warning && (
            <p className="mt-4 text-foreground">{result.warning}</p>
          )}

          {result.advice && (
            <div className="mt-4 p-4 bg-card/70 rounded-xl border border-border">
              <p className="font-bold text-foreground mb-1">{t('scamAdvice')}</p>
              <p className="text-foreground">{result.advice}</p>
            </div>
          )}

          <RiskGuide level={result.risk_level} />

          <ReportToFamilyButton message={text} level={result.risk_level} reasons={result.reasons} />
        </div>
      )}
    </div>
  );
}