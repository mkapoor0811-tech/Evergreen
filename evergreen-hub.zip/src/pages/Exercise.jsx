// Exercise: gentle routines by ability, played in the app or read as steps.
import React, { useState, useEffect } from 'react';
import ActionButton from '@/components/ActionButton';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import Illustration from '@/components/Illustration';
import { ILLUSTRATIONS } from '@/lib/illustrations';
import { Plus, Loader2, AlertTriangle } from 'lucide-react';
import VoiceButton from '@/components/VoiceButton';
import { parseExerciseAction } from '@/lib/voiceParse';
import ReadAloudButton from '@/components/ReadAloudButton';
import SeniorVideos from '@/components/SeniorVideos';
import ExerciseCard from '@/components/exercise/ExerciseCard';
import WeeklyGoalRing from '@/components/exercise/WeeklyGoalRing';
import GentleSuggestion from '@/components/exercise/GentleSuggestion';
import { daysUntil } from '@/lib/appointmentUtils';
import { todayLocal, localDate } from '@/lib/localDate';
import { youTubeId } from '@/lib/videoLink';

const todayStr = todayLocal;

const ABILITY_KEYS = ['seated', 'standing', 'balance', 'other'];
const DURATIONS = ['5', '10', '15'];

const ABILITY_BAND = {
  seated: 'bg-earth-terracotta',
  standing: 'bg-earth-lagoon',
  balance: 'bg-earth-plum',
  other: 'bg-earth-navy',
};

function weekStartStr() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - d.getDay());
  return localDate(d);
}

export default function Exercise() {
  const { t } = useAppSettings();
  const [exercises, setExercises] = useState(null);
  const [mood, setMood] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', youtube_url: '', ability: 'seated', duration_minutes: 10 });
  const [voiceProcessing, setVoiceProcessing] = useState(false);
  const [abilityFilter, setAbilityFilter] = useState('all');
  const [durationFilter, setDurationFilter] = useState('all');
  const [goal, setGoal] = useState(() => parseInt(localStorage.getItem('mahika_weeklyGoal') || '3', 10));

  const load = async () => {
    const data = await base44.entities.Exercise.list('-created_date', 100);
    setExercises(data);
  };

  useEffect(() => {
    load();
    base44.entities.DietLog.list('-date', 1)
      .then((items) => {
        const latest = items[0];
        if (latest && latest.mood && Math.abs(daysUntil(latest.date)) <= 1) setMood(latest.mood);
      })
      .catch(() => {});
  }, []);

  const updateGoal = (value) => {
    setGoal(value);
    localStorage.setItem('mahika_weeklyGoal', String(value));
  };

  const toggleDone = async (ex) => {
    const isDone = ex.done_today && ex.last_done_date === todayStr();
    const done_dates = Array.isArray(ex.done_dates) ? [...ex.done_dates] : [];
    if (!isDone) {
      if (!done_dates.includes(todayStr())) done_dates.push(todayStr());
    } else {
      const idx = done_dates.indexOf(todayStr());
      if (idx >= 0) done_dates.splice(idx, 1);
    }
    await base44.entities.Exercise.update(ex.id, {
      done_today: !isDone,
      last_done_date: !isDone ? todayStr() : ex.last_done_date,
      done_dates,
    });
    load();
  };

  const handleVoiceResult = async (transcript) => {
    if (!exercises || exercises.length === 0) return;
    setVoiceProcessing(true);
    try {
      const names = exercises.map((e) => e.name);
      const parsed = await parseExerciseAction(transcript, names);
      const target = exercises.find((e) => e.name.toLowerCase() === (parsed.exercise_name || '').toLowerCase()) || exercises[0];
      if (!target) return;
      if (parsed.action === 'complete') {
        const isDone = target.done_today && target.last_done_date === todayStr();
        if (!isDone) await toggleDone(target);
      } else if (parsed.action === 'note' && parsed.note) {
        const existingNote = target.notes || '';
        await base44.entities.Exercise.update(target.id, {
          notes: existingNote ? existingNote + ' | ' + parsed.note : parsed.note,
        });
        load();
      }
    } catch (e) { /* ignore */ }
    setVoiceProcessing(false);
  };

  const addExercise = async () => {
    if (!form.name.trim()) return;
    await base44.entities.Exercise.create({
      name: form.name.trim(),
      youtube_url: form.youtube_url.trim(),
      ability: form.ability,
      duration_minutes: Number(form.duration_minutes),
      done_today: false,
    });
    setForm({ name: '', youtube_url: '', ability: 'seated', duration_minutes: 10 });
    setShowForm(false);
    load();
  };

  const deleteExercise = async (id) => {
    if (!confirm(t('confirmDelete'))) return;
    await base44.entities.Exercise.delete(id);
    load();
  };

  const weekStart = weekStartStr();
  const weekDone = (exercises || []).reduce(
    (sum, ex) => sum + (Array.isArray(ex.done_dates) ? ex.done_dates.filter((d) => d >= weekStart).length : 0),
    0,
  );

  const today = todayStr();
  let lastRating = null;
  (exercises || []).forEach((ex) => {
    const found = (Array.isArray(ex.ratings) ? ex.ratings : []).find((r) => r.date === today);
    if (found) lastRating = found.rating;
  });

  const visible = (exercises || []).filter((ex) => {
    const ability = ex.ability || 'other';
    if (abilityFilter !== 'all' && ability !== abilityFilter) return false;
    if (durationFilter !== 'all' && Number(ex.duration_minutes) !== Number(durationFilter)) return false;
    return true;
  });

  const renderChips = (options, value, onChange) => (
    <div className="flex flex-wrap gap-2">
      {options.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`px-4 py-2 rounded-full font-bold transition ${
            value === opt.value ? 'bg-earth-navy text-white' : 'bg-secondary hover:bg-muted text-foreground'
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );

  return (
    <div>
      <PageHeader title={t('exercise')} description={t('exerciseDesc')} />

      <Illustration src={ILLUSTRATIONS.walking} alt={t('illWalkingAlt')} />
      {exercises && (
        <ReadAloudButton text={exercises.length === 0 ? t('noItems') : `${exercises.length} ${t('exercise')}. ` + exercises.map((e) => `${e.name}. ${e.done_today && e.last_done_date === todayStr() ? t('done') : t('markDone')}`).join('. ')} />
      )}

      <WeeklyGoalRing done={weekDone} goal={goal} onGoalChange={updateGoal} />

      <GentleSuggestion mood={mood} lastRating={lastRating} />

      <ActionButton onClick={() => setShowForm(!showForm)} className="w-full mb-5">
        <Plus className="w-6 h-6" strokeWidth={2.5} />
        {t('addExercise')}
      </ActionButton>

      <div className="mb-5">
        <VoiceButton
          label={t('addByVoice')}
          prompt={t('voiceExercisePrompt')}
          onResult={handleVoiceResult}
        />
      </div>
      {voiceProcessing && (
        <div className="mb-5 flex items-center justify-center gap-2 p-4 bg-earth-lagoon/10 rounded-2xl text-earth-lagoonDark font-bold">
          <Loader2 className="w-5 h-5 animate-spin" />
          {t('voiceProcessing')}
        </div>
      )}

      {showForm && (
        <div className="mb-5 p-5 bg-card rounded-3xl border border-border space-y-4">
          <div>
            <label className="block font-bold text-foreground mb-1">{t('exerciseName')}</label>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-terracotta outline-none text-lg"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-foreground mb-1">{t('ability')}</label>
              <select
                value={form.ability}
                onChange={(e) => setForm({ ...form, ability: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-terracotta outline-none text-lg"
              >
                <option value="seated">{t('seated')}</option>
                <option value="standing">{t('standing')}</option>
                <option value="balance">{t('balance')}</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-foreground mb-1">{t('duration')}</label>
              <select
                value={form.duration_minutes}
                onChange={(e) => setForm({ ...form, duration_minutes: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-terracotta outline-none text-lg"
              >
                {[5, 10, 15, 20, 30].map((min) => (
                  <option key={min} value={min}>{min} {t('minutesShort')}</option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className="block font-bold text-foreground mb-1">{t('youtubeLink')}</label>
            <input
              value={form.youtube_url}
              onChange={(e) => setForm({ ...form, youtube_url: e.target.value })}
              placeholder="https://youtube.com/watch?v=..."
              className="w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-terracotta outline-none text-lg"
            />
          </div>
          <button onClick={addExercise} className="w-full bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-4 rounded-xl transition min-h-[56px]">
            {t('save')}
          </button>
        </div>
      )}

      <div className="mb-5 flex items-start gap-3 p-4 rounded-2xl bg-earth-marigold/15 border-2 border-earth-marigold/50">
        <AlertTriangle className="w-7 h-7 text-earth-marigoldDark shrink-0 mt-0.5" strokeWidth={2.5} />
        <p className="text-lg font-semibold text-foreground leading-snug">{t('exerciseSafetyNote')}</p>
      </div>

      {exercises === null ? (
        <p className="text-center text-muted-foreground py-8">{t('loading')}</p>
      ) : exercises.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">{t('noItems')}</p>
      ) : (
        <>
          <div className="mb-5 space-y-3">
            <div>
              <p className="font-bold text-foreground mb-2">{t('ability')}</p>
              {renderChips(
                [{ value: 'all', label: t('allAbilities') }].concat(ABILITY_KEYS.map((key) => ({ value: key, label: t(key) }))),
                abilityFilter,
                setAbilityFilter,
              )}
            </div>
            <div>
              <p className="font-bold text-foreground mb-2">{t('duration')}</p>
              {renderChips(
                [{ value: 'all', label: t('allAbilities') }].concat(DURATIONS.map((min) => ({ value: min, label: `${min} ${t('minutesShort')}` }))),
                durationFilter,
                setDurationFilter,
              )}
            </div>
          </div>

          {visible.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">{t('noItems')}</p>
          ) : (
            ABILITY_KEYS.map((ability) => {
              const group = visible.filter((ex) => (ex.ability || 'other') === ability);
              if (group.length === 0) return null;
              return (
                <div key={ability} className="mb-8">
                  <div className="flex items-center gap-3 mb-3">
                    <span className={`w-2.5 h-8 rounded-full ${ABILITY_BAND[ability]}`} />
                    <h2 className="font-heading text-2xl text-foreground">{t(ability)}</h2>
                    <span className="text-muted-foreground font-semibold">{group.length}</span>
                  </div>
                  <div className="space-y-4">
                    {group.map((ex) => (
                      <ExerciseCard
                        key={ex.id}
                        exercise={ex}
                        isDone={ex.done_today && ex.last_done_date === todayStr()}
                        ytId={youTubeId(ex.youtube_url)}
                        onToggle={toggleDone}
                        onDelete={deleteExercise}
                        onChanged={load}
                      />
                    ))}
                  </div>
                </div>
              );
            })
          )}
        </>
      )}

      <SeniorVideos />
    </div>
  );
}