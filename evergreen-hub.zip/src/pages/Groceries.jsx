// Groceries: the shopping list, pantry basics, expiry reminders and recipe ideas.
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import { Plus, Check, Trash2, StickyNote } from 'lucide-react';
import VoiceButton from '@/components/VoiceButton';
import ReadAloudButton from '@/components/ReadAloudButton';
import SmartSuggestions from '@/components/groceries/SmartSuggestions';
import PantryBasics from '@/components/groceries/PantryBasics';
import RecipeSuggestion from '@/components/groceries/RecipeSuggestion';
import ExpiryReminder from '@/components/groceries/ExpiryReminder';
import { todayLocal } from '@/lib/localDate';

const todayStr = todayLocal;

export default function Groceries() {
  const { t } = useAppSettings();
  const [items, setItems] = useState(null);
  const [newItem, setNewItem] = useState('');
  const [editingNote, setEditingNote] = useState(null);
  const [noteDraft, setNoteDraft] = useState('');

  const load = async () => {
    const data = await base44.entities.Grocery.list('-created_date', 200);
    setItems(data);
  };

  useEffect(() => { load(); }, []);

  const handleVoiceResult = async (transcript) => {
    const item = transcript.trim();
    if (item) {
      await base44.entities.Grocery.create({ item, purchased: false });
      load();
    }
  };

  const addItem = async () => {
    if (!newItem.trim()) return;
    await base44.entities.Grocery.create({ item: newItem.trim(), purchased: false });
    setNewItem('');
    load();
  };

  const togglePurchased = async (item) => {
    await base44.entities.Grocery.update(item.id, {
      purchased: !item.purchased,
      purchased_date: !item.purchased ? todayStr() : null,
    });
    load();
  };

  const deleteItem = async (id) => {
    await base44.entities.Grocery.delete(id);
    load();
  };

  const togglePickupType = async (item, type) => {
    const newType = item.pickup_type === type ? null : type;
    await base44.entities.Grocery.update(item.id, { pickup_type: newType });
    load();
  };

  const startEditNote = (item) => {
    setEditingNote(item.id);
    setNoteDraft(item.note || '');
  };

  const saveNote = async (item) => {
    await base44.entities.Grocery.update(item.id, { note: noteDraft.trim() });
    setEditingNote(null);
    load();
  };

  const addSuggestedItem = async (name) => {
    await base44.entities.Grocery.create({ item: name, purchased: false });
    load();
  };

  const sorted = items ? [...items].sort((a, b) => a.purchased - b.purchased) : null;

  return (
    <div>
      <PageHeader title={t('groceries')} description={t('groceriesDesc')} />
      {items && (
        <ReadAloudButton text={items.length === 0 ? t('noItems') : `${t('groceryList')}. ` + items.filter(g => !g.purchased).map(g => g.item).join('. ')} />
      )}
      <div className="flex gap-2 mb-5">
        <input
          value={newItem}
          onChange={(e) => setNewItem(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addItem()}
          placeholder={t('addItem')}
          className="flex-1 px-4 py-3 rounded-xl border-2 border-slate-300 focus:border-green-500 outline-none text-lg"
        />
        <button
          onClick={addItem}
          className="flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-bold px-6 rounded-xl transition min-h-[56px]"
        >
          <Plus className="w-6 h-6" strokeWidth={2.5} />
          {t('add')}
        </button>
      </div>

      <div className="mb-5">
        <VoiceButton
          label={t('addByVoice')}
          prompt={t('voiceGroceryPrompt')}
          onResult={handleVoiceResult}
        />
      </div>

      <SmartSuggestions onAdd={addSuggestedItem} />
      <PantryBasics onAdd={addSuggestedItem} />

      {sorted === null ? (
        <p className="text-center text-slate-500 py-8">{t('loading')}</p>
      ) : sorted.length === 0 ? (
        <p className="text-center text-slate-500 py-8">{t('noItems')}</p>
      ) : (
        <div className="space-y-3">
          {sorted.map((item) => (
            <div key={item.id} className={`p-4 rounded-2xl border-2 ${item.purchased ? 'bg-slate-100 border-slate-200' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => togglePurchased(item)}
                  className={`w-12 h-12 rounded-xl flex items-center justify-center transition shrink-0 ${
                    item.purchased ? 'bg-green-600 text-white' : 'bg-white border-2 border-slate-300 hover:border-green-500'
                  }`}
                >
                  {item.purchased && <Check className="w-7 h-7" strokeWidth={3} />}
                </button>
                <div className="flex-1 min-w-0">
                  <span className={`text-lg ${item.purchased ? 'line-through text-slate-400' : 'text-slate-900 font-semibold'}`}>
                    {item.item}
                  </span>
                  {item.note && editingNote !== item.id && (
                    <p className="text-sm text-slate-500 mt-1">📝 {item.note}</p>
                  )}
                </div>
                <button
                  onClick={() => startEditNote(item)}
                  className="p-3 rounded-xl text-slate-400 hover:bg-slate-100 transition"
                >
                  <StickyNote className="w-5 h-5" />
                </button>
                <button
                  onClick={() => deleteItem(item.id)}
                  className="p-3 rounded-xl text-red-500 hover:bg-red-50 transition"
                >
                  <Trash2 className="w-6 h-6" />
                </button>
              </div>
              {editingNote === item.id && (
                <div className="mt-3 flex gap-2">
                  <input
                    value={noteDraft}
                    onChange={(e) => setNoteDraft(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && saveNote(item)}
                    placeholder={t('addNote')}
                    className="flex-1 px-3 py-2 rounded-lg border-2 border-slate-300 focus:border-green-500 outline-none text-base"
                  />
                  <button onClick={() => saveNote(item)} className="bg-green-600 text-white font-bold px-4 rounded-lg">
                    {t('save')}
                  </button>
                </div>
              )}
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => togglePickupType(item, 'pickup')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-bold transition ${
                    item.pickup_type === 'pickup' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  📦 {t('illPickUp')}
                </button>
                <button
                  onClick={() => togglePickupType(item, 'delivery')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-bold transition ${
                    item.pickup_type === 'delivery' ? 'bg-purple-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  🚚 {t('deliveryRequested')}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      {items && items.length >= 3 && <RecipeSuggestion items={items} />}
      {items && <ExpiryReminder items={items} />}
    </div>
  );
}