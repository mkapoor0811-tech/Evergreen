// One visit in full: questions to ask, what to bring, and the write-up.
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useParams, useNavigate } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import VisitForm from '@/components/appointments/VisitForm';
import ConfirmDialog from '@/components/appointments/ConfirmDialog';
import VisitNoteSection from '@/components/appointments/VisitNoteSection';
import VisitActionButton from '@/components/appointments/VisitActionButton';
import ShareWithCaregiverButton from '@/components/appointments/ShareWithCaregiverButton';
import VisitPrepActions from '@/components/appointments/VisitPrepActions';
import { formatShortDay, formatTime12 } from '@/lib/timeFormat';
import { Bell, Car, Pencil, Trash2 } from 'lucide-react';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

/** One visit's own page: a plain list of large buttons. */
export default function VisitDetail() {
  const { t, language } = useAppSettings();
  const { id } = useParams();
  const navigate = useNavigate();
  const [appt, setAppt] = useState(null);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState(null);
  const [askDelete, setAskDelete] = useState(false);

  const load = async () => setAppt(await base44.entities.Appointment.get(id));

  useEffect(() => { load(); }, [id]);

  if (!appt) {
    return <p className="text-center text-muted-foreground py-8">{t('loading')}</p>;
  }

  const locale = LOCALES[language] || 'en-US';

  const toggleReminders = async () => {
    await base44.entities.Appointment.update(appt.id, {
      reminders_on: appt.reminders_on === false,
      reminder_day_before_sent: false,
      reminder_morning_sent: false,
    });
    load();
  };

  const toggleRide = async () => {
    await base44.entities.Appointment.update(appt.id, { needs_ride: !appt.needs_ride });
    load();
  };

  const startEdit = () => {
    setForm({
      doctor_name: appt.doctor_name || '',
      date: appt.date || '',
      time: appt.time || '09:00',
      doctor_phone: appt.doctor_phone || '',
    });
    setEditing(true);
  };

  const saveEdit = async () => {
    if (!form.doctor_name.trim()) return;
    await base44.entities.Appointment.update(appt.id, {
      doctor_name: form.doctor_name.trim(),
      date: form.date,
      time: form.time,
      doctor_phone: (form.doctor_phone || '').trim(),
    });
    setEditing(false);
    load();
  };

  const remove = async () => {
    await base44.entities.Appointment.delete(appt.id);
    navigate('/appointments');
  };

  return (
    <div>
      <PageHeader title={appt.doctor_name} />
      <p className="text-2xl text-foreground mb-6">
        {formatShortDay(appt.date, locale)}, {formatTime12(appt.time, locale)}
      </p>

      {editing ? (
        <VisitForm
          form={form}
          setForm={setForm}
          onSubmit={saveEdit}
          onCancel={() => setEditing(false)}
          full
        />
      ) : (
        <div className="space-y-4">
          <VisitPrepActions appt={appt} />
          <VisitActionButton
            icon={Bell}
            label={t('remindMe')}
            value={appt.reminders_on === false ? t('stateOff') : t('stateOn')}
            onClick={toggleReminders}
          />
          <VisitActionButton
            icon={Car}
            label={t('needsRide')}
            value={appt.needs_ride ? t('stateOn') : t('stateOff')}
            onClick={toggleRide}
          />
          <ShareWithCaregiverButton appt={appt} />
          <VisitActionButton icon={Pencil} label={t('edit')} onClick={startEdit} />
          <VisitActionButton icon={Trash2} label={t('delete')} danger onClick={() => setAskDelete(true)} />
        </div>
      )}

      <div className="mt-6">
        <VisitNoteSection appt={appt} onSaved={load} />
      </div>

      {askDelete && (
        <ConfirmDialog
          title={t('areYouSure')}
          message={`${appt.doctor_name} — ${formatShortDay(appt.date, locale)}`}
          confirmLabel={t('yesDelete')}
          onConfirm={remove}
          onClose={() => setAskDelete(false)}
        />
      )}
    </div>
  );
}