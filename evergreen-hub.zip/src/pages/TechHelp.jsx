// Tech help: lessons for using a phone or computer.
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import ReadAloudButton from '@/components/ReadAloudButton';
import AskFamilyButton from '@/components/techhelp/AskFamilyButton';
import { TECH_LESSONS } from '@/lib/techHelpData';
import { BookMarked, PlayCircle, Check, ChevronRight, Wrench } from 'lucide-react';

export default function TechHelp() {
  const { t } = useAppSettings();
  const [completedIds, setCompletedIds] = useState(null);

  useEffect(() => {
    base44.entities.TechProgress.filter({ completed: true }, { limit: 100 })
      .then((page) => setCompletedIds(new Set(page.items.map((i) => i.lesson_id))))
      .catch(() => setCompletedIds(new Set()));
  }, []);

  const total = TECH_LESSONS.length;
  const doneCount = completedIds ? TECH_LESSONS.filter((l) => completedIds.has(l.id)).length : 0;
  const pct = total ? Math.round((doneCount / total) * 100) : 0;

  return (
    <div>
      <PageHeader title={t('techHelp')} description={t('techHelpDesc')} />
      <ReadAloudButton text={`${t('techHelp')}. ${t('techHelpIntro')}`} />

      <p className="text-lg text-foreground mb-5">{t('techHelpIntro')}</p>

      <div className="mb-6 p-5 rounded-2xl bg-card border border-border">
        <div className="flex items-baseline justify-between mb-2">
          <span className="font-heading text-lg text-foreground">{doneCount} / {total}</span>
          <span className="text-muted-foreground">{t('lessonsComplete')}</span>
        </div>
        <div className="h-4 rounded-full bg-secondary overflow-hidden">
          <div className="h-full bg-primary transition-all" style={{ width: `${pct}%` }} />
        </div>
      </div>

      <div className="space-y-3 mb-7">
        {TECH_LESSONS.map((lesson, idx) => {
          const done = completedIds && completedIds.has(lesson.id);
          return (
            <Link
              key={lesson.id}
              to={`/tech-help/lesson/${lesson.id}`}
              className="flex items-center gap-4 rounded-2xl bg-card border border-border px-5 py-4 hover:border-primary/40 hover:shadow-sm transition"
            >
              <span className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${done ? 'bg-primary text-primary-foreground' : 'bg-primary/10 text-primary'}`}>
                {done ? <Check className="w-6 h-6" strokeWidth={3} /> : <span className="font-heading text-xl">{idx + 1}</span>}
              </span>
              <span className="flex-1 min-w-0">
                <span className="block font-heading text-lg text-foreground leading-tight">{lesson.title}</span>
                <span className="block text-sm text-muted-foreground mt-0.5">
                  {done ? t('completed') : `${lesson.steps.length} ${lesson.steps.length === 1 ? t('stepOne') : t('stepMany')}`}
                </span>
              </span>
              <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" strokeWidth={2} />
            </Link>
          );
        })}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-7">
        <Link to="/tech-help/dictionary" className="flex items-center gap-4 rounded-2xl bg-card border border-border px-5 py-4 hover:border-primary/40 transition">
          <span className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <BookMarked className="w-6 h-6 text-primary" strokeWidth={2} />
          </span>
          <span className="flex-1">
            <span className="block font-heading text-lg text-foreground">{t('techDictionary')}</span>
            <span className="block text-sm text-muted-foreground">{t('techDictionaryDesc')}</span>
          </span>
        </Link>
        <Link to="/tech-help/practice" className="flex items-center gap-4 rounded-2xl bg-card border border-border px-5 py-4 hover:border-primary/40 transition">
          <span className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <PlayCircle className="w-6 h-6 text-primary" strokeWidth={2} />
          </span>
          <span className="flex-1">
            <span className="block font-heading text-lg text-foreground">{t('practiceMode')}</span>
            <span className="block text-sm text-muted-foreground">{t('practiceModeDesc')}</span>
          </span>
        </Link>
      </div>

      <AskFamilyButton />
    </div>
  );
}