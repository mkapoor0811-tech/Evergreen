// Family dashboard: what family sees — check-ins, alerts, medicines and visits.
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import Illustration from '@/components/Illustration';
import { ILLUSTRATIONS } from '@/lib/illustrations';
import { Heart, Pill, Calendar, ShoppingCart, Check, AlertTriangle, Clock, Stethoscope } from 'lucide-react';
import { sendMissedCheckInAlertIfNeeded, sendIsolationAlertIfNeeded } from '@/lib/caregiverAlerts';
import { detectIsolation } from '@/lib/isolationDetector';
import { getDueStatus } from '@/lib/careSchedule';
import WeeklySummary from '@/components/WeeklySummary';
import SupportSuggestion from '@/components/SupportSuggestion';
import IsolationAlert from '@/components/IsolationAlert';
import NeedsAttention from '@/components/family/NeedsAttention';
import CheckInCalendar from '@/components/checkin/CheckInCalendar';
import MedicationAdherence from '@/components/family/MedicationAdherence';
import WellbeingVisuals from '@/components/wellbeing/WellbeingVisuals';
import AppetiteAlert from '@/components/family/AppetiteAlert';
import EmergencyAlerts from '@/components/family/EmergencyAlerts';
import SharedRecaps from '@/components/family/SharedRecaps';
import { todayLocal, localDate } from '@/lib/localDate';
import { LOCALES, formatTime12 } from '@/lib/timeFormat';

const todayStr = todayLocal;

const CARE_STYLE = {
  overdue: { band: 'bg-earth-terracotta', chip: 'bg-earth-terracotta/15 text-earth-terracottaDark' },
  dueSoon: { band: 'bg-earth-marigold', chip: 'bg-earth-marigold/25 text-earth-marigoldDark' },
  unknown: { band: 'bg-earth-navy', chip: 'bg-earth-navy/12 text-earth-navy' },
};

export default function FamilyDashboard() {
  const { t, checkInDeadline, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';
  const [data, setData] = useState(null);

  useEffect(() => {
    const since = new Date();
    since.setDate(since.getDate() - 7);
    Promise.all([
      base44.entities.CheckIn.list('-date', 200),
      base44.entities.Medication.list('-created_date', 100),
      base44.entities.Appointment.list('date', 100),
      base44.entities.Grocery.list('-created_date', 200),
      base44.entities.DietLog.list('-date', 200),
      base44.entities.Exercise.list('-created_date', 100),
      base44.entities.CareRoutine.list('name', 100),
      base44.entities.DoseLog.filter(
        { date: { $gte: localDate(since) } },
        { sort: '-date', limit: 300 },
      ),
      base44.entities.AppetiteLog.filter(
        { date: { $gte: localDate(since) } },
        { sort: '-date', limit: 10 },
      ),
    ]).then(([checkIns, meds, appts, groceries, dietLogs, exercises, routines, dosePage, appetitePage]) => {
      setData({
        checkIns, meds, appts, groceries, dietLogs, exercises, routines,
        doseLogs: dosePage.items || [],
        appetiteLogs: appetitePage.items || [],
      });
    });
  }, []);

  useEffect(() => {
    if (!data) return;
    const checkIn = data.checkIns.find((c) => c.date === todayStr()) || null;
    const isCheckedIn = checkIn?.checked_in;
    const now = new Date();
    const [dh, dm] = (checkInDeadline || '12:00').split(':').map(Number);
    const deadline = new Date();
    deadline.setHours(dh, dm, 0, 0);
    if (!isCheckedIn && now > deadline) {
      sendMissedCheckInAlertIfNeeded().catch((e) => console.error('Caregiver alert failed:', e));
    }
    const pattern = detectIsolation(data);
    if (pattern) {
      sendIsolationAlertIfNeeded(pattern).catch((e) => console.error('Isolation alert failed:', e));
    }
  }, [data, checkInDeadline]);

  if (!data) return <div><PageHeader title={t('familyDashboard')} /><p className="text-center text-muted-foreground py-8">{t('loading')}</p></div>;

  const checkIn = data.checkIns.find((c) => c.date === todayStr()) || null;
  const isCheckedIn = checkIn?.checked_in;

  const now = new Date();
  const [dh, dm] = (checkInDeadline || '12:00').split(':').map(Number);
  const deadline = new Date();
  deadline.setHours(dh, dm, 0, 0);
  const isPastDeadline = now > deadline;
  const isMissed = !isCheckedIn && isPastDeadline;

  const upcomingAppts = data.appts.filter((a) => a.date >= todayStr()).slice(0, 5);
  const neededGroceries = data.groceries.filter((g) => !g.purchased);

  const careDue = data.routines
    .map((r) => ({ routine: r, due: getDueStatus(r) }))
    .filter(({ due }) => due.status === 'overdue' || due.status === 'dueSoon' || due.status === 'unknown');

  const fmtDate = (d) => new Date(d + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });

  return (
    <div>
      <PageHeader title={t('familyDashboard')} />

      <Illustration src={ILLUSTRATIONS.together} alt={t('illTogetherAlt')} />

      <EmergencyAlerts />

      <SharedRecaps />

      <NeedsAttention
        isMissed={isMissed}
        meds={data.meds}
        appts={data.appts}
        helpRequested={!!checkIn?.help_requested}
      />

      <CheckInCalendar checkIns={data.checkIns} />

      {/* Safety Status */}
      <div className={`rounded-3xl border-2 mb-6 overflow-hidden ${isMissed ? 'border-earth-terracotta/40' : isCheckedIn ? 'border-earth-sage/50' : 'border-earth-marigold/50'}`}>
        <div className={`px-5 py-2.5 ${isMissed ? 'bg-earth-terracotta' : isCheckedIn ? 'bg-earth-sage' : 'bg-earth-marigold'}`}>
          <h2 className="font-heading text-xl text-white">{t('safetyStatus')}</h2>
        </div>
        <div className="p-5 bg-card">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 blob flex items-center justify-center shrink-0 ${isMissed ? 'bg-earth-terracotta/15' : isCheckedIn ? 'bg-earth-sage/20' : 'bg-earth-marigold/25'}`}>
              {isMissed
                ? <AlertTriangle className="w-7 h-7 text-earth-terracottaDark" strokeWidth={2.25} />
                : <Heart className="w-7 h-7 text-earth-sageDark" strokeWidth={2.25} />}
            </div>
            <p className={`text-lg font-bold ${isMissed ? 'text-earth-terracottaDark' : isCheckedIn ? 'text-earth-sageDark' : 'text-earth-marigoldDark'}`}>
              {isMissed ? t('missedCheckIn') : isCheckedIn ? t('checkedIn') : t('notCheckedInYet')}
            </p>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground font-semibold mt-3">
            <Clock className="w-4 h-4" />
            {t('checkInDeadline')}: {checkInDeadline}
          </div>
        </div>
      </div>

      <WeeklySummary
        meds={data.meds}
        appts={data.appts}
        groceries={data.groceries}
        dietLogs={data.dietLogs}
        exercises={data.exercises}
        checkIns={data.checkIns}
      />

      <IsolationAlert pattern={detectIsolation(data)} />

      <SupportSuggestion
        checkIns={data.checkIns}
        exercises={data.exercises}
        dietLogs={data.dietLogs}
      />

      {/* Routine care to book */}
      <div className="rounded-3xl bg-card border border-border overflow-hidden mb-6">
        <div className="bg-earth-lagoon px-5 py-2.5">
          <h2 className="font-heading text-xl text-white">{t('careDueTitle')}</h2>
        </div>
        <div className="p-5">
          {careDue.length === 0 ? (
            <p className="text-muted-foreground">{t('careDueNone')}</p>
          ) : (
            <>
              <p className="text-muted-foreground mb-4">{t('careDueDesc')}</p>
              <ul className="space-y-3">
                {careDue.map(({ routine, due }) => {
                  const style = CARE_STYLE[due.status] || CARE_STYLE.dueSoon;
                  return (
                    <li key={routine.id} className="flex items-center gap-3">
                      <span className={`w-10 h-10 blob flex items-center justify-center shrink-0 ${style.chip}`}>
                        <Stethoscope className="w-5 h-5" strokeWidth={2.25} />
                      </span>
                      <span className="flex-1 min-w-0">
                        <span className="block font-heading text-lg text-foreground leading-tight">{routine.name}</span>
                        <span className="block text-sm text-muted-foreground">
                          {routine.last_done ? `${t('lastDone')}: ${fmtDate(routine.last_done)}` : t('dueUnknown')}
                        </span>
                      </span>
                      <span className={`rounded-full px-3 py-1 text-sm font-bold shrink-0 ${style.chip}`}>
                        {due.status === 'overdue' ? t('dueOverdue') : due.status === 'dueSoon' ? t('dueSoon') : t('dueUnknown')}
                      </span>
                    </li>
                  );
                })}
              </ul>
            </>
          )}
        </div>
      </div>

      {/* Medication Status */}
      <AppetiteAlert logs={data.appetiteLogs} />

      <MedicationAdherence meds={data.meds} doseLogs={data.doseLogs} />

      <WellbeingVisuals />

      {/* Appointments */}
      <div className="rounded-3xl bg-card border border-border overflow-hidden mb-6">
        <div className="bg-earth-lagoon px-5 py-2.5">
          <h2 className="font-heading text-xl text-white">{t('apptSchedule')}</h2>
        </div>
        <div className="p-5">
          {upcomingAppts.length === 0 ? (
            <p className="text-muted-foreground">{t('noAppointments')}</p>
          ) : (
            <div className="space-y-2">
              {upcomingAppts.map((a) => (
                <div key={a.id} className="flex items-center gap-3 py-2 border-b border-border last:border-0">
                  <div className="text-center w-14 shrink-0">
                    <p className="text-xs text-muted-foreground">{fmtDate(a.date).split(' ')[0]}</p>
                    <p className="font-bold text-foreground">{fmtDate(a.date).split(' ')[1]} {fmtDate(a.date).split(' ')[2]}</p>
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-foreground">{a.doctor_name}</p>
                    <p className="text-muted-foreground text-sm">{formatTime12(a.time, locale)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Grocery List */}
      <div className="rounded-3xl bg-card border border-border overflow-hidden">
        <div className="bg-earth-lagoon px-5 py-2.5">
          <h2 className="font-heading text-xl text-white">{t('groceryList')}</h2>
        </div>
        <div className="p-5">
          {neededGroceries.length === 0 ? (
            <p className="text-earth-sageDark font-semibold flex items-center gap-2">
              <Check className="w-5 h-5" strokeWidth={3} />
              {t('groceryDone')}
            </p>
          ) : (
            <ul className="space-y-2">
              {neededGroceries.map((g) => (
                <li key={g.id} className="flex items-center gap-3 py-1">
                  <div className="w-5 h-5 rounded-full border-2 border-border" />
                  <span className="text-foreground">{g.item}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}