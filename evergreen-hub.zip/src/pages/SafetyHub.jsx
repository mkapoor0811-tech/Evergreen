// Safety hub: the same panel-and-row layout as the Learn tab. Two panels group
// the five screens — staying safe day to day, then being ready for an emergency.
import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import HubSection from '@/components/hub/HubSection';
import HubRow from '@/components/hub/HubRow';
import { Heart, ShieldAlert, PhoneCall, FileText, Flame } from 'lucide-react';

const SAFE_ROWS = [
  { to: '/check-in', icon: Heart, titleKey: 'dailyCheckIn', descKey: 'dailyCheckInDesc', hex: '#2F7D6B' },
  { to: '/scam-checker', icon: ShieldAlert, titleKey: 'scamChecker', descKey: 'scamCheckerDesc', hex: '#4A4E9A' },
];

const READY_ROWS = [
  { to: '/emergency-profile', icon: PhoneCall, titleKey: 'emergencyProfile', descKey: 'emergencyProfileDesc', hex: '#A23B3B' },
  { to: '/emergency-readiness', icon: Flame, titleKey: 'readiness', descKey: 'readinessDesc', hex: '#C2651F' },
  { to: '/health-summary', icon: FileText, titleKey: 'healthSummary', descKey: 'healthSummaryCardDesc', hex: '#3E5C76' },
];

export default function SafetyHub() {
  const { t } = useAppSettings();

  return (
    <div>
      <PageHeader title={t('safetyHubTitle')} description={t('safetyHubDesc')} />

      <HubSection title={t('hubStaySafeTitle')} hex="#2E3A59">
        {SAFE_ROWS.map(({ to, icon, titleKey, descKey, hex }) => (
          <HubRow key={to} to={to} icon={icon} hex={hex} title={t(titleKey)} description={t(descKey)} />
        ))}
      </HubSection>

      <HubSection title={t('hubReadyTitle')} hex="#5B4A7A">
        {READY_ROWS.map(({ to, icon, titleKey, descKey, hex }) => (
          <HubRow key={to} to={to} icon={icon} hex={hex} title={t(titleKey)} description={t(descKey)} />
        ))}
      </HubSection>
    </div>
  );
}