// Today: the day's schedule, what is next, and a one-tap mood check.
import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { Heart, ArrowRight } from 'lucide-react';
import WeatherAlert from '@/components/WeatherAlert';
import DidYouKnowCard from '@/components/dailyfact/DidYouKnowCard';
import DayDial from '@/components/home/DayDial';
import WellbeingVisuals from '@/components/wellbeing/WellbeingVisuals';
import WhyAppCard from '@/components/home/WhyAppCard';
import ComingSoonDevices from '@/components/home/ComingSoonDevices';
import NightMode from '@/components/NightMode';
import TodayView from '@/components/home/TodayView';
import UpcomingReminder from '@/components/appointments/UpcomingReminder';
import AppointmentSoonReminder from '@/components/appointments/AppointmentSoonReminder';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

export default function Home() {
  const { t, language, simpleMode, updateSetting } = useAppSettings();
  const [showOnboardingPrompt, setShowOnboardingPrompt] = useState(false);
  const hour = new Date().getHours();
  const isNightHour = hour >= 22 || hour < 6;
  const [nightDismissed, setNightDismissed] = useState(() => {
    const ts = localStorage.getItem('mahika_nightDismissed');
    return ts ? Date.now() - parseInt(ts) < 8 * 60 * 60 * 1000 : false;
  });
  const [manualNightMode, setManualNightMode] = useState(() => localStorage.getItem('mahika_manualNightMode') === 'true');
  const showNightMode = (isNightHour && !nightDismissed) || manualNightMode;

  const exitNightMode = () => {
    localStorage.setItem('mahika_manualNightMode', 'false');
    localStorage.setItem('mahika_nightDismissed', Date.now().toString());
    setNightDismissed(true);
    setManualNightMode(false);
  };

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u && !u.onboarded) setShowOnboardingPrompt(true);
    }).catch(() => {});
  }, []);

  const greeting = hour < 12 ? t('goodMorning') : hour < 18 ? t('goodAfternoon') : t('goodEvening');

  const today = new Date().toLocaleDateString(LOCALES[language] || 'en-US', {
    weekday: 'long', month: 'long', day: 'numeric',
  });

  if (showNightMode) {
    return <NightMode onExit={exitNightMode} />;
  }

  return (
    <div>
      <div className="mb-6">
        <p className="text-muted-foreground font-semibold capitalize">{today}</p>
        <h1 className="text-4xl text-foreground leading-tight">
          {greeting}, <span className="text-earth-terracotta">{t('hereIsYourDay')}</span>
        </h1>
      </div>

      <WhyAppCard />

      {/* The featured card of the screen — what today looks like. */}
      <TodayView />

      <AppointmentSoonReminder />

      <UpcomingReminder />

      {simpleMode ? (
        <>
          <button
            onClick={() => updateSetting('simpleMode', false)}
            className="w-full mb-8 py-4 rounded-2xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
          >
            {t('showAllFeatures')}
          </button>
        </>
      ) : (
        <>
          <WeatherAlert />
          <DayDial />
          <WellbeingVisuals />
          <DidYouKnowCard />

          {showOnboardingPrompt && (
            <Link to="/onboarding" className="block mb-6 p-5 rounded-3xl border-2 border-earth-terracotta/40 bg-earth-terracotta/10 hover:bg-earth-terracotta/15 transition">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 blob bg-earth-terracotta flex items-center justify-center shrink-0">
                  <Heart className="w-7 h-7 text-white" strokeWidth={2.5} />
                </div>
                <div className="flex-1">
                  <p className="font-heading text-lg text-foreground">{t('onboardingPromptTitle')}</p>
                  <p className="text-muted-foreground">{t('onboardingPromptDesc')}</p>
                </div>
                <ArrowRight className="w-6 h-6 text-earth-terracotta shrink-0" />
              </div>
            </Link>
          )}
        </>
      )}

      <ComingSoonDevices />
    </div>
  );
}