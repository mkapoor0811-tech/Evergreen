// Learn hub: daily learning, topics, calming activities and tech help.
import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import Illustration from '@/components/Illustration';
import { ILLUSTRATIONS } from '@/lib/illustrations';
import HomeSection from '@/components/home/HomeSection';
import AppCard from '@/components/AppCard';
import DailyBoostCard from '@/components/learn/DailyBoostCard';
import { Library, BookOpen, MonitorSmartphone, Wind, Sprout } from 'lucide-react';

export default function LearnHub() {
  const { t } = useAppSettings();

  return (
    <div>
      <PageHeader title={t('learnHubTitle')} description={t('learnHubDesc')} />

      <Illustration src={ILLUSTRATIONS.learn} alt={t('illLearnAlt')} />

      <HomeSection title={t('bandEveryday')} layout="grid" color="learn">
        <DailyBoostCard />
      </HomeSection>

      <HomeSection title={t('bandUnderstand')} color="learn">
        <AppCard to="/learn/topics" icon={Library} title={t('healthTopics')} description={t('healthTopicsDesc')} />
        <AppCard to="/term-explainer" icon={BookOpen} title={t('termExplainer')} description={t('termExplainerDesc')} />
        <AppCard to="/tech-help" icon={MonitorSmartphone} title={t('techHelp')} description={t('techHelpDesc')} />
      </HomeSection>

      <HomeSection title={t('bandCalm')} collapsible defaultOpen={false} color="learn">
        <AppCard to="/breathe" icon={Wind} title={t('breathe')} description={t('breatheDesc')} />
        <AppCard to="/garden" icon={Sprout} title={t('gardenTipsTitle')} description={t('gardenTipsDesc')} />
      </HomeSection>
    </div>
  );
}