// Getting ready for a visit: the questions to ask and what to bring.
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useParams } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import ReadAloudButton from '@/components/ReadAloudButton';
import QuestionList from '@/components/appointments/QuestionList';
import StarterQuestions from '@/components/appointments/StarterQuestions';
import BringWithYou from '@/components/appointments/BringWithYou';
import { LOCALES, formatShortDay } from '@/lib/timeFormat';

/** Getting ready for a visit: what to ask, and what to bring. */
export default function VisitPrepare() {
  const { t, language } = useAppSettings();
  const { id } = useParams();
  const [appt, setAppt] = useState(null);
  const [meds, setMeds] = useState([]);

  useEffect(() => {
    base44.entities.Appointment.get(id).then(setAppt);
    base44.entities.Medication.list('-created_date', 100).then(setMeds);
  }, [id]);

  const saveQuestions = async (questions) => {
    setAppt((a) => ({ ...a, questions }));
    await base44.entities.Appointment.update(id, { questions });
  };

  if (!appt) {
    return <p className="text-center text-muted-foreground py-8">{t('loading')}</p>;
  }

  const questions = appt.questions || [];
  const locale = LOCALES[language] || 'en-US';

  const readAloud = [
    t('prepareTitle'),
    ...questions.map((q) => q.text),
    t('bringWithYou'),
    ...meds.map((m) => `${m.name}${m.dosage ? `, ${m.dosage}` : ''}`),
  ].join('. ');

  return (
    <div>
      <PageHeader title={t('prepareTitle')} />
      <p className="text-2xl text-foreground mb-5">
        {appt.doctor_name} — {formatShortDay(appt.date, locale)}
      </p>

      <ReadAloudButton text={readAloud} />

      <div className="space-y-9">
        <QuestionList
          questions={questions}
          onChange={saveQuestions}
        />
        <StarterQuestions
          existing={questions}
          onAdd={(text) => saveQuestions([...questions, { text }])}
        />
        <BringWithYou meds={meds} />
      </div>
    </div>
  );
}