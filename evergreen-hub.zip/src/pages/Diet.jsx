// Food: today's meals, the weekly planner, food checks and the portion guide.
import React, { useState, useEffect } from 'react';
import ActionButton from '@/components/ActionButton';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import { Save, Check, Loader2 } from 'lucide-react';
import VoiceButton from '@/components/VoiceButton';
import { parseDiet } from '@/lib/voiceParse';
import ReadAloudButton from '@/components/ReadAloudButton';
import DietRecommendations from '@/components/DietRecommendations';
import DietDisclaimer from '@/components/diet/DietDisclaimer';
import FoodSetupCard from '@/components/diet/FoodSetupCard';
import AppetiteTracker from '@/components/diet/AppetiteTracker';
import MealMedicationPrompt from '@/components/diet/MealMedicationPrompt';
import WeeklyMealPlanner from '@/components/diet/WeeklyMealPlanner';
import FoodCheck from '@/components/diet/FoodCheck';
import PlateGuide from '@/components/diet/PlateGuide';
import CuisinePicker from '@/components/diet/CuisinePicker';
import { todayLocal } from '@/lib/localDate';

const todayStr = todayLocal;

export default function Diet() {
  const { t } = useAppSettings();
  const [log, setLog] = useState(null);
  const [saved, setSaved] = useState(false);
  const [voiceProcessing, setVoiceProcessing] = useState(false);
  const [justLoggedSlot, setJustLoggedSlot] = useState(null);

  useEffect(() => {
    base44.entities.DietLog.filter({ date: todayStr() }).then((data) => {
      if (data.length > 0) {
        setLog(data[0]);
      } else {
        setLog({ date: todayStr(), breakfast: '', lunch: '', dinner: '', snacks: '' });
      }
    });
  }, []);

  const update = (field, value) => {
    setLog({ ...log, [field]: value });
    setSaved(false);
  };

  const handleVoiceResult = async (transcript) => {
    setVoiceProcessing(true);
    try {
      const parsed = await parseDiet(transcript);
      if (parsed.meal && parsed.content) {
        setLog((prev) => {
          const existing = prev[parsed.meal] || '';
          return { ...prev, [parsed.meal]: existing ? existing + ' ' + parsed.content : parsed.content };
        });
        setSaved(false);
      }
    } catch (e) { /* ignore */ }
    setVoiceProcessing(false);
  };

  const save = async () => {
    if (log.id) {
      await base44.entities.DietLog.update(log.id, {
        breakfast: log.breakfast, lunch: log.lunch, dinner: log.dinner, snacks: log.snacks,
      });
    } else {
      const created = await base44.entities.DietLog.create({
        date: log.date, breakfast: log.breakfast, lunch: log.lunch, dinner: log.dinner, snacks: log.snacks,
      });
      setLog(created);
    }
    setSaved(true);
  };

  // A meal typed in the week's plan is written straight into today's food log.
  const handleLogMeal = async (slot, name, date) => {
    if (date !== todayStr()) return;
    const existing = log[slot] || '';
    const next = { ...log, [slot]: existing ? `${existing}, ${name}` : name };

    if (next.id) {
      await base44.entities.DietLog.update(next.id, {
        breakfast: next.breakfast, lunch: next.lunch, dinner: next.dinner, snacks: next.snacks,
      });
    } else {
      const created = await base44.entities.DietLog.create({
        date: next.date, breakfast: next.breakfast, lunch: next.lunch, dinner: next.dinner, snacks: next.snacks,
      });
      next.id = created.id;
    }
    setLog(next);
    setSaved(true);
    setJustLoggedSlot(slot);
  };

  const today = new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
  const meals = [
    { key: 'breakfast', label: t('breakfast') },
    { key: 'lunch', label: t('lunch') },
    { key: 'dinner', label: t('dinner') },
    { key: 'snacks', label: t('snacks') },
  ];

  if (!log) return <div><PageHeader title={t('diet')} description={t('dietDesc')} /><p className="text-center text-muted-foreground py-8">{t('loading')}</p></div>;

  return (
    <div>
      <PageHeader title={t('diet')} description={t('dietDesc')} />
      <p className="text-muted-foreground font-semibold capitalize mb-5">{today}</p>

      <FoodSetupCard />

      <DietDisclaimer />

      {log && (
        <ReadAloudButton text={`${t('breakfast')}: ${log.breakfast || '...'}. ${t('lunch')}: ${log.lunch || '...'}. ${t('dinner')}: ${log.dinner || '...'}. ${t('snacks')}: ${log.snacks || '...'}.`} />
      )}

      <h2 className="font-heading text-2xl text-foreground mb-4">{t('todayMeals')}</h2>

      <div className="mb-5">
        <VoiceButton
          label={t('addByVoice')}
          prompt={t('voiceDietPrompt')}
          onResult={handleVoiceResult}
        />
      </div>
      {voiceProcessing && (
        <div className="mb-5 flex items-center justify-center gap-2 p-4 bg-earth-lagoon/10 rounded-2xl text-earth-lagoonDark font-bold">
          <Loader2 className="w-5 h-5 animate-spin" />
          {t('voiceProcessing')}
        </div>
      )}

      <div className="space-y-5">
        {meals.map((meal) => (
          <div key={meal.key} className="p-5 bg-card rounded-2xl border-2 border-border">
            <label className="block font-bold text-foreground text-lg mb-2">{meal.label}</label>
            <textarea
              value={log[meal.key] || ''}
              onChange={(e) => update(meal.key, e.target.value)}
              placeholder={t('whatDidYouEat')}
              rows={2}
              className="w-full px-4 py-3 rounded-xl border-2 border-input bg-card text-foreground focus:border-earth-terracotta outline-none text-lg resize-none"
            />
          </div>
        ))}
      </div>

      <ActionButton onClick={save} className="w-full mt-5 mb-6">
        {saved ? <Check className="w-6 h-6" strokeWidth={3} /> : <Save className="w-6 h-6" strokeWidth={2.5} />}
        {saved ? t('saved') : t('save')}
      </ActionButton>

      <MealMedicationPrompt justLoggedSlot={justLoggedSlot} />
      <AppetiteTracker />
      <WeeklyMealPlanner onLogMeal={handleLogMeal} />
      <FoodCheck />
      <PlateGuide />
      <CuisinePicker />
      <DietRecommendations />
    </div>
  );
}