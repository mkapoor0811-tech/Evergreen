// Learn topics: short, plain-language topics to read or listen to.
import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import { CATEGORIES, TOPICS } from '@/lib/learnTopics';
import { useSavedTopics } from '@/lib/useSavedTopics';
import LearnTopicCard from '@/components/learn/LearnTopicCard';
import {
  Heart, Pill, ShieldAlert, MonitorSmartphone, FileText, Smile, Home, Search, Info, Bookmark,
} from 'lucide-react';

const ICON = {
  healthy: Heart,
  medications: Pill,
  scams: ShieldAlert,
  technology: MonitorSmartphone,
  medicare: FileText,
  mental: Smile,
  homeSafety: Home,
};

const BAND = {
  sage: 'bg-earth-sage',
  terracotta: 'bg-earth-terracotta',
  navy: 'bg-earth-navy',
  lagoon: 'bg-earth-lagoon',
  plum: 'bg-earth-plum',
  marigold: 'bg-earth-marigold',
};

export default function Learn() {
  const { t, language } = useAppSettings();
  const [saved, toggleSaved] = useSavedTopics();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [savedOnly, setSavedOnly] = useState(false);

  const needle = query.trim().toLowerCase();

  const visible = TOPICS.filter((topic) => {
    const text = topic.text[language] || topic.text.en;
    const matchesQuery = !needle
      || text.title.toLowerCase().includes(needle)
      || text.summary.toLowerCase().includes(needle);
    const matchesCategory = category === 'all' || topic.category === category;
    const matchesSaved = !savedOnly || saved.includes(topic.id);
    return matchesQuery && matchesCategory && matchesSaved;
  });

  return (
    <div>
      <PageHeader title={t('learn')} description={t('healthTopicsDesc')} />

      <p className="mb-5 p-4 rounded-2xl bg-earth-marigold/15 border-2 border-earth-marigold/50 text-foreground flex items-start gap-3">
        <Info className="w-6 h-6 shrink-0 mt-0.5 text-earth-marigoldDark" strokeWidth={2.5} />
        <span className="font-semibold">{t('learnDisclaimer')}</span>
      </p>

      <div className="flex gap-2 mb-4">
        <div className="flex-1 relative">
          <Search className="w-6 h-6 absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" strokeWidth={2.5} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('learnSearchPlaceholder')}
            className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-input bg-card text-foreground focus:border-earth-navy outline-none text-lg min-h-[56px]"
          />
        </div>
        <button
          onClick={() => setSavedOnly(!savedOnly)}
          className={`flex items-center gap-2 px-4 rounded-xl border-2 font-bold transition min-h-[56px] ${
            savedOnly
              ? 'bg-earth-marigold/20 border-earth-marigold text-earth-marigoldDark'
              : 'bg-secondary border-border text-muted-foreground hover:border-earth-marigold'
          }`}
        >
          <Bookmark className="w-6 h-6" strokeWidth={2.5} />
          <span className="hidden sm:inline">{t('learnSavedOnly')}</span>
        </button>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        <button
          onClick={() => setCategory('all')}
          className={`px-4 py-3 rounded-2xl border-2 font-bold transition min-h-[56px] ${
            category === 'all'
              ? 'bg-earth-navy border-earth-navy text-white'
              : 'bg-secondary border-border text-foreground hover:border-earth-navy'
          }`}
        >
          {t('learnAll')}
        </button>
        {CATEGORIES.map((cat) => (
          <button
            key={cat.key}
            onClick={() => setCategory(cat.key)}
            className={`px-4 py-3 rounded-2xl border-2 font-bold transition min-h-[56px] ${
              category === cat.key
                ? 'bg-earth-navy border-earth-navy text-white'
                : 'bg-secondary border-border text-foreground hover:border-earth-navy'
            }`}
          >
            {t(cat.labelKey)}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <p className="text-center text-muted-foreground py-10">{t('learnNoResults')}</p>
      ) : (
        CATEGORIES.map((cat) => {
          const topics = visible.filter((topic) => topic.category === cat.key);
          if (topics.length === 0) return null;
          const Icon = ICON[cat.key];
          return (
            <section key={cat.key} className="mb-8">
              <div className={`${BAND[cat.tone]} rounded-2xl px-5 py-3 flex items-center gap-3 mb-4`}>
                <Icon className="w-6 h-6 text-white" strokeWidth={2.5} />
                <h2 className="font-heading text-xl text-white">{t(cat.labelKey)}</h2>
              </div>
              {topics.map((topic) => (
                <LearnTopicCard
                  key={topic.id}
                  topic={topic}
                  saved={saved.includes(topic.id)}
                  onToggleSave={toggleSaved}
                />
              ))}
            </section>
          );
        })
      )}
    </div>
  );
}