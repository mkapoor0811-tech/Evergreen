// Emergency profile: allergies, doctors and contacts, ready to show a paramedic.
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import ReadAloudButton from '@/components/ReadAloudButton';
import EmergencyProfileDetails from '@/components/emergency/EmergencyProfileDetails';
import { AlertTriangle, Info } from 'lucide-react';

export default function EmergencyProfile() {
  const { t } = useAppSettings();
  const [setting, setSetting] = useState(null);
  const [meds, setMeds] = useState([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    Promise.all([
      base44.entities.CaregiverSetting.list(),
      base44.entities.Medication.list('-created_date', 100),
    ])
      .then(([settings, medications]) => {
        setSetting(settings[0] || null);
        setMeds(medications);
      })
      .catch(() => {})
      .finally(() => setLoaded(true));
  }, []);

  const spoken = [
    t('emergencyProfileCaregiver'),
    setting?.caregiver_phone || t('emergencyProfileNoContacts'),
    t('emergencyProfileAllergies'),
    setting?.allergies || t('emergencyProfileNoAllergies'),
    t('emergencyProfileDoctor'),
    setting?.doctor_name || t('emergencyProfileNoDoctor'),
    t('emergencyProfileMeds'),
    meds.map((m) => `${m.name} ${m.dosage || ''}`).join(', ') || t('emergencyProfileNoMeds'),
  ].join('. ');

  if (!loaded) {
    return <div><PageHeader title={t('emergencyProfile')} description={t('emergencyProfileDesc')} /><p className="text-center text-muted-foreground py-8">{t('loading')}</p></div>;
  }

  return (
    <div>
      <PageHeader title={t('emergencyProfile')} description={t('emergencyProfileDesc')} />
      <ReadAloudButton text={spoken} />

      <div className="p-5 bg-earth-terracotta/10 border-2 border-earth-terracotta rounded-2xl flex items-start gap-3 mb-6">
        <AlertTriangle className="w-7 h-7 text-earth-terracottaDark shrink-0 mt-0.5" strokeWidth={2.25} />
        <p className="text-earth-terracottaDark font-semibold">{t('emergencyProfileDisclaimer')}</p>
      </div>

      <EmergencyProfileDetails setting={setting} meds={meds} showHealthSummary />

      <div className="mt-6 p-4 bg-card border border-border rounded-2xl flex items-start gap-3">
        <Info className="w-6 h-6 text-muted-foreground shrink-0 mt-0.5" />
        <p className="text-muted-foreground text-sm">{t('emergencyProfileHelp')}</p>
      </div>
    </div>
  );
}