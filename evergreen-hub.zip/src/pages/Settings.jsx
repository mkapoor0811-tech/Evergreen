// Settings: text size, language, high contrast, simple mode, voice mode and day times.
import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import SettingsRow from '@/components/settings/SettingsRow';
import ToggleRow from '@/components/settings/ToggleRow';
import MyDayTimes from '@/components/settings/MyDayTimes';
import DeleteAllData from '@/components/settings/DeleteAllData';

const SIZE_OPTIONS = [
  { key: 'medium', label: 'medium' },
  { key: 'large', label: 'large' },
  { key: 'xlarge', label: 'xlarge' },
];

const LANGUAGE_OPTIONS = [
  { key: 'en', label: 'english' },
  { key: 'es', label: 'spanish' },
  { key: 'hi', label: 'hindi' },
  { key: 'zh', label: 'chinese' },
  { key: 'tl', label: 'tagalog' },
  { key: 'vi', label: 'vietnamese' },
];

export default function Settings() {
  const { t, textSize, language, highContrast, voiceMode, updateSetting } = useAppSettings();

  return (
    <div>
      <PageHeader title={t('settings')} />

      <div className="space-y-3">
        <SettingsRow label={t('textSize')}>
          <div className="grid grid-cols-3 gap-2">
            {SIZE_OPTIONS.map((opt) => (
              <button
                key={opt.key}
                onClick={() => updateSetting('textSize', opt.key)}
                className={`py-4 rounded-xl border-2 font-bold transition min-h-[56px] ${
                  textSize === opt.key
                    ? 'bg-earth-navy border-earth-navy text-white'
                    : 'bg-card border-border text-foreground'
                }`}
              >
                {t(opt.label)}
              </button>
            ))}
          </div>
        </SettingsRow>

        <SettingsRow label={t('language')}>
          <select
            value={language}
            onChange={(e) => updateSetting('language', e.target.value)}
            className="w-full px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-navy outline-none text-xl font-bold min-h-[56px]"
          >
            {LANGUAGE_OPTIONS.map((opt) => (
              <option key={opt.key} value={opt.key}>{t(opt.label)}</option>
            ))}
          </select>
        </SettingsRow>

        <ToggleRow
          label={t('enableHighContrast')}
          on={highContrast}
          onToggle={() => updateSetting('highContrast', !highContrast)}
        />

        <ToggleRow
          label={t('readAloudAuto')}
          on={voiceMode}
          onToggle={() => updateSetting('voiceMode', !voiceMode)}
        />

        <SettingsRow label={t('myDayTitle')}>
          <MyDayTimes />
        </SettingsRow>

        <SettingsRow label={t('myPeopleTitle')} to="/family" />
        <SettingsRow label={t('aboutThisApp')} to="/about" />

        <DeleteAllData />
      </div>
    </div>
  );
}