// Daily Boost: a habit, word, quote, garden tip and reflection for today.
import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import WordOfTheDay from '@/components/dailyboost/WordOfTheDay';
import QuoteOfTheDay from '@/components/dailyboost/QuoteOfTheDay';
import GardenTip from '@/components/dailyboost/GardenTip';
import DailyFactsPanel from '@/components/dailyfact/DailyFactsPanel';
import DailyReflection from '@/components/dailyboost/DailyReflection';
import DailyHabit from '@/components/dailyboost/DailyHabit';
import ReadAloudButton from '@/components/ReadAloudButton';
import VoiceButton from '@/components/VoiceButton';
import { getWordsOfTheDay, getQuoteOfTheDay, getDailyHabits } from '@/lib/dailyContent';
import { readCustomTips, todayTip } from '@/lib/gardenTips';
import { BookOpen, Quote, Feather, Sparkles, Lightbulb, Sprout } from 'lucide-react';

export default function DailyBoost() {
  const { t, language } = useAppSettings();
  const [tab, setTab] = useState('word');

  const tabs = [
    { key: 'word', label: t('wordOfTheDay'), icon: BookOpen },
    { key: 'quote', label: t('quoteOfTheDay'), icon: Quote },
    { key: 'reflection', label: t('dailyReflection'), icon: Feather },
    { key: 'habit', label: t('dailyHabit'), icon: Sparkles },
    { key: 'fact', label: t('didYouKnow'), icon: Lightbulb },
    { key: 'gardenTip', label: t('gardenTip'), icon: Sprout },
  ];

  const spoken = (() => {
    if (tab === 'word') {
      const words = getWordsOfTheDay(language);
      return `${t('wordsOfTheDay')}. ` + words.map((w) => `${w.word}. ${w.definition}`).join('. ');
    }
    if (tab === 'quote') {
      const q = getQuoteOfTheDay(language);
      return `${t('quoteOfTheDay')}. ${q.text}${q.author ? '. ' + q.author : ''}`;
    }
    if (tab === 'habit') {
      return `${t('dailyHabit')}. ` + getDailyHabits(language).join('. ');
    }
    if (tab === 'gardenTip') {
      return `${t('gardenTip')}. ${todayTip(language, readCustomTips())}`;
    }
    return t('dailyBoost');
  })();

  return (
    <div>
      <PageHeader title={t('dailyBoost')} />
      <ReadAloudButton text={spoken} />
      <div className="mb-5">
        <VoiceButton
          label={t('addByVoice')}
          prompt={t('voiceDailyBoostPrompt')}
          onResult={(transcript) => {
            const lower = transcript.toLowerCase();
            if (lower.match(/word|palabra|शब्द|单词/)) setTab('word');
            else if (lower.match(/quote|frase|सुविचार|格言/)) setTab('quote');
            else if (lower.match(/reflect|reflexi|प्रतिबिंब|感悟/)) setTab('reflection');
            else if (lower.match(/habit|hábito|आदत|习惯/)) setTab('habit');
            else if (lower.match(/garden|jardín|बाग|花园|hardin|vườn/)) setTab('gardenTip');
          }}
        />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 mb-5">
        {tabs.map((tabItem) => {
          const Icon = tabItem.icon;
          const active = tab === tabItem.key;
          return (
            <button
              key={tabItem.key}
              onClick={() => setTab(tabItem.key)}
              className={`flex flex-col items-center gap-2 py-4 px-1 rounded-2xl border-2 transition min-h-[88px] ${active ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-slate-200 text-slate-700 hover:border-slate-400'}`}
            >
              <Icon className="w-7 h-7" strokeWidth={2.5} />
              <span className="text-sm font-bold text-center leading-tight">{tabItem.label}</span>
            </button>
          );
        })}
      </div>
      {tab === 'word' && <WordOfTheDay />}
      {tab === 'quote' && <QuoteOfTheDay />}
      {tab === 'reflection' && <DailyReflection />}
      {tab === 'habit' && <DailyHabit />}
      {tab === 'fact' && <DailyFactsPanel />}
      {tab === 'gardenTip' && <GardenTip />}
    </div>
  );
}