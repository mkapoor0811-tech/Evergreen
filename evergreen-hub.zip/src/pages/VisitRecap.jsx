// Writing up a visit: what the doctor said and what happens next.
import React, { useState, useEffect } from 'react';
import ActionButton from '@/components/ActionButton';
import { base44 } from '@/api/base44Client';
import { useParams, useNavigate } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import ReadAloudButton from '@/components/ReadAloudButton';
import RecapForm from '@/components/appointments/RecapForm';
import { LOCALES, formatShortDay } from '@/lib/timeFormat';
import { Check, Loader2 } from 'lucide-react';

/** Writing down what the doctor said, in the person's own words. */
export default function VisitRecap() {
  const { t, language } = useAppSettings();
  const { id } = useParams();
  const navigate = useNavigate();
  const [appt, setAppt] = useState(null);
  const [recap, setRecap] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    base44.entities.Appointment.get(id).then((a) => {
      setAppt(a);
      setRecap(a.recap || {});
    });
  }, [id]);

  const save = async () => {
    setSaving(true);
    await base44.entities.Appointment.update(id, { recap });
    setSaving(false);
    setSaved(true);
    setTimeout(() => navigate('/appointments'), 900);
  };

  if (!appt || !recap) {
    return <p className="text-center text-muted-foreground py-8">{t('loading')}</p>;
  }

  const locale = LOCALES[language] || 'en-US';
  const readAloud = [
    t('recapTitle'),
    recap.doctor_said,
    t('whatToDoNext'),
    recap.next_steps,
    t('recapNotAdvice'),
  ].filter(Boolean).join('. ');

  return (
    <div>
      <PageHeader title={t('recapTitle')} />
      <p className="text-2xl text-foreground mb-5">
        {appt.doctor_name} — {formatShortDay(appt.date, locale)}
      </p>

      <ReadAloudButton text={readAloud} />

      <RecapForm recap={recap} onChange={setRecap} />

      <ActionButton onClick={save} disabled={saving || saved} size="large" className="w-full mt-8 text-2xl">
        {saving ? <Loader2 className="w-7 h-7 animate-spin" /> : <Check className="w-7 h-7" strokeWidth={3} />}
        {saved ? t('saved') : t('save')}
      </ActionButton>
    </div>
  );
}