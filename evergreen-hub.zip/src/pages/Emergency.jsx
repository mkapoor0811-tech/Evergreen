// The red emergency screen: call for help, and tell family where you are.
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { getEmergencyContacts, getEmergencyNumber, telHref } from '@/lib/emergency';
import TellFamilyButton from '@/components/emergency/TellFamilyButton';
import EmergencyProfileDetails from '@/components/emergency/EmergencyProfileDetails';
import { AlertTriangle, PhoneCall, Phone, Heart, X, Loader2 } from 'lucide-react';

export default function Emergency() {
  const { t } = useAppSettings();
  const navigate = useNavigate();
  const [config, setConfig] = useState(null);
  const [meds, setMeds] = useState([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    Promise.all([
      base44.entities.CaregiverSetting.list().catch(() => []),
      base44.entities.Medication.list('-created_date', 100).catch(() => []),
    ]).then(([settings, medications]) => {
      setConfig(settings[0] || null);
      setMeds(medications);
    }).finally(() => setLoaded(true));
  }, []);

  const emergencyNumber = getEmergencyNumber(config);
  const contacts = getEmergencyContacts(config);

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-destructive shadow-md">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
          <AlertTriangle className="w-9 h-9 text-white shrink-0" strokeWidth={2.5} />
          <h1 className="font-heading text-2xl text-white flex-1">{t('emergency')}</h1>
          <button
            onClick={() => navigate('/')}
            aria-label={t('emergencyClose')}
            className="shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold transition min-h-[56px]"
          >
            <X className="w-6 h-6" strokeWidth={3} />
            <span className="hidden sm:inline">{t('emergencyClose')}</span>
          </button>
        </div>
      </header>

      <div className="max-w-3xl mx-auto w-full px-4 pt-6 pb-24">
        <p className="p-5 mb-6 rounded-2xl bg-earth-marigold/20 border-2 border-earth-marigold/60 text-xl font-semibold text-foreground leading-snug">
          {t('emergencyNote')}
        </p>

        <a
          href={telHref(emergencyNumber)}
          className="w-full flex items-center justify-center gap-3 bg-destructive hover:bg-destructive/90 text-white font-bold py-7 rounded-2xl text-2xl transition min-h-[96px] mb-4"
        >
          <PhoneCall className="w-9 h-9" strokeWidth={2.5} />
          {t('emergencyCallServices')}
        </a>

        {contacts.map((c) => (
          <a
            key={c.key}
            href={telHref(c.phone)}
            className="w-full flex items-center justify-center gap-3 bg-earth-navy hover:bg-earth-navyDark text-white font-bold py-6 rounded-2xl text-2xl transition min-h-[84px] mb-4"
          >
            <Phone className="w-8 h-8" strokeWidth={2.5} />
            {c.name ? `${t('emergencyCallName')} ${c.name}` : t('callMyFamily')}
          </a>
        ))}

        {loaded && contacts.length === 0 && (
          <p className="mb-4 p-5 rounded-2xl border-2 border-dashed border-earth-navy bg-card text-xl font-semibold text-foreground">
            {t('emergencyNoContacts')}
          </p>
        )}

        <div className="mb-4">
          <TellFamilyButton allowLocation={!!config?.allow_location} />
          <p className="mt-2 text-lg text-muted-foreground">{t('emergencyTellFamilyHelp')}</p>
        </div>

        <button
          onClick={() => navigate('/')}
          className="w-full flex items-center justify-center gap-3 border-2 border-earth-sage text-earth-sageDark bg-card hover:bg-earth-sage/10 font-bold py-6 rounded-2xl text-2xl transition min-h-[84px] mb-10"
        >
          <Heart className="w-8 h-8" strokeWidth={2.5} />
          {t('emergencyImOkay')}
        </button>

        <h2 className="font-heading text-3xl text-foreground mb-6">{t('emergencyYourProfile')}</h2>

        {!loaded ? (
          <p className="flex items-center gap-3 text-muted-foreground text-xl">
            <Loader2 className="w-6 h-6 animate-spin" />
            {t('loading')}
          </p>
        ) : (
          <EmergencyProfileDetails setting={config} meds={meds} />
        )}
      </div>
    </div>
  );
}