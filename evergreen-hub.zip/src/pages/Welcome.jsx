// The first screen: the app's name, the tagline and a Start button.
import React, { useState } from 'react';
import ActionButton from '@/components/ActionButton';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import ReadAloudButton from '@/components/ReadAloudButton';
import { Heart, Type, Users, Check, Loader2 } from 'lucide-react';

const STEPS = [
  { icon: Heart, tone: 'bg-earth-terracotta', title: 'welcome1Title', body: 'welcome1Body' },
  { icon: Type, tone: 'bg-earth-lagoon', title: 'welcome2Title', body: 'welcome2Body' },
  { icon: Users, tone: 'bg-earth-sage', title: 'welcome3Title', body: 'welcome3Body' },
];

const SIZE_OPTIONS = [
  { key: 'medium', label: 'medium', sample: 'text-xl' },
  { key: 'large', label: 'large', sample: 'text-2xl' },
  { key: 'xlarge', label: 'xlarge', sample: 'text-3xl' },
];

const LANG_OPTIONS = [
  { key: 'en', label: 'english' },
  { key: 'es', label: 'spanish' },
  { key: 'hi', label: 'hindi' },
  { key: 'zh', label: 'chinese' },
];

const inputClass =
  'w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-navy outline-none text-lg';

export default function Welcome() {
  const { t, textSize, language, updateSetting } = useAppSettings();
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [saving, setSaving] = useState(false);

  const current = STEPS[step];
  const Icon = current.icon;
  const isLast = step === STEPS.length - 1;

  const finish = () => {
    localStorage.setItem('mahika_welcomeDone', 'true');
    window.location.href = '/';
  };

  const saveContactAndFinish = async () => {
    setSaving(true);
    try {
      const payload = {
        caregiver_email: email.trim(),
        caregiver_phone: phone.trim(),
        timezone_offset: new Date().getTimezoneOffset(),
      };
      const existing = await base44.entities.CaregiverSetting.list();
      if (existing.length > 0) await base44.entities.CaregiverSetting.update(existing[0].id, payload);
      else await base44.entities.CaregiverSetting.create(payload);
      if (phone.trim()) localStorage.setItem('mahika_caregiver_phone', phone.trim());
    } catch (e) {
      /* the contact is optional here; the welcome still finishes */
    }
    setSaving(false);
    finish();
  };

  const next = () => {
    if (isLast) saveContactAndFinish();
    else setStep(step + 1);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="max-w-lg w-full mx-auto p-6 flex-1 flex flex-col">
        <div className="text-center mb-6">
          <p className="font-heading text-3xl text-foreground leading-tight">{t('appName')}</p>
          <p className="text-muted-foreground font-semibold mt-1">{t('tagline')}</p>
        </div>

        <div className="flex items-center justify-between gap-4 mb-6">
          <p className="text-muted-foreground font-semibold">
            {t('welcomeStep').replace('{n}', String(step + 1))}
          </p>
          <button
            onClick={finish}
            className="px-6 py-3 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
          >
            {t('welcomeSkip')}
          </button>
        </div>

        <div className="flex items-center justify-center gap-2 mb-8">
          {STEPS.map((_, i) => (
            <span
              key={i}
              className={`h-3 rounded-full transition-all ${
                i === step ? 'w-10 bg-earth-navy' : i < step ? 'w-3 bg-earth-navy/50' : 'w-3 bg-border'
              }`}
            />
          ))}
        </div>

        <div className="flex-1">
          <div className={`w-20 h-20 blob ${current.tone} flex items-center justify-center mb-6`}>
            <Icon className="w-10 h-10 text-white" strokeWidth={2.25} />
          </div>

          <h1 className="font-heading text-4xl text-foreground mb-4 leading-tight">{t(current.title)}</h1>
          <p className="text-xl text-muted-foreground leading-relaxed mb-6">{t(current.body)}</p>

          <ReadAloudButton text={`${t(current.title)}. ${t(current.body)}`} />

          {step === 1 && (
            <div className="space-y-6">
              <div>
                <h2 className="font-heading text-2xl text-foreground mb-3">{t('textSize')}</h2>
                <div className="grid grid-cols-3 gap-3">
                  {SIZE_OPTIONS.map((opt) => (
                    <button
                      key={opt.key}
                      onClick={() => updateSetting('textSize', opt.key)}
                      className={`p-4 rounded-2xl border-2 transition flex flex-col items-center gap-2 min-h-[96px] ${
                        textSize === opt.key
                          ? 'bg-earth-navy border-earth-navy text-white'
                          : 'bg-card border-border hover:border-earth-navy text-foreground'
                      }`}
                    >
                      <span className={`font-bold ${opt.sample}`}>Aa</span>
                      <span className="font-semibold">{t(opt.label)}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="font-heading text-2xl text-foreground mb-3">{t('language')}</h2>
                <div className="grid grid-cols-2 gap-3">
                  {LANG_OPTIONS.map((opt) => (
                    <button
                      key={opt.key}
                      onClick={() => updateSetting('language', opt.key)}
                      className={`p-4 rounded-2xl border-2 transition flex items-center justify-center gap-2 min-h-[64px] ${
                        language === opt.key
                          ? 'bg-earth-navy border-earth-navy text-white'
                          : 'bg-card border-border hover:border-earth-navy text-foreground'
                      }`}
                    >
                      {language === opt.key && <Check className="w-6 h-6" strokeWidth={3} />}
                      <span className="text-lg font-bold">{t(opt.label)}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="block font-bold text-foreground mb-1">{t('contactName')}</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={inputClass}
                />
              </div>
              <div>
                <label className="block font-bold text-foreground mb-1">{t('contactPhone')}</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={inputClass}
                />
              </div>
              <div>
                <label className="block font-bold text-foreground mb-1">{t('contactEmail')}</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={inputClass}
                />
              </div>
            </div>
          )}
        </div>

        <ActionButton onClick={next} disabled={saving} size="large" className="w-full mt-8 text-xl">
          {saving ? <Loader2 className="w-7 h-7 animate-spin" /> : null}
          {isLast ? t('welcomeStart') : t('welcomeNext')}
        </ActionButton>
      </div>
    </div>
  );
}