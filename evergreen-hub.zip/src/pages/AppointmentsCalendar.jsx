// My Visits: a month view of every appointment.
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import AppointmentCalendar from '@/components/appointments/AppointmentCalendar';

const iso = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export default function AppointmentsCalendar() {
  const { t } = useAppSettings();
  const [appts, setAppts] = useState(null);

  useEffect(() => {
    const from = new Date();
    from.setFullYear(from.getFullYear() - 1);
    const to = new Date();
    to.setFullYear(to.getFullYear() + 1);

    base44.entities.Appointment
      .filter({ date: { $gte: iso(from), $lte: iso(to) } }, { sort: 'date', limit: 300 })
      .then(({ items }) => setAppts(items));
  }, []);

  return (
    <div className="max-w-2xl mx-auto">
      <PageHeader title={t('calendar')} />
      {appts === null ? (
        <p className="text-center text-muted-foreground py-8">{t('loading')}</p>
      ) : (
        <AppointmentCalendar appts={appts} />
      )}
    </div>
  );
}