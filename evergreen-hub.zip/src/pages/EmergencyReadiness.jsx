// Emergency readiness: what to do in a power cut, with a checklist and tips.
import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import ReadAloudButton from '@/components/ReadAloudButton';
import ReadinessChecklist from '@/components/readiness/ReadinessChecklist';
import ReadinessTips from '@/components/readiness/ReadinessTips';
import PowerOutGuide from '@/components/readiness/PowerOutGuide';
import { CHECKLIST, HEAT_TIPS, COLD_TIPS, POWER_OUT, pickContent } from '@/lib/readinessContent';

export default function EmergencyReadiness() {
  const { t, language } = useAppSettings();
  const [checks, setChecks] = useState([]);

  const load = useCallback(async () => {
    const list = await base44.entities.ReadinessCheck.list('-created_date', 100);
    setChecks(list);
  }, []);

  useEffect(() => { load(); }, [load]);

  const items = pickContent(CHECKLIST, language);
  const doneKeys = new Set(checks.filter((c) => c.done).map((c) => c.item_key));
  const doneCount = items.filter((item) => doneKeys.has(item.key)).length;

  const toggle = async (item) => {
    const existing = checks.find((c) => c.item_key === item.key);
    if (existing) {
      await base44.entities.ReadinessCheck.update(existing.id, { done: !existing.done });
    } else {
      await base44.entities.ReadinessCheck.create({ item_key: item.key, done: true });
    }
    await load();
  };

  const intro = `${t('readiness')}. ${t('readinessDesc')}. ${t('readyChecklist')}. ${doneCount} ${t('readyOf')} ${items.length}.`;

  return (
    <div>
      <PageHeader title={t('readiness')} />
      <ReadAloudButton text={intro} />

      <p className="text-muted-foreground font-semibold mb-5">{t('readinessDesc')}</p>

      <ReadinessChecklist items={items} doneKeys={doneKeys} doneCount={doneCount} onToggle={toggle} />

      <ReadinessTips title={t('heatTips')} tips={pickContent(HEAT_TIPS, language)} tone="marigold" />
      <ReadinessTips title={t('coldTips')} tips={pickContent(COLD_TIPS, language)} tone="lagoon" />
      <PowerOutGuide steps={pickContent(POWER_OUT, language)} />
    </div>
  );
}