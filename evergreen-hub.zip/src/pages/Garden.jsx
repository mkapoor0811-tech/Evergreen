// Garden: a gentle garden tip for today, and the tips done so far.
import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import GardenTip from '@/components/dailyboost/GardenTip';

/** A garden tip for each day, plus room to add your own. */
export default function Garden() {
  const { t } = useAppSettings();

  return (
    <div>
      <PageHeader title={t('gardenTipsTitle')} description={t('gardenTipsDesc')} />
      <p className="text-muted-foreground font-semibold mb-5">{t('gardenTipsIntro')}</p>
      <GardenTip />
    </div>
  );
}