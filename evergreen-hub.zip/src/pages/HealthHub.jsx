// Health hub: the same panel-and-row layout as the Learn tab. Two panels group
// the five screens — your care first, then food and movement. Each row keeps the
// colour of the part of the app it opens.
import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import HubSection from '@/components/hub/HubSection';
import HubRow from '@/components/hub/HubRow';
import { Pill, Calendar, Utensils, Dumbbell, ShoppingCart } from 'lucide-react';

const CARE_ROWS = [
  { to: '/medications', icon: Pill, titleKey: 'medications', descKey: 'tileMedsSub', hex: '#38598A' },
  { to: '/appointments', icon: Calendar, titleKey: 'appointments', descKey: 'tileApptsSub', hex: '#6A4C88' },
];

const FOOD_ROWS = [
  { to: '/diet', icon: Utensils, titleKey: 'diet', descKey: 'tileDietSub', hex: '#507C52' },
  { to: '/exercise', icon: Dumbbell, titleKey: 'exercise', descKey: 'tileExerciseSub', hex: '#A8650A' },
  { to: '/groceries', icon: ShoppingCart, titleKey: 'groceries', descKey: 'groceriesDesc', hex: '#2F5F5B' },
];

export default function HealthHub() {
  const { t } = useAppSettings();

  return (
    <div>
      <PageHeader title={t('healthHubTitle')} description={t('healthHubDesc')} />

      <HubSection title={t('hubCareTitle')} hex="#38598A">
        {CARE_ROWS.map(({ to, icon, titleKey, descKey, hex }) => (
          <HubRow key={to} to={to} icon={icon} hex={hex} title={t(titleKey)} description={t(descKey)} />
        ))}
      </HubSection>

      <HubSection title={t('hubFoodTitle')} hex="#507C52">
        {FOOD_ROWS.map(({ to, icon, titleKey, descKey, hex }) => (
          <HubRow key={to} to={to} icon={icon} hex={hex} title={t(titleKey)} description={t(descKey)} />
        ))}
      </HubSection>
    </div>
  );
}