// About screen: what the app is, who it is for, and the illustration credits.
import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import ReadAloudButton from '@/components/ReadAloudButton';
import AboutSection from '@/components/about/AboutSection';
import { Sunrise, CalendarDays, ShieldAlert, Moon, AlertTriangle, Bell, Info, ExternalLink } from 'lucide-react';

const WHO_URL = 'https://www.who.int/news-room/fact-sheets/detail/ageing-and-health';

const DAY = [
  { key: 'aboutDayMorning', body: 'aboutDayMorningBody', icon: Sunrise },
  { key: 'aboutDayDaytime', body: 'aboutDayDaytimeBody', icon: CalendarDays },
  { key: 'aboutDayAnyTime', body: 'aboutDayAnyTimeBody', icon: ShieldAlert },
  { key: 'aboutDayEvening', body: 'aboutDayEveningBody', icon: Moon },
];

const SAFE = [
  { key: 'aboutSafeEmergency', body: 'aboutSafeEmergencyBody', icon: AlertTriangle },
  { key: 'aboutSafeScam', body: 'aboutSafeScamBody', icon: ShieldAlert },
  { key: 'aboutSafeAlerts', body: 'aboutSafeAlertsBody', icon: Bell },
];

const INFO_KEYS = ['aboutInfo1', 'aboutInfo2', 'aboutInfo3', 'aboutInfo4'];

export default function About() {
  const { t } = useAppSettings();

  const spoken = [
    t('aboutTagline'),
    t('aboutWhatTitle'), t('aboutWhatBody'),
    t('aboutDayTitle'), ...DAY.flatMap((d) => [t(d.key), t(d.body)]),
    t('aboutSafeTitle'), ...SAFE.flatMap((s) => [t(s.key), t(s.body)]),
    t('aboutInfoTitle'), ...INFO_KEYS.map((k) => t(k)),
    t('aboutWhyTitle'), t('whyTagline'), t('whyNeed'), t('whyDoes'), t('whyMatters'), t('whySmallPrint'), t('aboutWhySource'),
    t('aboutLimitsTitle'), t('aboutLimitsBody'),
  ].join('. ');

  const rows = (items) => (
    <div className="space-y-4">
      {items.map(({ key, body, icon: Icon }) => (
        <div key={key} className="flex items-start gap-4 p-5 rounded-2xl bg-card border-2 border-border">
          <span className="w-14 h-14 blob bg-earth-lagoon/12 text-earth-lagoon flex items-center justify-center shrink-0">
            <Icon className="w-7 h-7" strokeWidth={2.25} />
          </span>
          <div className="min-w-0">
            <p className="font-heading text-xl text-foreground">{t(key)}</p>
            <p className="text-xl text-foreground leading-snug">{t(body)}</p>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="max-w-2xl">
      <PageHeader title={t('about')} />
      <ReadAloudButton text={spoken} />

      <p className="font-heading text-3xl text-foreground leading-snug mb-8">{t('aboutTagline')}</p>

      <AboutSection tone="bg-earth-terracotta" title={t('aboutWhatTitle')}>
        <p className="text-xl text-foreground leading-relaxed">{t('aboutWhatBody')}</p>
      </AboutSection>

      <AboutSection tone="bg-earth-marigold" title={t('aboutDayTitle')}>
        {rows(DAY)}
      </AboutSection>

      <AboutSection tone="bg-earth-navy" title={t('aboutSafeTitle')}>
        {rows(SAFE)}
      </AboutSection>

      <AboutSection tone="bg-earth-lagoon" title={t('aboutInfoTitle')}>
        <ul className="space-y-3">
          {INFO_KEYS.map((key) => (
            <li key={key} className="flex items-start gap-3 text-xl text-foreground leading-snug">
              <span className="w-3 h-3 rounded-full bg-earth-lagoon shrink-0 mt-3" />
              {t(key)}
            </li>
          ))}
        </ul>
      </AboutSection>

      <AboutSection tone="bg-earth-plum" title={t('aboutWhyTitle')}>
        <p className="font-bold text-2xl text-foreground leading-snug mb-3">{t('whyTagline')}</p>
        <p className="text-xl text-foreground leading-snug mb-3">{t('whyNeed')}</p>
        <p className="text-xl text-foreground leading-snug mb-3">{t('whyDoes')}</p>
        <p className="text-xl text-foreground leading-snug mb-3">{t('whyMatters')}</p>
        <p className="text-lg text-foreground leading-snug mb-3">{t('whySmallPrint')}</p>
        <a
          href={WHO_URL}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-3 px-5 py-4 rounded-xl bg-card border-2 border-earth-plum text-earth-plum font-bold transition hover:bg-earth-plum/10 min-h-[56px]"
        >
          <ExternalLink className="w-6 h-6 shrink-0" strokeWidth={2.25} />
          {t('aboutWhyLink')}
        </a>
        <p className="text-lg text-muted-foreground">{t('aboutWhySource')}</p>
      </AboutSection>

      <AboutSection tone="bg-earth-terracotta" title={t('aboutLimitsTitle')}>
        <div className="flex items-start gap-4 p-5 rounded-2xl bg-earth-marigold/15 border-2 border-earth-marigold/60">
          <Info className="w-8 h-8 text-earth-marigoldDark shrink-0 mt-0.5" strokeWidth={2.25} />
          <p className="text-xl text-foreground font-semibold leading-snug">{t('aboutLimitsBody')}</p>
        </div>
      </AboutSection>

      <AboutSection tone="bg-earth-sage" title={t('creditsTitle')}>
        <a
          href="https://storyset.com"
          target="_blank"
          rel="noreferrer"
          className="inline-block text-lg font-semibold text-foreground underline"
        >
          {t('creditsIllustrations')}
        </a>
      </AboutSection>

      <div className="mt-10 pt-6 border-t-2 border-border text-center">
        <p className="font-heading text-2xl text-foreground">{t('appName')}</p>
        <p className="text-muted-foreground font-semibold mt-1">{t('tagline')}</p>
      </div>
    </div>
  );
}