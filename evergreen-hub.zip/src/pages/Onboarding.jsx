// Onboarding: a few questions that set the app up for this person.
import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { Briefcase, Heart, Users, MapPin, Check } from 'lucide-react';

export default function Onboarding() {
  const { t, language } = useAppSettings();
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState({ career: '', hobbies: '', family_info: '', hometown: '' });
  const [saving, setSaving] = useState(false);

  const questions = [
    { key: 'career', icon: Briefcase, label: t('onboardingCareer'), placeholder: t('onboardingCareerPlaceholder') },
    { key: 'hobbies', icon: Heart, label: t('onboardingHobbies'), placeholder: t('onboardingHobbiesPlaceholder') },
    { key: 'family_info', icon: Users, label: t('onboardingFamily'), placeholder: t('onboardingFamilyPlaceholder') },
    { key: 'hometown', icon: MapPin, label: t('onboardingHometown'), placeholder: t('onboardingHometownPlaceholder') },
  ];

  const current = questions[step];
  const isLast = step === questions.length - 1;
  const Icon = current.icon;

  const finish = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe({
        career: profile.career.trim(),
        hobbies: profile.hobbies.trim(),
        family_info: profile.family_info.trim(),
        hometown: profile.hometown.trim(),
        onboarded: true,
      });
    } finally {
      setSaving(false);
      window.location.href = '/';
    }
  };

  const next = () => {
    if (isLast) {
      finish();
    } else {
      setStep(step + 1);
    }
  };

  const skip = () => {
    if (isLast) {
      finish();
    } else {
      setStep(step + 1);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
      <div className="max-w-lg w-full">
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-2xl bg-indigo-600 flex items-center justify-center mx-auto mb-4">
            <Heart className="w-10 h-10 text-white" strokeWidth={2.5} />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">{t('onboardingTitle')}</h1>
          <p className="text-lg text-slate-600">{t('onboardingSubtitle')}</p>
        </div>

        {/* Progress dots */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {questions.map((_, i) => (
            <div
              key={i}
              className={`h-3 rounded-full transition-all ${i === step ? 'w-8 bg-indigo-600' : i < step ? 'w-3 bg-indigo-400' : 'w-3 bg-slate-300'}`}
            />
          ))}
        </div>

        <div className="bg-white rounded-2xl border-2 border-slate-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 rounded-xl bg-indigo-100 flex items-center justify-center">
              <Icon className="w-8 h-8 text-indigo-600" strokeWidth={2.5} />
            </div>
            <h2 className="text-xl font-bold text-slate-900">{current.label}</h2>
          </div>
          <textarea
            value={profile[current.key]}
            onChange={(e) => setProfile({ ...profile, [current.key]: e.target.value })}
            placeholder={current.placeholder}
            rows={3}
            autoFocus
            className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 focus:border-indigo-500 outline-none text-lg resize-none"
          />
          <div className="flex gap-3 mt-5">
            <button
              onClick={skip}
              className="px-6 py-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold transition min-h-[56px]"
            >
              {t('onboardingSkip')}
            </button>
            <button
              onClick={next}
              disabled={saving}
              className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl transition min-h-[56px] disabled:opacity-50 text-lg"
            >
              {saving ? <Check className="w-6 h-6 animate-spin" /> : null}
              {isLast ? t('onboardingFinish') : t('next')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}