// My People: emergency contacts and the family or caregiver contacts.
import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import SectionCard from '@/components/SectionCard';
import ContactList from '@/components/people/ContactList';
import usePeopleConfig from '@/lib/usePeopleConfig';

/** "My people": emergency contacts, and family and caregivers. */
export default function FamilyHub() {
  const { t } = useAppSettings();
  const { config, loading, save } = usePeopleConfig();

  return (
    <div>
      <PageHeader title={t('myPeopleTitle')} description={t('myPeopleDesc')} />

      {loading ? (
        <div className="h-16 rounded-3xl bg-secondary animate-pulse" />
      ) : (
        <>
          <SectionCard title={t('emergencyContactsTitle')} color="family">
            <ContactList
              contacts={config.emergency_contacts}
              onChange={(list) => save({ emergency_contacts: list })}
              kind="emergency"
              addLabel={t('addContact')}
            />
          </SectionCard>

          <SectionCard title={t('familyCaregiversTitle')} color="family">
            <ContactList
              contacts={config.secondary_contacts}
              onChange={(list) => save({ secondary_contacts: list })}
              kind="caregiver"
              addLabel={t('addPersonLabel')}
            />
          </SectionCard>
        </>
      )}
    </div>
  );
}