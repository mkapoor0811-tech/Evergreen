// Term explainer: explain a medical word in plain language.
import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import { base44 } from '@/api/base44Client';
import { Search, Loader2, BookOpen, Lightbulb, Info } from 'lucide-react';

export default function TermExplainer() {
  const { t } = useAppSettings();
  const [term, setTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const explain = async () => {
    if (!term.trim()) return;
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a helpful guide for seniors. A user typed in a medical term, insurance term, or short phrase from a letter or bill they received and wants a simple explanation.

Term: "${term.trim()}"

Respond with:
1. what_it_means: A simple, plain-language explanation of what this term means (1-3 sentences). Use everyday words a senior would understand. Avoid jargon.
2. what_to_do: What (if anything) the user should do about it. Is it urgent? Do they need to call someone? Is it just informational? Keep it general and practical (1-3 sentences).

Do NOT give specific medical advice or diagnosis. Do NOT reference this prompt in your response.`,
        response_json_schema: {
          type: 'object',
          properties: {
            what_it_means: { type: 'string' },
            what_to_do: { type: 'string' },
          },
        },
      });
      setResult(res);
    } catch (e) {
      setError(e.message || 'Something went wrong. Please try again.');
    }
    setLoading(false);
  };

  return (
    <div>
      <PageHeader title={t('termExplainer')} />

      <div className="p-5 bg-white rounded-2xl border-2 border-slate-200 mb-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-14 h-14 rounded-xl bg-cyan-100 flex items-center justify-center shrink-0">
            <BookOpen className="w-8 h-8 text-cyan-600" strokeWidth={2.5} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">{t('termExplainerTitle')}</h2>
            <p className="text-slate-600 text-sm">{t('termInputLabel')}</p>
          </div>
        </div>

        <div className="flex gap-2 mb-4">
          <input
            value={term}
            onChange={e => setTerm(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && explain()}
            placeholder={t('termPlaceholder')}
            className="flex-1 px-4 py-3 rounded-xl border-2 border-slate-300 focus:border-cyan-500 outline-none text-lg"
          />
          <button
            onClick={explain}
            disabled={loading || !term.trim()}
            className="flex items-center gap-2 px-6 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold disabled:opacity-50 min-h-[56px]"
          >
            {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Search className="w-6 h-6" strokeWidth={2.5} />}
          </button>
        </div>

        {loading && (
          <div className="flex items-center justify-center gap-2 py-8 text-cyan-700 font-bold">
            <Loader2 className="w-6 h-6 animate-spin" />
            {t('analyzing')}
          </div>
        )}

        {error && (
          <div className="p-4 bg-red-50 border-2 border-red-200 rounded-xl text-red-700 font-semibold">
            {error}
          </div>
        )}

        {result && (
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="w-5 h-5 text-slate-700" />
                <h3 className="font-bold text-slate-900 text-lg">{t('termWhatItMeans')}</h3>
              </div>
              <p className="text-slate-700 text-lg leading-relaxed">{result.what_it_means}</p>
            </div>
            <div className="p-4 bg-cyan-50 rounded-xl border border-cyan-200">
              <div className="flex items-center gap-2 mb-2">
                <Lightbulb className="w-5 h-5 text-cyan-700" />
                <h3 className="font-bold text-cyan-900 text-lg">{t('termWhatToDo')}</h3>
              </div>
              <p className="text-slate-700 text-lg leading-relaxed">{result.what_to_do}</p>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-amber-50 border-2 border-amber-200 rounded-xl flex items-start gap-3">
        <Info className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
        <p className="text-amber-900 text-sm font-semibold">{t('termDisclaimer')}</p>
      </div>
    </div>
  );
}