// Guided breathing: a circle that grows on the in-breath and shrinks on the out-breath.
import React, { useState } from 'react';
import ActionButton from '@/components/ActionButton';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import Illustration from '@/components/Illustration';
import { ILLUSTRATIONS } from '@/lib/illustrations';
import BreathingCircle from '@/components/breathe/BreathingCircle';
import ReadAloudButton from '@/components/ReadAloudButton';
import { Heart, Play, Square, RotateCcw } from 'lucide-react';

const OPTIONS = [
  { minutes: 1, key: 'oneMinute' },
  { minutes: 3, key: 'threeMinutes' },
  { minutes: 5, key: 'fiveMinutes' },
];

export default function Breathe() {
  const { t } = useAppSettings();
  const [minutes, setMinutes] = useState(null);
  const [running, setRunning] = useState(false);
  const [finished, setFinished] = useState(false);

  const start = (value) => {
    setMinutes(value);
    setFinished(false);
    setRunning(true);
  };

  const stop = () => {
    setRunning(false);
    setFinished(false);
    setMinutes(null);
  };

  if (finished) {
    return (
      <div>
        <PageHeader title={t('breathe')} description={t('breatheDesc')} />
        <div className="rounded-3xl bg-card border-2 border-border p-8 text-center">
          <div className="w-32 h-32 mx-auto mb-6 blob bg-earth-sage/25 flex items-center justify-center">
            <Heart className="w-16 h-16 text-earth-sageDark" strokeWidth={2} />
          </div>
          <p className="font-heading text-3xl text-foreground mb-4">{t('breatheDone')}</p>
          <ReadAloudButton text={t('breatheDone')} />
          <ActionButton onClick={() => start(minutes)} className="w-full mb-3">
            <RotateCcw className="w-6 h-6" strokeWidth={2.5} />
            {t('breatheAgain')}
          </ActionButton>
          <ActionButton variant="secondary" onClick={stop} className="w-full">
            {t('back')}
          </ActionButton>
        </div>
      </div>
    );
  }

  if (running) {
    return (
      <div>
        <PageHeader title={t('breathe')} description={t('breatheDesc')} />
        <div className="rounded-3xl bg-card border-2 border-border overflow-hidden">
          <BreathingCircle
            minutes={minutes}
            onFinished={() => { setRunning(false); setFinished(true); }}
          />
          <div className="p-5 pt-0">
            <button
              onClick={stop}
              className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
            >
              <Square className="w-6 h-6" strokeWidth={2.5} />
              {t('breatheStop')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title={t('breathe')} description={t('breatheDesc')} />

      <Illustration src={ILLUSTRATIONS.relax} alt={t('illRelaxAlt')} />

      <div className="rounded-3xl bg-card border-2 border-border p-6 mb-6">
        <p className="font-heading text-2xl text-foreground mb-4">{t('breatheReady')}</p>
        <ReadAloudButton text={`${t('breathe')}. ${t('breatheReady')}`} />

        <p className="font-bold text-foreground mb-3">{t('breatheChoose')}</p>
        <div className="grid grid-cols-3 gap-3 mb-5">
          {OPTIONS.map((opt) => (
            <button
              key={opt.minutes}
              onClick={() => start(opt.minutes)}
              className="flex flex-col items-center justify-center gap-2 py-6 rounded-2xl bg-earth-lagoon/12 border-2 border-earth-lagoon/40 text-earth-lagoonDark font-bold text-xl hover:bg-earth-lagoon/20 transition min-h-[96px]"
            >
              <Play className="w-8 h-8" strokeWidth={2.5} />
              {t(opt.key)}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}