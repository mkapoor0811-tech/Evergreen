// Health summary: one page about medicines, visits and how things have been, to show a doctor.
import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import { generateHealthSummaryPDF } from '@/lib/healthSummary';
import { FileText, Download, Loader2, CheckCircle, Info } from 'lucide-react';

export default function HealthSummary() {
  const { t } = useAppSettings();
  const [generating, setGenerating] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  const handleExport = async () => {
    setGenerating(true);
    setError('');
    setDone(false);
    try {
      await generateHealthSummaryPDF();
      setDone(true);
    } catch (e) {
      setError(e.message || 'Failed to generate PDF');
    }
    setGenerating(false);
  };

  return (
    <div>
      <PageHeader title={t('healthSummary')} description={t('healthSummaryCardDesc')} />
      <div className="p-5 bg-white rounded-2xl border-2 border-slate-200 mb-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-14 h-14 rounded-xl bg-blue-100 flex items-center justify-center shrink-0">
            <FileText className="w-8 h-8 text-blue-600" strokeWidth={2.5} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">{t('healthSummaryTitle')}</h2>
            <p className="text-slate-600">{t('healthSummaryDesc')}</p>
          </div>
        </div>

        <div className="space-y-2 mb-5">
          <p className="font-bold text-slate-700 mb-2">{t('healthSummaryIncludes')}</p>
          <ul className="space-y-1 text-slate-600">
            <li className="flex items-center gap-2"><CheckCircle className="w-5 h-5 text-green-600 shrink-0" /> {t('healthSummaryMeds')}</li>
            <li className="flex items-center gap-2"><CheckCircle className="w-5 h-5 text-green-600 shrink-0" /> {t('healthSummaryAppts')}</li>
            <li className="flex items-center gap-2"><CheckCircle className="w-5 h-5 text-green-600 shrink-0" /> {t('healthSummaryCheckIns')}</li>
            <li className="flex items-center gap-2"><CheckCircle className="w-5 h-5 text-green-600 shrink-0" /> {t('healthSummaryExercise')}</li>
            <li className="flex items-center gap-2"><CheckCircle className="w-5 h-5 text-green-600 shrink-0" /> {t('healthSummaryDiet')}</li>
          </ul>
        </div>

        <button
          onClick={handleExport}
          disabled={generating}
          className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl transition min-h-[56px] disabled:opacity-50"
        >
          {generating ? (
            <><Loader2 className="w-6 h-6 animate-spin" /> {t('healthSummaryGenerating')}</>
          ) : (
            <><Download className="w-6 h-6" strokeWidth={2.5} /> {t('healthSummaryDownload')}</>
          )}
        </button>

        {done && (
          <p className="mt-3 text-center text-green-700 font-bold flex items-center justify-center gap-2">
            <CheckCircle className="w-5 h-5" /> {t('healthSummaryDone')}
          </p>
        )}
        {error && (
          <p className="mt-3 text-center text-red-600 font-semibold">{error}</p>
        )}
      </div>

      <div className="p-4 bg-amber-50 border-2 border-amber-200 rounded-xl flex items-start gap-3">
        <Info className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
        <p className="text-amber-900 text-sm font-semibold">{t('healthSummaryDisclaimer')}</p>
      </div>
    </div>
  );
}