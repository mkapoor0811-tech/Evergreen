// Medicines: today's pills, taken or skipped, with refills and how each one felt.
import React, { useState, useEffect } from 'react';
import ActionButton from '@/components/ActionButton';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import { Plus, Loader2, Check, ChevronDown } from 'lucide-react';
import { applyMedTaken } from '@/lib/medTaken';
import VoiceButton from '@/components/VoiceButton';
import { parseMedication } from '@/lib/voiceParse';
import ReadAloudButton from '@/components/ReadAloudButton';
import VoiceCommandListener from '@/components/medications/VoiceCommandListener';
import { parseTakenCommand } from '@/lib/voiceCommands';
import MedicationForm from '@/components/medications/MedicationForm';
import QuickMedForm from '@/components/medications/QuickMedForm';
import TodayPillRow from '@/components/medications/TodayPillRow';
import NextPillCard from '@/components/medications/NextPillCard';
import MedMorePanel from '@/components/medications/MedMorePanel';
import PillOrganizer from '@/components/medications/PillOrganizer';
import DoseDialog from '@/components/medications/DoseDialog';
import FeelHistory from '@/components/medications/FeelHistory';
import MedicationExportButton from '@/components/medications/MedicationExportButton';
import { LOCALES, formatTime12 } from '@/lib/timeFormat';
import ConfirmDialog from '@/components/appointments/ConfirmDialog';
import { useUndo } from '@/lib/UndoContext';
import { slotForTime } from '@/lib/medSchedule';
import { INSTRUCTION_KEYS } from '@/lib/medInstructions';
import { effectiveMedTime } from '@/lib/daySchedule';
import { todayLocal, localDate } from '@/lib/localDate';

const todayStr = todayLocal;

const EMPTY_FORM = {
  name: '',
  dosage: '',
  time: '08:00',
  notes: '',
  instructions: [],
  pharmacy_name: '',
  pharmacy_phone: '',
  doctor_name: '',
  doctor_phone: '',
  pill_count: '',
  refill_threshold: 5,
};

const EMPTY_QUICK = { name: '', time: '08:00', notes: '' };

// Three plain groups. Anything after 8pm is shown under "Evening" so nothing is hidden.
const GROUP_OF_SLOT = { morning: 'morning', afternoon: 'afternoon', evening: 'evening', bedtime: 'evening' };
const GROUPS = ['morning', 'afternoon', 'evening'];

export default function Medications() {
  const { t, dayTimes, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';
  const { showUndo } = useUndo();
  const [meds, setMeds] = useState(null);
  const [pendingDelete, setPendingDelete] = useState(null);
  const [doseLogs, setDoseLogs] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [showQuick, setShowQuick] = useState(false);
  const [quick, setQuick] = useState(EMPTY_QUICK);
  const [moreId, setMoreId] = useState(null);
  const [showOptions, setShowOptions] = useState(false);
  const [now, setNow] = useState(new Date());
  const [voiceProcessing, setVoiceProcessing] = useState(false);
  const [commandMessage, setCommandMessage] = useState('');
  const [doseDialog, setDoseDialog] = useState(null);

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(id);
  }, []);

  const load = async () => {
    const since = new Date();
    since.setDate(since.getDate() - 34);
    const [medList, logPage] = await Promise.all([
      base44.entities.Medication.list('-created_date', 100),
      base44.entities.DoseLog.filter(
        { date: { $gte: localDate(since) } },
        { sort: '-date', limit: 500 },
      ),
    ]);
    // A pill taken "with breakfast" reminds at the breakfast time the user chose.
    setMeds(medList.map((m) => ({ ...m, time: effectiveMedTime(m, dayTimes) })));
    setDoseLogs(logPage.items || []);
  };

  useEffect(() => { load(); }, [dayTimes]);

  const findTodayLog = (med) =>
    doseLogs.find((l) => l.medication_id === med.id && l.date === todayStr() && l.slot === slotForTime(med.time));

  const isTaken = (med) => Boolean(med.taken_today && med.last_taken_date === todayStr());
  const isSkipped = (med) => findTodayLog(med)?.status === 'skipped';

  const isOverdue = (med) => {
    if (isTaken(med) || isSkipped(med) || !med.time) return false;
    const [h, m] = med.time.split(':').map(Number);
    const due = new Date();
    due.setHours(h, m + 30, 0, 0);
    return now >= due;
  };

  const saveDoseLog = async (med, status, extra = {}) => {
    const existing = findTodayLog(med);
    const payload = {
      medication_id: med.id,
      medication_name: med.name,
      date: todayStr(),
      slot: slotForTime(med.time),
      status,
      logged_at: new Date().toISOString(),
      ...extra,
    };
    if (existing) return await base44.entities.DoseLog.update(existing.id, payload);
    return await base44.entities.DoseLog.create(payload);
  };

  // Applies a taken / not-taken state to one medication. Returns true when it changed.
  const applyTaken = (med, markAsTaken) => applyMedTaken(med, markAsTaken);

  const markTaken = async (med) => {
    const changed = await applyTaken(med, true);
    if (!changed) return;
    await saveDoseLog(med, 'taken');
    await load();
    showUndo(t('undoTakenMsg'), async () => {
      await applyTaken(med, false);
      await base44.entities.DoseLog.deleteMany({ medication_id: med.id, date: todayStr() });
      await load();
    });
  };

  const toggleTaken = async (med) => {
    if (isTaken(med)) {
      await applyTaken(med, false);
      const existing = findTodayLog(med);
      if (existing) await base44.entities.DoseLog.delete(existing.id);
      await load();
    } else {
      await markTaken(med);
    }
  };

  const openFeel = (med) => setDoseDialog({ med, log: findTodayLog(med), mode: 'feel' });

  const skipDose = (med) => {
    setMoreId(null);
    setDoseDialog({ med, log: findTodayLog(med), mode: 'skip' });
  };

  const saveDoseDialog = async (data) => {
    if (!doseDialog) return;
    const { med, log, mode } = doseDialog;
    if (mode === 'feel') {
      if (log) {
        await base44.entities.DoseLog.update(log.id, data);
      } else {
        await applyTaken(med, true);
        await saveDoseLog(med, 'taken', data);
      }
    } else {
      if (isTaken(med)) await applyTaken(med, false);
      await saveDoseLog(med, 'skipped', data);
    }
    setDoseDialog(null);
    await load();
  };

  const handleVoiceCommand = async (transcript) => {
    if (!meds) return;
    const targets = parseTakenCommand(transcript, meds);
    if (targets.length === 0) {
      setCommandMessage(t('voiceNoMatch'));
      return;
    }
    let changed = 0;
    for (const med of targets) {
      const did = await applyTaken(med, true);
      if (did) {
        await saveDoseLog(med, 'taken');
        changed++;
      }
    }
    await load();
    const names = targets.map((m) => m.name).join(', ');
    setCommandMessage(changed > 0 ? `${t('voiceMarked')} ${names}` : `${t('voiceAlreadyTaken')} ${names}`);
  };

  const handleVoiceResult = async (transcript) => {
    setVoiceProcessing(true);
    try {
      const parsed = await parseMedication(transcript);
      setQuick({
        name: parsed.name || '',
        time: parsed.time || '08:00',
        notes: parsed.dosage ? `${t('dosage')}: ${parsed.dosage}` : '',
      });
      setShowQuick(true);
    } catch (e) { /* ignore */ }
    setVoiceProcessing(false);
  };

  const submitQuick = async () => {
    if (!quick.name.trim()) return;
    await base44.entities.Medication.create({
      name: quick.name.trim(),
      dosage: '',
      time: quick.time,
      notes: quick.notes.trim(),
      instructions: [],
      taken_today: false,
    });
    setQuick(EMPTY_QUICK);
    setShowQuick(false);
    await load();
  };

  const submitForm = async () => {
    if (!form.name.trim()) return;
    const payload = {
      name: form.name.trim(),
      dosage: form.dosage.trim(),
      time: form.time,
      notes: (form.notes || '').trim(),
      instructions: Array.isArray(form.instructions) ? form.instructions : [],
      pharmacy_name: form.pharmacy_name.trim(),
      pharmacy_phone: form.pharmacy_phone.trim(),
      doctor_name: form.doctor_name.trim(),
      doctor_phone: form.doctor_phone.trim(),
      pill_count: form.pill_count === '' ? null : Number(form.pill_count),
      refill_threshold: Number(form.refill_threshold) || 5,
    };
    if (editingId) {
      await base44.entities.Medication.update(editingId, payload);
    } else {
      await base44.entities.Medication.create({ ...payload, taken_today: false });
    }
    setForm(EMPTY_FORM);
    setEditingId(null);
    setShowForm(false);
    await load();
  };

  const startEdit = (med) => {
    setMoreId(null);
    setForm({
      name: med.name || '',
      dosage: med.dosage || '',
      time: med.time || '08:00',
      notes: med.notes || '',
      instructions: Array.isArray(med.instructions) ? med.instructions : [],
      pharmacy_name: med.pharmacy_name || '',
      pharmacy_phone: med.pharmacy_phone || '',
      doctor_name: med.doctor_name || '',
      doctor_phone: med.doctor_phone || '',
      pill_count: med.pill_count ?? '',
      refill_threshold: med.refill_threshold ?? 5,
    });
    setEditingId(med.id);
    setShowForm(true);
  };

  const deleteMed = (id) => setPendingDelete(id);

  const confirmDeleteMed = async () => {
    const id = pendingDelete;
    setPendingDelete(null);
    setMoreId(null);
    await base44.entities.Medication.delete(id);
    await base44.entities.DoseLog.deleteMany({ medication_id: id });
    load();
  };

  const refillMed = async (med) => {
    const input = prompt(t('enterRefillCount'), String(med.pill_count ?? ''));
    if (input === null) return;
    const count = parseInt(input, 10);
    if (isNaN(count) || count < 0) return;
    const threshold = med.refill_threshold ?? 5;
    const updates = { pill_count: count };
    if (count > threshold) updates.refill_reminder_sent = false;
    await base44.entities.Medication.update(med.id, updates);
    load();
  };

  const readAloudText = () => {
    if (!meds) return t('medications');
    if (meds.length === 0) return t('noPillsYet');
    const count = t('takenTodayCount')
      .replace('{taken}', String(meds.filter(isTaken).length))
      .replace('{total}', String(meds.length));
    return `${t('medications')}. ${count}. ` + meds.map((m) => {
      const how = (m.instructions || []).map((k) => t(INSTRUCTION_KEYS[k])).filter(Boolean);
      return `${m.name}, ${t('time')} ${formatTime12(m.time, locale)}.${how.length ? ` ${t('howToTake')}: ${how.join(', ')}.` : ''} ${isTaken(m) ? t('done') : t('markTaken')}`;
    }).join('. ');
  };

  const untaken = (meds || []).filter((m) => !isTaken(m) && !isSkipped(m));
  const nextPill = untaken.slice().sort((a, b) => (a.time || '').localeCompare(b.time || ''))[0] || null;
  const takenCount = (meds || []).filter(isTaken).length;

  return (
    <div>
      <PageHeader title={t('medications')} description={t('medicationsDesc')} />
      {meds && <ReadAloudButton text={readAloudText()} />}

      <div className="mb-4">
        <VoiceCommandListener onCommand={handleVoiceCommand} />
      </div>
      {commandMessage && (
        <div className="mb-5 flex items-center gap-3 p-4 rounded-2xl bg-earth-sage/15 border-2 border-earth-sage/50 text-earth-sageDark font-bold">
          <Check className="w-6 h-6 shrink-0" strokeWidth={3} />
          {commandMessage}
        </div>
      )}
      {voiceProcessing && (
        <div className="mb-5 flex items-center justify-center gap-2 p-4 bg-earth-lagoon/10 rounded-2xl text-earth-lagoonDark font-bold">
          <Loader2 className="w-5 h-5 animate-spin" />
          {t('voiceProcessing')}
        </div>
      )}

      {showForm && (
        <MedicationForm
          form={form}
          setForm={setForm}
          onSubmit={submitForm}
          onCancel={() => { setShowForm(false); setEditingId(null); setForm(EMPTY_FORM); }}
          meds={meds}
          editing={editingId}
        />
      )}

      {meds === null ? (
        <p className="text-center text-muted-foreground py-8">{t('loading')}</p>
      ) : meds.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">{t('noPillsYet')}</p>
      ) : (
        <>
          <p className="text-2xl font-heading text-foreground text-center mb-5">
            {t('takenTodayCount').replace('{taken}', String(takenCount)).replace('{total}', String(meds.length))}
          </p>

          <NextPillCard med={nextPill} onTake={markTaken} />

          <h2 className="font-heading text-2xl text-foreground mb-3">{t('todaysPills')}</h2>

          <div className="space-y-5 mb-8">
            {GROUPS.map((group) => {
              const groupMeds = meds.filter((m) => GROUP_OF_SLOT[slotForTime(m.time)] === group);
              if (groupMeds.length === 0) return null;
              return (
                <div key={group}>
                  <p className="text-lg font-bold text-muted-foreground mb-2">{t(group)}</p>
                  <div className="space-y-3">
                    {groupMeds.map((med) => (
                      <TodayPillRow
                        key={med.id}
                        med={med}
                        taken={isTaken(med)}
                        skipped={isSkipped(med)}
                        overdue={isOverdue(med)}
                        open={moreId === med.id}
                        onToggleTaken={toggleTaken}
                        onToggleMore={() => setMoreId(moreId === med.id ? null : med.id)}
                      >
                        <MedMorePanel
                          med={med}
                          taken={isTaken(med)}
                          onFeel={openFeel}
                          onSkip={skipDose}
                          onRefill={refillMed}
                          onEdit={startEdit}
                          onDelete={deleteMed}
                        />
                      </TodayPillRow>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {showQuick && (
        <QuickMedForm
          form={quick}
          setForm={setQuick}
          onSubmit={submitQuick}
          onCancel={() => { setShowQuick(false); setQuick(EMPTY_QUICK); }}
        />
      )}

      <ActionButton
        onClick={() => { setShowQuick((v) => !v); setShowForm(false); }}
        size="large"
        className="w-full mb-4 text-xl"
      >
        <Plus className="w-7 h-7" strokeWidth={2.5} />
        {t('addAPill')}
      </ActionButton>

      <div className="mb-6">
        <VoiceButton
          label={t('addByVoice')}
          prompt={t('voiceMedicationPrompt')}
          onResult={handleVoiceResult}
        />
      </div>

      <button
        onClick={() => setShowOptions((v) => !v)}
        className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
      >
        {t('moreOptions')}
        <ChevronDown className={`w-6 h-6 transition ${showOptions ? 'rotate-180' : ''}`} strokeWidth={2.5} />
      </button>

      {showOptions && (
        <div className="mt-6 space-y-6">
          {meds && meds.length > 0 && <PillOrganizer meds={meds} doseLogs={doseLogs} />}
          {meds && meds.length > 0 && <MedicationExportButton meds={meds} />}
          <FeelHistory doseLogs={doseLogs} />
        </div>
      )}

      {doseDialog && (
        <DoseDialog
          med={doseDialog.med}
          mode={doseDialog.mode}
          onClose={() => setDoseDialog(null)}
          onSave={saveDoseDialog}
        />
      )}

      {pendingDelete && (
        <ConfirmDialog
          title={t('areYouSure')}
          message={t('confirmDelete')}
          confirmLabel={t('yesDelete')}
          onConfirm={confirmDeleteMed}
          onClose={() => setPendingDelete(null)}
        />
      )}
    </div>
  );
}