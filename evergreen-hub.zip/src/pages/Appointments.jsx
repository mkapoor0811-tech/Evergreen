// My Visits: the next visit, its reminders, and the list of upcoming visits.
import React, { useState, useEffect } from 'react';
import ActionButton from '@/components/ActionButton';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { Link } from 'react-router-dom';
import PageHeader from '@/components/PageHeader';
import ReadAloudButton from '@/components/ReadAloudButton';
import NextVisitCard from '@/components/appointments/NextVisitCard';
import VisitRow from '@/components/appointments/VisitRow';
import VisitForm from '@/components/appointments/VisitForm';
import NoteDialog from '@/components/appointments/NoteDialog';
import { parseAppointment } from '@/lib/voiceParse';
import { sendDueAppointmentReminders } from '@/lib/appointmentReminders';
import VisitPrepActions from '@/components/appointments/VisitPrepActions';
import { todayLocal } from '@/lib/localDate';
import { LOCALES, formatTime12 } from '@/lib/timeFormat';
import { Plus, Loader2 } from 'lucide-react';

const todayStr = todayLocal;
const EMPTY = { doctor_name: '', date: todayStr(), time: '09:00' };

export default function Appointments() {
  const { t, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';
  const [upcoming, setUpcoming] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [noteFor, setNoteFor] = useState(null);
  const [voiceProcessing, setVoiceProcessing] = useState(false);

  const load = async () => {
    const { items } = await base44.entities.Appointment.filter(
      { date: { $gte: todayStr() } },
      { sort: 'date', limit: 100 },
    );
    setUpcoming(items);
  };

  useEffect(() => {
    load();
    // Reminders are sent when the app is opened (background sending needs Builder+).
    sendDueAppointmentReminders().catch(() => {});
  }, []);

  const addAppt = async () => {
    if (!form.doctor_name.trim()) return;
    await base44.entities.Appointment.create({
      doctor_name: form.doctor_name.trim(),
      date: form.date,
      time: form.time,
      notes: '',
      doctor_phone: '',
      reminders_on: true,
    });
    setForm(EMPTY);
    setShowAdd(false);
    load();
  };

  const speakVisit = async (transcript) => {
    setVoiceProcessing(true);
    try {
      const parsed = await parseAppointment(transcript);
      setForm((f) => ({
        ...f,
        doctor_name: parsed.doctor_name || f.doctor_name,
        date: parsed.date || f.date,
        time: parsed.time || f.time,
      }));
    } catch (e) { /* ignore */ }
    setVoiceProcessing(false);
  };

  const saveNote = async (id, notes) => {
    await base44.entities.Appointment.update(id, { notes });
    setNoteFor(null);
    load();
  };

  const next = upcoming?.[0] || null;
  const others = (upcoming || []).slice(1);

  const readAloudText = () => {
    if (!upcoming) return t('myVisits');
    if (upcoming.length === 0) return t('noUpcomingVisits');
    return `${t('myVisits')}. ` + upcoming
      .map((a) => `${a.doctor_name}, ${a.date}, ${t('time')} ${formatTime12(a.time, locale)}.`)
      .join('. ');
  };

  return (
    <div>
      <PageHeader title={t('myVisits')} description={t('appointmentsDesc')} />
      {upcoming && <ReadAloudButton text={readAloudText()} />}

      {voiceProcessing && (
        <div className="mb-5 flex items-center justify-center gap-2 p-4 bg-earth-lagoon/10 rounded-2xl text-earth-lagoonDark font-bold">
          <Loader2 className="w-5 h-5 animate-spin" />
          {t('voiceProcessing')}
        </div>
      )}

      {showAdd && (
        <VisitForm
          form={form}
          setForm={setForm}
          onSubmit={addAppt}
          onCancel={() => { setShowAdd(false); setForm(EMPTY); }}
          onSpeak={speakVisit}
        />
      )}

      {upcoming === null ? (
        <p className="text-center text-muted-foreground py-8">{t('loading')}</p>
      ) : (
        <>
          <NextVisitCard appt={next} onAddNote={setNoteFor} />

          {others.length > 0 && (
            <>
              <h2 className="font-heading text-2xl text-foreground mb-3">{t('otherVisits')}</h2>
              <div className="space-y-3 mb-8">
                {others.map((appt) => (
                  <VisitRow key={appt.id} appt={appt}>
                    <VisitPrepActions appt={appt} />
                  </VisitRow>
                ))}
              </div>
            </>
          )}

          <div className="flex justify-center gap-10 mb-4">
            <Link
              to="/appointments/calendar"
              className="font-bold text-xl text-earth-lagoonDark underline py-3"
            >
              {t('calendar')}
            </Link>
            <Link
              to="/appointments/past"
              className="font-bold text-xl text-earth-lagoonDark underline py-3"
            >
              {t('pastVisits')}
            </Link>
          </div>
        </>
      )}

      <ActionButton onClick={() => setShowAdd((v) => !v)} size="large" className="w-full mb-4 text-2xl">
        <Plus className="w-8 h-8" strokeWidth={2.5} />
        {t('addAVisit')}
      </ActionButton>

      {noteFor && (
        <NoteDialog
          title={t('addNote')}
          value={noteFor.notes || ''}
          onSave={(text) => saveNote(noteFor.id, text)}
          onClose={() => setNoteFor(null)}
        />
      )}
    </div>
  );
}