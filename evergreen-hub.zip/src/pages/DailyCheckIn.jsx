// Daily check-in: mark today as okay, keep the streak going, or ask for help.
import React, { useState, useEffect } from 'react';
import ActionButton from '@/components/ActionButton';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import PageHeader from '@/components/PageHeader';
import Illustration from '@/components/Illustration';
import { ILLUSTRATIONS } from '@/lib/illustrations';
import { Heart, Check, AlertTriangle, Clock } from 'lucide-react';
import VoiceButton from '@/components/VoiceButton';
import ReadAloudButton from '@/components/ReadAloudButton';
import StreakCounter from '@/components/checkin/StreakCounter';
import CheckInCalendar from '@/components/checkin/CheckInCalendar';
import NeedHelpButton from '@/components/checkin/NeedHelpButton';
import { todayLocal } from '@/lib/localDate';
import { LOCALES, formatTime12 } from '@/lib/timeFormat';

const todayStr = todayLocal;

export default function DailyCheckIn() {
  const { t, checkInDeadline, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';
  const [checkIn, setCheckIn] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const [todayRows, all] = await Promise.all([
      base44.entities.CheckIn.filter({ date: todayStr() }),
      base44.entities.CheckIn.list('-date', 200),
    ]);
    setCheckIn(todayRows.length > 0 ? todayRows[0] : null);
    setHistory(all);
  };

  useEffect(() => { load(); }, []);

  const now = new Date();
  const [dh, dm] = (checkInDeadline || '12:00').split(':').map(Number);
  const deadline = new Date();
  deadline.setHours(dh, dm, 0, 0);
  const isPastDeadline = now > deadline;
  const isCheckedIn = checkIn?.checked_in;
  const isMissed = !isCheckedIn && isPastDeadline;

  const doCheckIn = async () => {
    setLoading(true);
    if (checkIn) {
      const updated = await base44.entities.CheckIn.update(checkIn.id, { checked_in: true, checked_in_at: new Date().toISOString() });
      setCheckIn(updated);
    } else {
      const created = await base44.entities.CheckIn.create({ date: todayStr(), checked_in: true, checked_in_at: new Date().toISOString() });
      setCheckIn(created);
    }
    await load();
    setLoading(false);
  };

  const handleVoiceResult = () => {
    doCheckIn();
  };

  const checkInButton = (
    <ActionButton onClick={doCheckIn} disabled={loading} size="large" className="w-full text-xl">
      <Heart className="w-8 h-8" strokeWidth={2.5} />
      {t('imOkayToday')}
    </ActionButton>
  );

  return (
    <div>
      <PageHeader title={t('dailyCheckIn')} description={t('dailyCheckInDesc')} />
      <ReadAloudButton text={isCheckedIn ? t('checkInDone') : isMissed ? `${t('missedCheckIn')}. ${t('missedCheckInMsg')}` : t('notCheckedIn')} />

      <div className="flex items-center gap-2 text-muted-foreground font-semibold mb-5">
        <Clock className="w-5 h-5" />
        {t('checkInDeadline')}: <span className="font-bold text-foreground tabular-nums">{formatTime12(checkInDeadline, locale)}</span>
      </div>

      {!isCheckedIn && (
        <div className="mb-5">
          <VoiceButton
            label={t('voiceCheckIn')}
            prompt={t('voiceCheckInPrompt')}
            onResult={handleVoiceResult}
          />
        </div>
      )}

      {isCheckedIn ? (
        <div className="p-8 bg-earth-sage/15 border-2 border-earth-sage/50 rounded-3xl text-center">
          <Illustration src={ILLUSTRATIONS.together} alt={t('illTogetherAlt')} />
          <div className="w-20 h-20 mx-auto blob bg-earth-sage flex items-center justify-center mb-4">
            <Check className="w-12 h-12 text-white" strokeWidth={3} />
          </div>
          <p className="text-xl font-bold text-earth-sageDark">{t('checkInDone')}</p>
          <p className="font-heading text-2xl text-foreground mt-3">{t('wellDoneToday')}</p>
        </div>
      ) : isMissed ? (
        <div className="space-y-5">
          <div className="p-6 bg-earth-terracotta/10 border-2 border-earth-terracotta/40 rounded-3xl text-center">
            <div className="w-20 h-20 mx-auto blob bg-earth-terracotta flex items-center justify-center mb-4">
              <AlertTriangle className="w-12 h-12 text-white" strokeWidth={2.5} />
            </div>
            <p className="text-2xl font-bold text-earth-terracottaDark">{t('missedCheckIn')}</p>
            <p className="text-lg text-foreground mt-2">{t('missedCheckInMsg')}</p>
          </div>
          <p className="text-center text-muted-foreground font-semibold">{t('notCheckedIn')}</p>
          {checkInButton}
        </div>
      ) : (
        <div className="space-y-5">
          <div className="p-6 bg-earth-marigold/15 border-2 border-earth-marigold/40 rounded-3xl text-center">
            <p className="text-lg text-foreground font-semibold">{t('notCheckedIn')}</p>
          </div>
          {checkInButton}
        </div>
      )}

      <StreakCounter checkIns={history} />

      <NeedHelpButton checkIn={checkIn} onSaved={load} />

      <div className="mt-6">
        <CheckInCalendar checkIns={history} />
      </div>
    </div>
  );
}