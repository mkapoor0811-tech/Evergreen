import { useState } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Outlet } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import { Navigate } from 'react-router-dom';
import ProtectedRoute from '@/components/ProtectedRoute';
import { AppSettingsProvider } from '@/lib/AppSettings';
import WelcomeSplash from '@/components/WelcomeSplash';
import Layout from '@/components/Layout';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Home from '@/pages/Home';
import Medications from '@/pages/Medications';
import Appointments from '@/pages/Appointments';
import VisitDetail from '@/pages/VisitDetail';
import VisitPrepare from '@/pages/VisitPrepare';
import VisitRecap from '@/pages/VisitRecap';
import PastVisits from '@/pages/PastVisits';
import AppointmentsCalendar from '@/pages/AppointmentsCalendar';
import Groceries from '@/pages/Groceries';
import Diet from '@/pages/Diet';
import Exercise from '@/pages/Exercise';
import DailyCheckIn from '@/pages/DailyCheckIn';
import ScamChecker from '@/pages/ScamChecker';
import Settings from '@/pages/Settings';
import FamilyDashboard from '@/pages/FamilyDashboard';
import DailyBoost from '@/pages/DailyBoost';
import Onboarding from '@/pages/Onboarding';
import Welcome from '@/pages/Welcome';
import Emergency from '@/pages/Emergency';
import About from '@/pages/About';
import HealthSummary from '@/pages/HealthSummary';
import TermExplainer from '@/pages/TermExplainer';
import Learn from '@/pages/Learn';
import HealthHub from '@/pages/HealthHub';
import SafetyHub from '@/pages/SafetyHub';
import LearnHub from '@/pages/LearnHub';
import FamilyHub from '@/pages/FamilyHub';
import EmergencyProfile from '@/pages/EmergencyProfile';
import Breathe from '@/pages/Breathe';
import Garden from '@/pages/Garden';
import TechHelp from '@/pages/TechHelp';
import TechHelpLesson from '@/pages/TechHelpLesson';
import TechDictionary from '@/pages/TechDictionary';
import TechPractice from '@/pages/TechPractice';
import EmergencyReadiness from '@/pages/EmergencyReadiness';

// Sends first-time users through the short welcome before they reach the app.
const WelcomeGate = () => {
  if (localStorage.getItem('mahika_welcomeDone') === 'true') return <Outlet />;
  return <Navigate to="/welcome" replace />;
};

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin, isAuthenticated } = useAuth();
  // Kept in memory only: a fresh load shows the welcome screen, moving between pages never does.
  const [started, setStarted] = useState(false);

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <AppSettingsProvider>
      {isAuthenticated && !started && <WelcomeSplash onStart={() => setStarted(true)} />}
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/welcome" element={<Welcome />} />
        <Route path="/emergency" element={<Emergency />} />
        <Route element={<WelcomeGate />}>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/medications" element={<Medications />} />
            <Route path="/appointments" element={<Appointments />} />
            <Route path="/appointments/calendar" element={<AppointmentsCalendar />} />
            <Route path="/appointments/past" element={<PastVisits />} />
            <Route path="/appointments/:id" element={<VisitDetail />} />
            <Route path="/appointments/:id/prepare" element={<VisitPrepare />} />
            <Route path="/appointments/:id/recap" element={<VisitRecap />} />
            <Route path="/groceries" element={<Groceries />} />
            <Route path="/diet" element={<Diet />} />
            <Route path="/exercise" element={<Exercise />} />
            <Route path="/check-in" element={<DailyCheckIn />} />
            <Route path="/scam-checker" element={<ScamChecker />} />
            <Route path="/daily-boost" element={<DailyBoost />} />
            <Route path="/term-explainer" element={<TermExplainer />} />
            <Route path="/health" element={<HealthHub />} />
            <Route path="/safety" element={<SafetyHub />} />
            <Route path="/learn" element={<LearnHub />} />
            <Route path="/learn/topics" element={<Learn />} />
            <Route path="/family" element={<FamilyHub />} />
            <Route path="/breathe" element={<Breathe />} />
            <Route path="/garden" element={<Garden />} />
            <Route path="/tech-help" element={<TechHelp />} />
            <Route path="/tech-help/lesson/:lessonId" element={<TechHelpLesson />} />
            <Route path="/tech-help/dictionary" element={<TechDictionary />} />
            <Route path="/tech-help/practice" element={<TechPractice />} />
            <Route path="/emergency-readiness" element={<EmergencyReadiness />} />
            <Route path="/about" element={<About />} />

            {/* The private screens still ask for a sign-in. */}
            <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
              <Route path="/settings" element={<Settings />} />
              <Route path="/family-dashboard" element={<FamilyDashboard />} />
              <Route path="/health-summary" element={<HealthSummary />} />
              <Route path="/emergency-profile" element={<EmergencyProfile />} />
            </Route>
          </Route>
        </Route>
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </AppSettingsProvider>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App