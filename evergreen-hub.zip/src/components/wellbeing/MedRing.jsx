import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';

export default function MedRing({ taken, total }) {
  const { t } = useAppSettings();
  const pct = total > 0 ? Math.min(1, taken / total) : 0;
  const R = 70;
  const C = 2 * Math.PI * R;

  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 180 180" className="w-48 h-48">
        <circle cx="90" cy="90" r={R} fill="none" strokeWidth="20" className="stroke-secondary" />
        <circle
          cx="90"
          cy="90"
          r={R}
          fill="none"
          strokeWidth="20"
          strokeLinecap="round"
          className="stroke-earth-sage"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - pct)}
          transform="rotate(-90 90 90)"
        />
        <text x="90" y="86" textAnchor="middle" fontSize="42" fontWeight="700" className="fill-foreground font-heading">
          {taken}
        </text>
        <text x="90" y="114" textAnchor="middle" fontSize="18" className="fill-muted-foreground font-bold">
          / {total}
        </text>
      </svg>
      <p className="font-bold text-foreground">{t('medRing')}</p>
      <p className="text-muted-foreground">{t('taken')}</p>
    </div>
  );
}