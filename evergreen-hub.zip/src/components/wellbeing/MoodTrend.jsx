import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';

// One table drives both the dot's height and the words under the chart, so the two always agree.
const MOOD_LEVEL = {
  great: { value: 3, key: 'moodGreat' },
  okay: { value: 2, key: 'moodGood' },
  not_great: { value: 1, key: 'moodOkay' },
  down: { value: 0, key: 'moodLow' },
};
const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

// The chart's own scale, read top to bottom down the left side.
const AXIS = [
  { key: 'moodGreat', value: 3 },
  { key: 'moodGood', value: 2 },
  { key: 'moodOkay', value: 1 },
  { key: 'moodLow', value: 0 },
];

const VIEW_W = 300;
const VIEW_H = 130;
const TOP = 20;
const BOTTOM = 104;
const xFor = (i) => 24 + i * 42;
const yFor = (value) => BOTTOM - (value / 3) * (BOTTOM - TOP);

export default function MoodTrend({ days, dietLogs }) {
  const { t, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';

  const logsByDate = {};
  dietLogs.forEach((log) => {
    if (log.mood) logsByDate[log.date] = log.mood;
  });

  const points = days.map((date, i) => {
    const mood = logsByDate[date];
    if (!mood) return null;
    const level = MOOD_LEVEL[mood] || MOOD_LEVEL.okay;
    return { date, mood, levelKey: level.key, x: xFor(i), y: yFor(level.value) };
  });

  // A day with no entry leaves a gap: the line stops there and no dot is drawn.
  const segments = [];
  let run = [];
  points.forEach((p) => {
    if (p) { run.push(p); return; }
    if (run.length > 1) segments.push(run);
    run = [];
  });
  if (run.length > 1) segments.push(run);

  const found = points.filter(Boolean);

  return (
    <div>
      <p className="font-bold text-foreground mb-2">{t('moodTrend')}</p>
      <p className="text-muted-foreground mb-3">{t('moodChartHelp')}</p>

      {found.length < 1 ? (
        <p className="text-muted-foreground">{t('noMoodYet')}</p>
      ) : (
        <>
          <div className="flex gap-2">
            <div className="relative w-[72px] shrink-0">
              {AXIS.map((a) => (
                <span
                  key={a.key}
                  style={{ top: `${(yFor(a.value) / VIEW_H) * 100}%` }}
                  className="absolute right-0 -translate-y-1/2 text-sm font-semibold text-muted-foreground leading-none"
                >
                  {t(a.key)}
                </span>
              ))}
            </div>
            <div className="flex-1">
              <svg viewBox={`0 0 ${VIEW_W} ${VIEW_H}`} className="w-full block">
                <line x1="16" y1={BOTTOM} x2="292" y2={BOTTOM} className="stroke-border" strokeWidth="2" />
                {segments.map((seg, i) => (
                  <polyline
                    key={i}
                    points={seg.map((p) => `${p.x},${p.y}`).join(' ')}
                    fill="none"
                    className="stroke-earth-terracotta"
                    strokeWidth="5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                ))}
                {found.map((p) => (
                  <circle key={p.date} cx={p.x} cy={p.y} r="9" className="fill-earth-terracotta stroke-white" strokeWidth="3" />
                ))}
              </svg>
            </div>
          </div>

          <div className="relative h-7 mt-1 ml-[80px]">
            {days.map((date, i) => (
              <span
                key={date}
                style={{ left: `${(xFor(i) / VIEW_W) * 100}%` }}
                className="absolute -translate-x-1/2 text-sm font-semibold text-muted-foreground"
              >
                {new Date(`${date}T00:00:00`).getDate()}
              </span>
            ))}
          </div>

          <div className="flex flex-wrap gap-x-5 gap-y-1 mt-2 text-muted-foreground font-semibold">
            {found.map((p) => (
              <span key={p.date}>
                {new Date(`${p.date}T00:00:00`).toLocaleDateString(locale, { weekday: 'short' })}: {t(p.levelKey)}
              </span>
            ))}
          </div>
        </>
      )}
    </div>
  );
}