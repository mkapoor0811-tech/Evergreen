import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { todayLocal } from '@/lib/localDate';
import { Check } from 'lucide-react';

// Low to Great, matching the levels the chart draws.
const CHOICES = [
  { mood: 'down', key: 'moodLow' },
  { mood: 'not_great', key: 'moodOkay' },
  { mood: 'okay', key: 'moodGood' },
  { mood: 'great', key: 'moodGreat' },
];

export default function MoodPicker({ todayLog, onSaved }) {
  const { t } = useAppSettings();
  const [logId, setLogId] = useState(todayLog ? todayLog.id : null);
  const [chosen, setChosen] = useState(todayLog ? todayLog.mood : null);
  const [saving, setSaving] = useState(false);
  const [justSaved, setJustSaved] = useState(false);

  // One tap saves it — there is no separate Save step.
  const pick = async (mood) => {
    if (saving || mood === chosen) return;
    setSaving(true);
    try {
      const date = todayLocal();
      if (logId) {
        await base44.entities.DietLog.update(logId, { mood });
        onSaved({ id: logId, date, mood });
      } else {
        const created = await base44.entities.DietLog.create({ date, mood });
        setLogId(created.id);
        onSaved(created);
      }
      setChosen(mood);
      setJustSaved(true);
      window.setTimeout(() => setJustSaved(false), 2500);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mt-4">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {CHOICES.map(({ mood, key }) => {
          const active = chosen === mood;
          return (
            <button
              key={mood}
              type="button"
              onClick={() => pick(mood)}
              disabled={saving}
              aria-pressed={active}
              className={`flex items-center justify-center gap-2 min-h-[64px] px-3 rounded-2xl border-2 font-bold transition disabled:opacity-70 ${
                active
                  ? 'bg-earth-lagoon border-earth-lagoon text-white'
                  : 'bg-card border-border text-foreground hover:bg-earth-lagoon/10'
              }`}
            >
              {active && <Check className="w-6 h-6 shrink-0" strokeWidth={3} />}
              {t(key)}
            </button>
          );
        })}
      </div>

      <p className="mt-3 min-h-[1.6rem] font-bold text-earth-lagoon" aria-live="polite">
        {justSaved ? t('saved') : ''}
      </p>
    </div>
  );
}