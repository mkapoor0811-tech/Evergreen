import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { iso } from '@/lib/medSchedule';
import { todayLocal } from '@/lib/localDate';
import MoodTrend from '@/components/wellbeing/MoodTrend';
import MoodPicker from '@/components/wellbeing/MoodPicker';
import ReadAloudButton from '@/components/ReadAloudButton';
import { Activity } from 'lucide-react';

function lastSevenDays() {
  const today = new Date();
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() - (6 - i));
    return iso(d);
  });
}

export default function WellbeingVisuals() {
  const { t } = useAppSettings();
  const [dietLogs, setDietLogs] = useState(null);

  useEffect(() => {
    const days = lastSevenDays();
    base44.entities.DietLog.filter({ date: { $gte: days[0] } }, { sort: 'date', limit: 50 })
      .then((page) => setDietLogs(page.items || []));
  }, []);

  // Keeps the chart and the words under it in step with the button just tapped.
  const handleMoodSaved = (record) => {
    setDietLogs((prev) => [
      ...(prev || []).filter((l) => l.date !== record.date),
      record,
    ].sort((a, b) => a.date.localeCompare(b.date)));
  };

  const todayLog = dietLogs?.find((l) => l.date === todayLocal());

  if (dietLogs === null) {
    return (
      <div className="mb-6 p-5 rounded-3xl bg-card border-2 border-border text-muted-foreground font-semibold">
        {t('loading')}
      </div>
    );
  }

  return (
    <section className="mb-6 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <div className="bg-earth-lagoon px-5 py-2.5 flex items-center gap-3">
        <Activity className="w-6 h-6 text-white" strokeWidth={2.5} />
        <h2 className="font-heading text-xl text-white">{t('moodTrend')}</h2>
      </div>

      <div className="p-5">
        <MoodTrend days={lastSevenDays()} dietLogs={dietLogs} />
        <MoodPicker todayLog={todayLog} onSaved={handleMoodSaved} />
        <ReadAloudButton text={t('moodTrend')} />
      </div>
    </section>
  );
}