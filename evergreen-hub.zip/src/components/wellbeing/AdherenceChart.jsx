import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

export default function AdherenceChart({ days, meds }) {
  const { t, language } = useAppSettings();
  const total = meds.length;

  return (
    <div>
      <p className="font-bold text-foreground mb-3">{t('adherenceWeek')}</p>
      <div className="flex items-end justify-between gap-2">
        {days.map(({ date, taken }) => {
          const pct = total > 0 ? Math.min(1, taken / total) : 0;
          const label = new Date(`${date}T00:00:00`).toLocaleDateString(LOCALES[language] || 'en-US', { weekday: 'short' });
          return (
            <div key={date} className="flex-1 flex flex-col items-center gap-2">
              <div className="w-full h-28 rounded-xl bg-secondary flex items-end overflow-hidden">
                <div className="w-full bg-earth-sage rounded-xl transition-all" style={{ height: `${pct * 100}%` }} />
              </div>
              <span className="font-semibold text-muted-foreground">{label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}