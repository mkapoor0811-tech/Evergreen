import React from 'react';
import { Check, X } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';
import { useUndo } from '@/lib/UndoContext';

/** A plain confirmation with an Undo button, shown above the bottom bar. */
export default function UndoBar() {
  const { t, simpleMode } = useAppSettings();
  const { undo, runUndo, dismissUndo } = useUndo();

  if (!undo) return null;

  return (
    <div className={`fixed left-0 right-0 z-[60] px-4 ${simpleMode ? 'bottom-[330px]' : 'bottom-[100px]'}`}>
      <div className="max-w-3xl mx-auto flex items-center gap-3 rounded-2xl bg-earth-navy text-white px-5 py-3 shadow-2xl">
        <Check className="w-7 h-7 shrink-0" strokeWidth={3} />
        <p className="flex-1 font-bold text-lg leading-snug">{undo.message}</p>
        <button
          onClick={runUndo}
          className="shrink-0 rounded-xl bg-white text-earth-navy font-bold px-5 min-h-[56px]"
        >
          {t('undo')}
        </button>
        <button
          onClick={dismissUndo}
          aria-label={t('cancel')}
          className="shrink-0 flex items-center justify-center w-[56px] h-[56px] rounded-xl hover:bg-white/15"
        >
          <X className="w-7 h-7" strokeWidth={2.5} />
        </button>
      </div>
    </div>
  );
}