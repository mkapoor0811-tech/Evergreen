import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Lightbulb, X } from 'lucide-react';

export default function SimpleModePrompt() {
  const { t, updateSetting, textSize } = useAppSettings();
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  // Don't show if already on large text
  if (textSize === 'large') return null;

  const switchToLarge = () => {
    updateSetting('textSize', 'large');
    setDismissed(true);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/40 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border-2 border-slate-200 max-w-md w-full p-6 shadow-2xl">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
              <Lightbulb className="w-7 h-7 text-amber-600" strokeWidth={2.5} />
            </div>
            <h2 className="text-xl font-bold text-slate-900">{t('simpleModeTitle')}</h2>
          </div>
          <button
            onClick={() => setDismissed(true)}
            className="p-2 rounded-xl hover:bg-slate-100 transition"
          >
            <X className="w-6 h-6 text-slate-500" />
          </button>
        </div>
        <p className="text-lg text-slate-700 leading-relaxed mb-5">{t('simpleModeMsg')}</p>
        <div className="flex flex-col gap-3">
          <button
            onClick={switchToLarge}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl transition min-h-[56px] text-lg"
          >
            {t('simpleModeYes')}
          </button>
          <button
            onClick={() => setDismissed(true)}
            className="w-full bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold py-3 rounded-xl transition min-h-[56px]"
          >
            {t('simpleModeNo')}
          </button>
        </div>
      </div>
    </div>
  );
}