import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { UserX, TrendingDown } from 'lucide-react';

export default function IsolationAlert({ pattern }) {
  const { t } = useAppSettings();
  if (!pattern) return null;

  return (
    <div className="p-5 rounded-2xl border-2 mb-5 bg-orange-50 border-orange-300">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-12 h-12 rounded-xl bg-orange-600 flex items-center justify-center shrink-0">
          <UserX className="w-7 h-7 text-white" strokeWidth={2.5} />
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900">{t('isolationAlertTitle')}</h2>
          <p className="text-orange-700 font-semibold">{t('isolationAlertDesc')}</p>
        </div>
      </div>
      <div className="mt-3 p-3 bg-white rounded-xl border border-orange-200">
        <div className="flex items-center gap-2 mb-2">
          <TrendingDown className="w-5 h-5 text-orange-600" />
          <p className="font-bold text-slate-900">{t('isolationActivityDrop')}</p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="p-2 bg-slate-50 rounded-lg">
            <p className="text-slate-500 text-sm">{t('isolationLastWeek')}</p>
            <p className="font-bold text-slate-900 text-lg">{pattern.previousScore} <span className="text-sm font-normal text-slate-500">{t('isolationActions')}</span></p>
          </div>
          <div className="p-2 bg-orange-50 rounded-lg">
            <p className="text-slate-500 text-sm">{t('isolationThisWeek')}</p>
            <p className="font-bold text-orange-700 text-lg">{pattern.recentScore} <span className="text-sm font-normal text-slate-500">{t('isolationActions')}</span></p>
          </div>
        </div>
        <p className="mt-3 text-slate-700 text-sm">{t('isolationSuggestion')}</p>
      </div>
    </div>
  );
}