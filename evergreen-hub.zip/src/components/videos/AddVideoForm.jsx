import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { base44 } from '@/api/base44Client';
import { Link2, Check } from 'lucide-react';

/** Paste a link, add a title and a short description, save. */
export default function AddVideoForm({ onSaved, onCancel }) {
  const { t } = useAppSettings();
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!url.trim()) return;
    setSaving(true);
    try {
      await base44.entities.ExerciseVideo.create({
        url: url.trim(),
        title: title.trim() || t('watch'),
        description: description.trim(),
        sort_order: 0,
      });
      setUrl('');
      setTitle('');
      setDescription('');
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mt-4 p-5 rounded-2xl border-2 border-earth-lagoon/50 bg-card space-y-4">
      <div>
        <label className="block font-bold text-xl text-foreground mb-2">{t('pasteVideoLink')}</label>
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://www.youtube.com/watch?v=..."
          className="w-full px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-lg min-h-[64px]"
        />
      </div>
      <div>
        <label className="block font-bold text-xl text-foreground mb-2">{t('videoTitle')}</label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-lg min-h-[64px]"
        />
      </div>
      <div>
        <label className="block font-bold text-xl text-foreground mb-2">{t('videoDescription')}</label>
        <input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-lg min-h-[64px]"
        />
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={save}
          disabled={saving || !url.trim()}
          className="flex-1 flex items-center justify-center gap-2 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-4 rounded-xl transition min-h-[64px] disabled:opacity-40"
        >
          {saving ? <Link2 className="w-6 h-6" strokeWidth={2.5} /> : <Check className="w-6 h-6" strokeWidth={3} />}
          {t('save')}
        </button>
        <button
          onClick={onCancel}
          className="px-6 py-4 rounded-xl border-2 border-border font-bold text-foreground transition min-h-[64px]"
        >
          {t('cancel')}
        </button>
      </div>
    </div>
  );
}