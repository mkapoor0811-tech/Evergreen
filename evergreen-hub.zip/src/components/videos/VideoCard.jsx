import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { youTubeId, watchUrl } from '@/lib/videoLink';
import { Play, Trash2 } from 'lucide-react';

/** One video: title, short description and a large Watch button. */
export default function VideoCard({ video, canManage, onDelete }) {
  const { t } = useAppSettings();
  const [playing, setPlaying] = useState(false);
  const [opensElsewhere, setOpensElsewhere] = useState(false);
  const id = youTubeId(video.url);

  const watch = () => {
    if (id) {
      setPlaying(true);
      return;
    }
    // Not a YouTube link, so it cannot play inside the app.
    window.open(watchUrl(video.url), '_blank', 'noopener');
    setOpensElsewhere(true);
  };

  return (
    <div className="rounded-2xl border-2 border-border bg-card p-5">
      <h3 className="font-heading text-2xl text-foreground leading-tight">{video.title}</h3>
      {video.description && <p className="text-lg text-muted-foreground mt-2">{video.description}</p>}

      {playing && id && (
        <div className="mt-4 aspect-video rounded-xl overflow-hidden border-2 border-border">
          <iframe
            src={`https://www.youtube.com/embed/${id}`}
            title={video.title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="w-full h-full"
          />
        </div>
      )}

      {opensElsewhere && (
        <p className="mt-4 text-lg font-bold text-earth-lagoonDark">{t('opensOnYouTube')}</p>
      )}

      <button
        type="button"
        onClick={watch}
        className="w-full mt-4 flex items-center justify-center gap-3 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-5 rounded-2xl transition min-h-[64px] text-xl"
      >
        <Play className="w-7 h-7" strokeWidth={2.5} />
        {t('watch')}
      </button>

      {canManage && (
        <button
          type="button"
          onClick={() => onDelete(video)}
          className="w-full mt-3 flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-destructive/40 text-destructive font-bold transition min-h-[56px]"
        >
          <Trash2 className="w-5 h-5" strokeWidth={2.5} />
          {t('delete')}
        </button>
      )}
    </div>
  );
}