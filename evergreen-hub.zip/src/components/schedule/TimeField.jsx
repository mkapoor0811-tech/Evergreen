import React from 'react';
import { formatTime } from '@/lib/daySchedule';

/** One very large time picker, with the chosen time repeated in plain words. */
export default function TimeField({ label, value, onChange }) {
  return (
    <div>
      <label className="block font-bold text-xl text-foreground mb-2">{label}</label>
      <input
        type="time"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-5 py-5 rounded-2xl border-2 border-border bg-card focus:border-earth-navy outline-none text-3xl font-bold min-h-[84px]"
      />
      <p className="mt-2 text-lg font-bold text-earth-sageDark">{`${label}, ${formatTime(value)}`}</p>
    </div>
  );
}