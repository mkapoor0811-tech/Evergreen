import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import VideoCard from '@/components/videos/VideoCard';
import AddVideoForm from '@/components/videos/AddVideoForm';
import { Play, Plus } from 'lucide-react';

/** The exercise video library. Videos are added by pasting a link. */
export default function SeniorVideos() {
  const { t } = useAppSettings();
  const [videos, setVideos] = useState(null);
  const [canManage, setCanManage] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const load = () => base44.entities.ExerciseVideo.list('sort_order', 100).then(setVideos);

  useEffect(() => {
    load();
    base44.auth.me()
      .then((user) => setCanManage(user?.role === 'admin'))
      .catch(() => {});
  }, []);

  const remove = async (video) => {
    if (!confirm(t('confirmDelete'))) return;
    await base44.entities.ExerciseVideo.delete(video.id);
    load();
  };

  return (
    <div className="mt-6 rounded-3xl border-2 border-border bg-card overflow-hidden">
      <div className="bg-earth-lagoon px-5 py-3 flex items-center gap-3">
        <Play className="w-6 h-6 text-white" strokeWidth={2.5} />
        <h2 className="font-heading text-2xl text-white">{t('seniorVideos')}</h2>
      </div>

      <div className="p-5">
        {videos === null ? (
          <p className="text-center text-muted-foreground py-6">{t('loading')}</p>
        ) : videos.length === 0 ? (
          <p className="text-center text-muted-foreground py-6">{t('noVideosYet')}</p>
        ) : (
          <div className="space-y-4">
            {videos.map((video) => (
              <VideoCard key={video.id} video={video} canManage={canManage} onDelete={remove} />
            ))}
          </div>
        )}

        {canManage && !showForm && (
          <button
            onClick={() => setShowForm(true)}
            className="w-full mt-4 flex items-center justify-center gap-2 bg-earth-navy hover:bg-earth-navyDark text-white font-bold py-4 rounded-2xl transition min-h-[64px] text-lg"
          >
            <Plus className="w-6 h-6" strokeWidth={2.5} />
            {t('addVideo')}
          </button>
        )}

        {canManage && showForm && (
          <AddVideoForm onSaved={() => { setShowForm(false); load(); }} onCancel={() => setShowForm(false)} />
        )}
      </div>
    </div>
  );
}