import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Eye } from 'lucide-react';

export default function AccessibilityPreview() {
  const { t } = useAppSettings();

  return (
    <div className="mt-6 rounded-3xl bg-card border-2 border-earth-lagoon/40 overflow-hidden">
      <div className="bg-earth-lagoon px-5 py-2.5 flex items-center gap-2">
        <Eye className="w-5 h-5 text-white" strokeWidth={2.25} />
        <h2 className="font-heading text-xl text-white">{t('preview')}</h2>
      </div>
      <div className="p-5">
        <p className="font-heading text-2xl text-foreground mb-2">{t('previewSampleHeading')}</p>
        <p className="text-foreground mb-4">{t('previewSampleText')}</p>
        <span className="inline-block bg-earth-terracotta text-white font-bold px-5 py-3 rounded-xl">
          {t('previewSampleButton')}
        </span>
      </div>
    </div>
  );
}