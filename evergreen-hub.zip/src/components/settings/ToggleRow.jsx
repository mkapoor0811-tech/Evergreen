import React from 'react';

/** A single on/off row: short label on the left, switch on the right. */
export default function ToggleRow({ label, on, onToggle }) {
  return (
    <button
      onClick={onToggle}
      aria-pressed={on}
      className={`w-full flex items-center justify-between gap-3 px-5 py-4 rounded-2xl border-2 transition min-h-[64px] ${
        on ? 'bg-earth-navy/10 border-earth-navy' : 'bg-card border-border'
      }`}
    >
      <span className="font-heading text-xl text-foreground text-left leading-tight">{label}</span>
      <span className={`w-14 h-8 rounded-full p-1 transition shrink-0 ${on ? 'bg-foreground' : 'bg-border'}`}>
        <span className={`block w-6 h-6 bg-card rounded-full transition ${on ? 'translate-x-6' : ''}`} />
      </span>
    </button>
  );
}