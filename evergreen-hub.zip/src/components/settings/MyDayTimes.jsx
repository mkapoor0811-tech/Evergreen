import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { DAY_TIME_ORDER, DAY_TIME_LABELS } from '@/lib/daySchedule';
import TimeField from '@/components/schedule/TimeField';

/** Wake-up, meal and bedtime pickers. Each change is saved straight away. */
export default function MyDayTimes() {
  const { t, dayTimes, updateDayTimes } = useAppSettings();

  return (
    <div className="space-y-4">
      {DAY_TIME_ORDER.map((key) => (
        <TimeField
          key={key}
          label={t(DAY_TIME_LABELS[key])}
          value={dayTimes[key]}
          onChange={(value) => updateDayTimes({ [key]: value })}
        />
      ))}
    </div>
  );
}