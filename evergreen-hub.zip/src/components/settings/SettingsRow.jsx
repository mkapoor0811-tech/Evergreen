import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

/** One plain row in Settings: a short label, and either controls or a link. */
export default function SettingsRow({ label, to, children }) {
  if (to) {
    return (
      <Link
        to={to}
        className="flex items-center justify-between gap-3 px-5 py-5 rounded-2xl border-2 border-border bg-card hover:border-earth-navy transition min-h-[64px]"
      >
        <span className="font-heading text-xl text-foreground leading-tight">{label}</span>
        <ChevronRight className="w-6 h-6 text-muted-foreground shrink-0" />
      </Link>
    );
  }

  return (
    <section className="px-5 py-5 rounded-2xl border-2 border-border bg-card">
      <h2 className="font-heading text-xl text-foreground leading-tight">{label}</h2>
      {children && <div className="mt-4">{children}</div>}
    </section>
  );
}