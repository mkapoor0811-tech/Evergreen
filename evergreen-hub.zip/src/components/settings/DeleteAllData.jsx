import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { deleteAllMyData } from '@/lib/myData';
import { Trash2, Loader2, X } from 'lucide-react';

/** Wipes everything the person has entered, behind an "Are you sure?" step. */
export default function DeleteAllData() {
  const { t } = useAppSettings();
  const [confirming, setConfirming] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [done, setDone] = useState(false);

  const wipe = async () => {
    setDeleting(true);
    const me = await base44.auth.me().catch(() => null);
    if (me?.id) await deleteAllMyData(me.id);
    setDeleting(false);
    setConfirming(false);
    setDone(true);
    setTimeout(() => { window.location.href = '/'; }, 1800);
  };

  return (
    <div className="px-5 py-5 rounded-2xl border-2 border-destructive/40 bg-destructive/5 space-y-4">
      {done ? (
        <p className="text-xl font-bold text-destructive">{t('deleteAllDone')}</p>
      ) : confirming ? (
        <div className="space-y-3">
          <p className="font-heading text-xl text-destructive">{t('areYouSure')}</p>
          <button
            onClick={wipe}
            disabled={deleting}
            className="w-full flex items-center justify-center gap-3 bg-destructive hover:bg-destructive/90 text-white font-bold py-5 rounded-xl text-xl transition min-h-[64px] disabled:opacity-50"
          >
            {deleting ? <Loader2 className="w-7 h-7 animate-spin" /> : <Trash2 className="w-7 h-7" />}
            {t('yesDeleteEverything')}
          </button>
          <button
            onClick={() => setConfirming(false)}
            className="w-full flex items-center justify-center gap-3 bg-secondary hover:bg-muted text-foreground font-bold py-5 rounded-xl text-xl transition min-h-[64px]"
          >
            <X className="w-7 h-7" />
            {t('cancel')}
          </button>
        </div>
      ) : (
        <button
          onClick={() => setConfirming(true)}
          className="w-full flex items-center justify-center gap-3 bg-destructive hover:bg-destructive/90 text-white font-bold py-5 rounded-xl text-xl transition min-h-[64px]"
        >
          <Trash2 className="w-7 h-7" />
          {t('deleteAllData')}
        </button>
      )}
    </div>
  );
}