import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import usePeopleConfig from '@/lib/usePeopleConfig';
import ContactList from '@/components/people/ContactList';

/** The emergency contacts list, shown inside its Settings row. */
export default function EmergencyContactsRow() {
  const { t } = useAppSettings();
  const { config, loading, save } = usePeopleConfig();

  if (loading) return <div className="h-16 rounded-2xl bg-secondary animate-pulse" />;

  return (
    <ContactList
      contacts={config.emergency_contacts}
      onChange={(list) => save({ emergency_contacts: list })}
      kind="emergency"
      addLabel={t('addContact')}
    />
  );
}