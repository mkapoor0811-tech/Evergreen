import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Pill, Calendar, ShoppingCart, Utensils, Dumbbell, Heart, Sparkles } from 'lucide-react';
import { todayLocal, localDate } from '@/lib/localDate';

const todayStr = todayLocal;
const dateStrFromISO = (iso) => (iso ? localDate(new Date(iso)) : null);

function dayDiff(a, b) {
  const [y1, m1, d1] = a.split('-').map(Number);
  const [y2, m2, d2] = b.split('-').map(Number);
  return Math.round((new Date(y2, m2 - 1, d2) - new Date(y1, m1 - 1, d1)) / 86400000);
}

export default function WeeklySummary({ meds, appts, groceries, dietLogs, exercises, checkIns }) {
  const { language } = useAppSettings();
  const es = language === 'es';

  const today = todayStr();
  const start = new Date();
  start.setDate(start.getDate() - 6);
  const startStr = localDate(start);
  const future = new Date();
  future.setDate(future.getDate() + 7);
  const futureStr = localDate(future);
  const inWeek = (d) => !!d && d >= startStr && d <= today;

  // Medications: doses taken vs missed (expected = days each med existed this week)
  let medTaken = 0, medExpected = 0;
  (meds || []).forEach((m) => {
    const created = dateStrFromISO(m.created_date);
    const from = created && created > startStr ? created : startStr;
    const days = dayDiff(from, today) + 1;
    if (days > 0) medExpected += days;
    (m.taken_dates || []).forEach((d) => { if (inWeek(d)) medTaken++; });
  });
  const medMissed = Math.max(0, medExpected - medTaken);

  // Appointments: completed this week + upcoming next 7 days
  const apptCompleted = (appts || []).filter((a) => a.date >= startStr && a.date <= today).length;
  const apptUpcoming = (appts || []).filter((a) => a.date > today && a.date <= futureStr).length;

  // Groceries: added + checked off this week
  const groceryAdded = (groceries || []).filter((g) => inWeek(dateStrFromISO(g.created_date))).length;
  const groceryChecked = (groceries || []).filter((g) => g.purchased && inWeek(g.purchased_date)).length;

  // Diet: days with a meal entry
  const dietDays = new Set();
  (dietLogs || []).forEach((log) => {
    if (inWeek(log.date) && (log.breakfast || log.lunch || log.dinner || log.snacks)) dietDays.add(log.date);
  });

  // Exercise: distinct active days
  const exDays = new Set();
  (exercises || []).forEach((ex) => (ex.done_dates || []).forEach((d) => { if (inWeek(d)) exDays.add(d); }));

  // Check-ins: successful vs missed
  const ciDays = new Set();
  (checkIns || []).forEach((ci) => { if (ci.checked_in && inWeek(ci.date)) ciDays.add(ci.date); });
  const ciMissed = Math.max(0, 7 - ciDays.size);

  const lines = [];

  if (medExpected === 0) {
    lines.push({ icon: Pill, color: 'text-blue-600 bg-blue-100', text: es ? 'Medicinas: aún no hay registro esta semana.' : 'Medications: nothing tracked yet this week.' });
  } else {
    const missedPart = medMissed > 0 ? (es ? `, ${medMissed} olvidada${medMissed > 1 ? 's' : ''}` : `, ${medMissed} missed`) : '';
    lines.push({ icon: Pill, color: 'text-blue-600 bg-blue-100', text: es
      ? `Medicinas: ${medTaken} de ${medExpected} dosis tomadas esta semana${missedPart}.`
      : `Medications: ${medTaken} of ${medExpected} doses taken this week${missedPart}.` });
  }

  let apptText;
  if (apptCompleted === 0 && apptUpcoming === 0) {
    apptText = es ? 'Citas: ninguna esta semana.' : 'Appointments: none this week.';
  } else {
    const parts = [];
    if (apptCompleted > 0) parts.push(es ? `${apptCompleted} visita${apptCompleted > 1 ? 's' : ''} completada${apptCompleted > 1 ? 's' : ''}` : `${apptCompleted} visit${apptCompleted > 1 ? 's' : ''} completed`);
    if (apptUpcoming > 0) parts.push(es ? `${apptUpcoming} próxima${apptUpcoming > 1 ? 's' : ''} en los próximos 7 días` : `${apptUpcoming} upcoming in the next 7 days`);
    apptText = (es ? 'Citas: ' : 'Appointments: ') + parts.join(', ') + '.';
  }
  lines.push({ icon: Calendar, color: 'text-purple-600 bg-purple-100', text: apptText });

  const groceryText = groceryAdded === 0 && groceryChecked === 0
    ? (es ? 'Compras: nada añadido esta semana.' : 'Groceries: nothing added this week.')
    : (es ? `Compras: ${groceryAdded} artículo${groceryAdded !== 1 ? 's' : ''} añadido${groceryAdded !== 1 ? 's' : ''}, ${groceryChecked} comprado${groceryChecked !== 1 ? 's' : ''}.`
           : `Groceries: ${groceryAdded} item${groceryAdded !== 1 ? 's' : ''} added, ${groceryChecked} checked off the list.`);
  lines.push({ icon: ShoppingCart, color: 'text-green-600 bg-green-100', text: groceryText });

  lines.push({ icon: Utensils, color: 'text-orange-600 bg-orange-100', text: es
    ? `Dieta: comidas registradas en ${dietDays.size} de 7 días esta semana.`
    : `Diet: meals were logged on ${dietDays.size} of 7 days this week.` });

  lines.push({ icon: Dumbbell, color: 'text-red-600 bg-red-100', text: es
    ? `Ejercicio: activo en ${exDays.size} de 7 días esta semana.`
    : `Exercise: stayed active on ${exDays.size} of 7 days this week.` });

  const ciMissedPart = ciMissed > 0 ? (es ? `, ${ciMissed} perdida${ciMissed > 1 ? 's' : ''}` : `, ${ciMissed} missed`) : '';
  lines.push({ icon: Heart, color: 'text-pink-600 bg-pink-100', text: es
    ? `Registro diario: se registró seguro en ${ciDays.size} de 7 días${ciMissedPart} esta semana.`
    : `Check-ins: checked in safely on ${ciDays.size} of 7 days${ciMissedPart} this week.` });

  return (
    <div className="p-5 bg-white rounded-2xl border-2 border-slate-200 mb-5">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center">
          <Sparkles className="w-7 h-7 text-white" strokeWidth={2.5} />
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900">{es ? 'Resumen Semanal' : 'Weekly Summary'}</h2>
          <p className="text-sm text-slate-500">{es ? 'Así ha estado la última semana' : 'A recap of the past 7 days'}</p>
        </div>
      </div>
      <div className="space-y-3">
        {lines.map((line, i) => {
          const Icon = line.icon;
          return (
            <div key={i} className="flex items-start gap-3">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${line.color}`}>
                <Icon className="w-5 h-5" strokeWidth={2.5} />
              </div>
              <p className="text-slate-700 text-base leading-relaxed pt-1">{line.text}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}