import React from 'react';
import { Check } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';
import ReadAloudButton from '@/components/ReadAloudButton';

export default function ReadinessChecklist({ items, doneKeys, doneCount, onToggle }) {
  const { t } = useAppSettings();
  const percent = Math.round((doneCount / (items.length || 1)) * 100);
  const spoken = `${t('readyChecklist')}. ${doneCount} ${t('readyOf')} ${items.length}. ${items
    .map((item) => `${item.label}${doneKeys.has(item.key) ? `. ${t('done')}` : ''}`)
    .join('. ')}`;

  return (
    <div className="mb-6">
      <p className="font-heading text-2xl text-foreground">{t('readyChecklist')}</p>
      <p className="text-muted-foreground font-semibold mb-3">{t('readyChecklistHint')}</p>
      <ReadAloudButton text={spoken} />

      <div className="p-5 rounded-3xl bg-card border-2 border-border mb-4">
        <div className="flex justify-between items-baseline font-bold text-foreground mb-2">
          <span className="text-3xl">{doneCount} / {items.length}</span>
          <span className="text-earth-lagoonDark">{t('readyOf')}</span>
        </div>
        <div className="h-5 rounded-full bg-secondary overflow-hidden">
          <div className="h-full bg-earth-lagoon transition-all" style={{ width: `${percent}%` }} />
        </div>
        {doneCount === items.length && (
          <p className="mt-3 font-bold text-earth-lagoonDark">{t('readyAllDone')}</p>
        )}
      </div>

      <div className="space-y-3">
        {items.map((item) => {
          const done = doneKeys.has(item.key);
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onToggle(item)}
              className={`w-full flex items-start gap-4 p-4 rounded-2xl border-2 text-left min-h-[64px] transition ${
                done ? 'bg-earth-lagoon/10 border-earth-lagoon/50' : 'bg-card border-border'
              }`}
            >
              <span className={`w-9 h-9 rounded-xl border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                done ? 'bg-earth-lagoon border-earth-lagoon' : 'border-border'
              }`}>
                {done && <Check className="w-6 h-6 text-white" strokeWidth={3} />}
              </span>
              <span className="flex-1 min-w-0">
                <span className={`block font-bold text-lg ${done ? 'text-earth-lagoonDark' : 'text-foreground'}`}>
                  {item.label}
                </span>
                {item.hint && <span className="block text-muted-foreground">{item.hint}</span>}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}