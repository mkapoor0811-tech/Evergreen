import React from 'react';
import { Sun, Snowflake } from 'lucide-react';
import ReadAloudButton from '@/components/ReadAloudButton';

const TONES = {
  marigold: 'border-earth-marigold/50 bg-earth-marigold/15',
  lagoon: 'border-earth-lagoon/40 bg-earth-lagoon/10',
};

const ICONS = { marigold: Sun, lagoon: Snowflake };

export default function ReadinessTips({ title, tips, tone = 'marigold' }) {
  const Icon = ICONS[tone] || Sun;

  return (
    <div className={`mb-6 p-5 rounded-3xl border-2 ${TONES[tone] || TONES.marigold}`}>
      <div className="flex items-center gap-3 mb-3">
        <span className="w-12 h-12 blob bg-card flex items-center justify-center shrink-0">
          <Icon className="w-7 h-7 text-foreground" strokeWidth={2.25} />
        </span>
        <p className="font-heading text-2xl text-foreground">{title}</p>
      </div>
      <ReadAloudButton text={`${title}. ${tips.join('. ')}`} />
      <ul className="space-y-3">
        {tips.map((tip, index) => (
          <li key={index} className="flex items-start gap-3">
            <span className="w-3 h-3 rounded-full bg-foreground/60 shrink-0 mt-2.5" />
            <span className="flex-1 text-foreground text-lg">{tip}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}