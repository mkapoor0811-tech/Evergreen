import React from 'react';
import { Flashlight } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';
import ReadAloudButton from '@/components/ReadAloudButton';

export default function PowerOutGuide({ steps }) {
  const { t } = useAppSettings();

  return (
    <div className="mb-6 p-5 rounded-3xl border-2 border-earth-navy/40 bg-earth-navy/10">
      <div className="flex items-center gap-3 mb-2">
        <span className="w-12 h-12 blob bg-earth-navy flex items-center justify-center shrink-0">
          <Flashlight className="w-7 h-7 text-white" strokeWidth={2.25} />
        </span>
        <p className="font-heading text-2xl text-foreground">{t('powerOut')}</p>
      </div>
      <ReadAloudButton text={`${t('powerOut')}. ${steps.join('. ')}`} />

      <ol className="space-y-3">
        {steps.map((step, index) => (
          <li key={index} className="flex items-start gap-4 p-4 rounded-2xl bg-card border-2 border-border">
            <span className="w-10 h-10 rounded-full bg-earth-navy text-white font-bold flex items-center justify-center shrink-0">
              {index + 1}
            </span>
            <span className="flex-1 text-foreground text-lg">{step}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}