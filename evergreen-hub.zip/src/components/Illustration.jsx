import React from 'react';
import { cn } from '@/lib/utils';

/**
 * A decorative illustration for the top of a screen: no frame, transparent
 * background, centered, 85% of the screen width on a phone and never wider
 * than 380px, with the height following the picture. It fades in gently and
 * then floats a few pixels up and down — both animations stop on their own
 * when the device is set to reduce motion.
 */
export default function Illustration({ src, alt, className }) {
  return (
    <img
      src={src}
      alt={alt}
      className={cn('block mx-auto mb-6 h-auto w-[85vw] max-w-[min(380px,100%)] animate-illustration', className)}
    />
  );
}