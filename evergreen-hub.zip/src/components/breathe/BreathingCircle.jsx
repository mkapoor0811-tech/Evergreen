import React, { useState, useEffect, useRef } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Wind } from 'lucide-react';

const IN_SECONDS = 4;
const OUT_SECONDS = 6;

export default function BreathingCircle({ minutes, onFinished }) {
  const { t } = useAppSettings();
  const [phase, setPhase] = useState('in');
  const [cycle, setCycle] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(minutes * 60);
  const phaseTimer = useRef(null);

  useEffect(() => {
    let cancelled = false;
    let current = 'in';

    const step = () => {
      if (cancelled) return;
      setPhase(current);
      setCycle((c) => c + 1);
      phaseTimer.current = setTimeout(() => {
        current = current === 'in' ? 'out' : 'in';
        step();
      }, (current === 'in' ? IN_SECONDS : OUT_SECONDS) * 1000);
    };

    step();
    return () => {
      cancelled = true;
      clearTimeout(phaseTimer.current);
    };
  }, [minutes]);

  useEffect(() => {
    const tick = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(tick);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(tick);
  }, [minutes]);

  useEffect(() => {
    if (secondsLeft === 0) onFinished();
  }, [secondsLeft, onFinished]);

  const duration = phase === 'in' ? IN_SECONDS : OUT_SECONDS;
  const mins = Math.floor(secondsLeft / 60);
  const secs = String(secondsLeft % 60).padStart(2, '0');

  return (
    <div className="flex flex-col items-center py-6">
      <div className="relative w-64 h-64 sm:w-80 sm:h-80 flex items-center justify-center">
        <div className="absolute inset-0 rounded-full bg-earth-lagoon/10" />
        <div
          key={cycle}
          className="w-56 h-56 sm:w-72 sm:h-72 rounded-full bg-earth-lagoon/25 border-8 border-earth-lagoon flex items-center justify-center"
          style={{ animation: `${phase === 'in' ? 'breathe-in' : 'breathe-out'} ${duration}s ease-in-out forwards` }}
        >
          <span className="font-heading text-3xl sm:text-4xl text-earth-lagoonDark text-center px-4">
            {phase === 'in' ? t('breatheIn') : t('breatheOut')}
          </span>
        </div>
      </div>

      <p className="mt-8 text-3xl font-bold text-foreground tabular-nums">
        {mins}:{secs}
      </p>
      <p className="mt-2 flex items-center gap-2 text-muted-foreground font-semibold">
        <Wind className="w-6 h-6" strokeWidth={2.5} />
        {t('breatheDesc')}
      </p>
    </div>
  );
}