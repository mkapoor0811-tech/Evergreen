import React, { useState, useEffect } from 'react';
import { Volume2, Square } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';
import { LOCALES } from '@/lib/timeFormat';

/** Reads a piece of text on this screen out loud. Used on nearly every page. */
export default function ReadAloudButton({ text, compact = false, iconOnly = false, className = '' }) {
  const { t, language } = useAppSettings();
  const [speaking, setSpeaking] = useState(false);

  useEffect(() => {
    return () => { if (window.speechSynthesis) window.speechSynthesis.cancel(); };
  }, []);

  const handleClick = () => {
    if (!window.speechSynthesis || !text) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = LOCALES[language] || 'en-US';
    utterance.rate = 0.9;
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
  };

  if (iconOnly) {
    return (
      <button
        type="button"
        onClick={handleClick}
        aria-label={speaking ? t('stopReading') : t('readAloud')}
        title={speaking ? t('stopReading') : t('readAloud')}
        className={`flex items-center justify-center w-12 h-12 rounded-xl border-2 transition ${
          speaking
            ? 'bg-earth-lagoon border-earth-lagoon text-white'
            : 'bg-card border-border text-earth-lagoon hover:bg-earth-lagoon/10'
        } ${className}`}
      >
        {speaking ? <Square className="w-6 h-6" strokeWidth={2.5} /> : <Volume2 className="w-6 h-6" strokeWidth={2.5} />}
      </button>
    );
  }

  return (
    <button
      onClick={handleClick}
      className={`flex items-center justify-center gap-2 font-bold rounded-xl border-2 transition min-h-[56px] ${
        compact ? 'px-5 py-3' : 'w-full py-3 mb-4'
      } ${
        speaking
          ? 'bg-blue-600 border-blue-600 text-white'
          : 'bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100'
      } ${className}`}
    >
      {speaking ? <Square className="w-5 h-5" strokeWidth={2.5} /> : <Volume2 className="w-5 h-5" strokeWidth={2.5} />}
      {speaking ? t('stopReading') : t('readAloud')}
    </button>
  );
}