import React from 'react';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { Settings as SettingsIcon } from 'lucide-react';

/** The gear Settings button, kept in the header of every screen. */
export default function SettingsButton() {
  const { t } = useAppSettings();

  return (
    <Link
      to="/settings"
      aria-label={t('settings')}
      className="shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
    >
      <SettingsIcon className="w-6 h-6" strokeWidth={2.5} />
      <span className="hidden sm:inline">{t('settings')}</span>
    </Link>
  );
}