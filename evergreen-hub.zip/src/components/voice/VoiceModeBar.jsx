import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAppSettings, speechLocale } from '@/lib/AppSettings';
import { todayStr, isMedTakenToday, applyMedTaken, logDose } from '@/lib/medTaken';
import {
  Mic, MicOff, Pill, Heart, PhoneCall, Clock, ShieldAlert, Home, Volume2,
  ChevronDown, ChevronUp,
} from 'lucide-react';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

const COMMANDS = [
  {
    id: 'pills',
    words: [
      'took my pills', 'taken my pills', 'i took my pills', 'my pills', 'pills taken',
      'took my medicine', 'taken my medicine',
      'tomé mis pastillas', 'tome mis pastillas', 'mis pastillas',
      'मैंने गोलियाँ', 'गोलियाँ ले लीं', 'दवा ले ली',
      '我吃过药', '吃过药了', '我的药',
    ],
  },
  {
    id: 'checkin',
    words: [
      "i'm okay", 'i am okay', 'im okay', 'check me in', 'check in',
      'estoy bien', 'registrarme',
      'मैं ठीक हूँ', 'चेक इन',
      '我很好', '报到',
    ],
  },
  {
    id: 'call',
    words: [
      'call my daughter', 'call my son', 'call my family', 'call family', 'call my',
      'llama a mi', 'llamar a la familia',
      'बेटी को कॉल', 'परिवार को कॉल', 'कॉल करो',
      '打给我女儿', '打给家人', '打电话给',
    ],
  },
  {
    id: 'next',
    words: [
      'what is next today', 'whats next today', 'what is next', 'whats next', 'next today',
      'qué sigue', 'que sigue',
      'आज आगे क्या', 'आगे क्या है',
      '今天接下来做什么', '接下来做什么',
    ],
  },
  {
    id: 'scam',
    words: ['is this a scam', 'is this message a scam', 'a scam', 'scam', 'suspicious message', 'estafa', 'धोखा', '诈骗'],
  },
  {
    id: 'home',
    words: ['go home', 'home screen', 'back home', 'ir a inicio', 'घर चलो', '回家'],
  },
];

const NAV_WORDS = [
  { to: '/medications', key: 'medications', words: ['medications', 'my medicines', 'medicine list', 'medicinas', 'दवाएँ', '药'] },
  { to: '/appointments', key: 'appointments', words: ['appointments', 'doctor visits', 'citas', 'अपॉइंटमेंट', '预约'] },
  { to: '/diet', key: 'diet', words: ['diet', 'my meals', 'comida', 'खाना', '饮食'] },
  { to: '/exercise', key: 'exercise', words: ['exercise', 'व्यायाम', '运动'] },
  { to: '/groceries', key: 'groceries', words: ['groceries', 'shopping list', 'compras', 'खरीदारी', '购物'] },
  { to: '/daily-boost', key: 'dailyBoost', words: ['daily boost', 'brain games', 'ज्ञान', '游戏'] },
  { to: '/family-dashboard', key: 'familyDashboard', words: ['family dashboard', 'dashboard', '家人面板'] },
  { to: '/settings', key: 'settings', words: ['settings', 'ajustes', 'सेटिंग', '设置'] },
];

export default function VoiceModeBar({ open, onToggle, simple = false }) {
  const { t, language } = useAppSettings();
  const navigate = useNavigate();
  const [listening, setListening] = useState(false);
  const [heard, setHeard] = useState('');
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [always, setAlways] = useState(false);
  const alwaysRef = useRef(false);
  const recRef = useRef(null);
  const lastStatusRef = useRef('');

  useEffect(() => { alwaysRef.current = always; }, [always]);

  useEffect(() => () => {
    alwaysRef.current = false;
    try { recRef.current?.abort(); } catch { /* noop */ }
    window.speechSynthesis?.cancel();
  }, []);

  // Speaks a confirmation and, when always-listening is on, starts listening again
  // once the confirmation has finished so the app never hears itself.
  const say = (text) => {
    if (!text) return;
    lastStatusRef.current = text;
    setStatus(text);
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = speechLocale(language);
    utterance.rate = 0.9;
    utterance.onend = () => {
      if (alwaysRef.current) setTimeout(() => { if (alwaysRef.current) startListening(); }, 500);
    };
    window.speechSynthesis.speak(utterance);
  };

  const markPills = async () => {
    const meds = await base44.entities.Medication.list('-created_date', 100);
    if (!meds.length) return say(t('voiceSaidNoMeds'));
    const pending = meds.filter((m) => !isMedTakenToday(m));
    if (!pending.length) return say(t('voiceSaidPillsNone'));
    for (const med of pending) {
      await applyMedTaken(med, true);
      await logDose(med, 'taken');
    }
    return say(t('voiceSaidPills').replace('{count}', pending.length));
  };

  const whatsNext = async () => {
    const today = todayStr();
    const meds = await base44.entities.Medication.list('-created_date', 100);
    const pending = meds.filter((m) => !isMedTakenToday(m));
    const page = await base44.entities.Appointment.filter({ date: { $gte: today } }, { sort: 'date', limit: 1 });
    const appt = (page.items || [])[0];
    const parts = [];
    if (pending.length) parts.push(t('voiceSaidNextMeds').replace('{count}', pending.length));
    if (appt) {
      const d = new Date(`${appt.date}T00:00:00`).toLocaleDateString(LOCALES[language] || 'en-US', {
        weekday: 'long', month: 'long', day: 'numeric',
      });
      parts.push(t('voiceSaidNextAppt').replace('{name}', appt.doctor_name).replace('{date}', d));
    }
    if (!parts.length) parts.push(t('voiceSaidNothingNext'));
    return say(parts.join(' '));
  };

  const doCheckIn = async () => {
    const today = todayStr();
    const page = await base44.entities.CheckIn.filter({ date: today }, { limit: 1 });
    const existing = (page.items || [])[0];
    if (existing && existing.checked_in) return say(t('voiceSaidAlreadyCheckedIn'));
    const payload = { checked_in: true, checked_in_at: new Date().toISOString() };
    if (existing) await base44.entities.CheckIn.update(existing.id, payload);
    else await base44.entities.CheckIn.create({ date: today, ...payload });
    return say(t('voiceSaidCheckInDone'));
  };

  const callFamily = () => {
    const phone = localStorage.getItem('mahika_caregiver_phone') || '';
    if (!phone) return say(t('voiceSaidNoPhone'));
    say(t('voiceSaidCalling'));
    setTimeout(() => { window.location.href = `tel:${phone.replace(/[^\d+]/g, '')}`; }, 1300);
  };

  const goScam = () => { navigate('/scam-checker'); say(t('voiceSaidScam')); };
  const goHome = () => { navigate('/'); say(t('voiceSaidHome')); };
  const goTo = (to, key) => { navigate(to); say(t('voiceSaidOpening').replace('{name}', t(key))); };

  const ACTIONS = {
    pills: markPills,
    checkin: doCheckIn,
    call: callFamily,
    next: whatsNext,
    scam: goScam,
    home: goHome,
  };

  const handleCommand = async (raw) => {
    const text = (raw || '').toLowerCase().trim();
    setHeard(raw);
    if (!text) return;
    const has = (words) => words.some((w) => text.includes(w));

    const command = COMMANDS.find((c) => has(c.words));
    if (command) {
      try { await ACTIONS[command.id](); }
      catch { say(t('voiceSaidDidntCatch')); }
      return;
    }
    const nav = NAV_WORDS.find((n) => has(n.words));
    if (nav) { goTo(nav.to, nav.key); return; }
    say(t('voiceSaidDidntCatch'));
  };

  function startListening() {
    const SR = typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition);
    if (!SR) { setError(t('voiceSpeakUnsupported')); return; }
    try { recRef.current?.abort(); } catch { /* noop */ }
    window.speechSynthesis?.cancel();

    const rec = new SR();
    rec.lang = speechLocale(language);
    rec.continuous = false;
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onresult = (e) => { handleCommand(e.results[0][0].transcript); };
    rec.onerror = (e) => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        setError(t('voiceNotAllowed'));
        setAlways(false);
      }
    };
    rec.onend = () => {
      setListening(false);
      if (alwaysRef.current) setTimeout(() => { if (alwaysRef.current) startListening(); }, 700);
    };
    try {
      rec.start();
      setListening(true);
      setError('');
    } catch {
      setListening(false);
    }
    recRef.current = rec;
  }

  const stopListening = () => {
    alwaysRef.current = false;
    setAlways(false);
    try { recRef.current?.abort(); } catch { /* noop */ }
    setListening(false);
  };

  const toggleAlways = () => {
    if (always) stopListening();
    else { setAlways(true); alwaysRef.current = true; startListening(); }
  };

  const speakAgain = () => say(lastStatusRef.current || t('voiceScreenHint'));

  const bigActions = [
    { id: 'pills', icon: Pill, label: t('voiceCmdPills'), tone: 'bg-earth-terracotta', onClick: markPills },
    { id: 'checkin', icon: Heart, label: t('voiceCmdCheckIn'), tone: 'bg-earth-sage', onClick: doCheckIn },
    { id: 'call', icon: PhoneCall, label: t('voiceCmdCall'), tone: 'bg-earth-lagoon', onClick: callFamily },
    { id: 'next', icon: Clock, label: t('voiceCmdNext'), tone: 'bg-earth-marigold', onClick: whatsNext },
    { id: 'scam', icon: ShieldAlert, label: t('voiceCmdScam'), tone: 'bg-earth-navy', onClick: goScam },
    { id: 'home', icon: Home, label: t('voiceCmdHome'), tone: 'bg-earth-plum', onClick: goHome },
  ];

  if (!open) {
    return (
      <button
        type="button"
        onClick={onToggle}
        aria-label={t('voiceBarTitle')}
        className={`fixed ${simple ? 'bottom-[336px]' : 'bottom-[92px]'} right-4 z-40 w-16 h-16 rounded-full bg-earth-navy text-white shadow-xl flex items-center justify-center hover:bg-earth-navyDark transition`}
      >
        <Mic className="w-8 h-8" strokeWidth={2.25} />
      </button>
    );
  }

  return (
    <div className={`fixed ${simple ? 'bottom-[316px]' : 'bottom-[76px]'} left-0 right-0 z-40 px-3 pb-2`}>
      <div className="max-w-3xl mx-auto rounded-3xl bg-card border-2 border-earth-navy shadow-xl overflow-hidden">
        <div className="bg-earth-lagoon px-4 py-2 flex items-center justify-between">
          <span className="font-heading text-lg text-white">{t('voiceBarTitle')}</span>
          <button onClick={onToggle} className="p-1.5 rounded-lg hover:bg-white/15 text-white min-h-[56px] min-w-[40px] flex items-center justify-center">
            <ChevronDown className="w-6 h-6" strokeWidth={2.5} />
          </button>
        </div>

        <div className="p-3">
          <p className="text-foreground font-semibold min-h-[28px] leading-snug">
            {error ? <span className="text-earth-terracottaDark">{error}</span>
              : listening ? t('voiceListeningNow')
              : status || t('voiceTapToSpeak')}
          </p>
          {heard && !error && (
            <p className="text-muted-foreground text-sm truncate">{t('voiceLastHeard')}: “{heard}”</p>
          )}

          <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
            {bigActions.map(({ id, icon: Icon, label, tone, onClick }) => (
              <button
                key={id}
                type="button"
                onClick={onClick}
                className="flex flex-col items-center justify-center gap-1.5 rounded-2xl border-2 border-border bg-background hover:bg-secondary transition px-2 py-2.5 min-w-[112px] min-h-[96px] shrink-0"
              >
                <span className={`w-11 h-11 blob flex items-center justify-center shrink-0 ${tone} text-white`}>
                  <Icon className="w-6 h-6" strokeWidth={2.5} />
                </span>
                <span className="text-sm font-bold text-foreground leading-tight text-center">{label}</span>
              </button>
            ))}
          </div>

          <div className="flex gap-2 mt-3">
            <button
              type="button"
              onClick={listening ? stopListening : startListening}
              className={`flex-1 flex items-center justify-center gap-2 font-bold py-3.5 rounded-2xl transition min-h-[60px] text-white ${
                listening ? 'bg-earth-terracotta' : 'bg-earth-navy hover:bg-earth-navyDark'
              }`}
            >
              {listening ? <MicOff className="w-6 h-6" strokeWidth={2.5} /> : <Mic className="w-6 h-6" strokeWidth={2.5} />}
              {listening ? t('voiceListeningNow') : t('voiceTapToSpeak')}
            </button>
            <button
              type="button"
              onClick={speakAgain}
              aria-label={t('voiceRepeat')}
              className="w-[60px] flex items-center justify-center rounded-2xl border-2 border-border bg-background hover:bg-secondary transition min-h-[60px]"
            >
              <Volume2 className="w-6 h-6 text-foreground" strokeWidth={2.5} />
            </button>
          </div>

          <div className="flex items-center gap-2 mt-3">
            <button
              type="button"
              onClick={toggleAlways}
              className={`flex-1 flex items-center justify-center gap-2 font-bold py-3 rounded-2xl border-2 transition min-h-[56px] ${
                always ? 'bg-earth-sage text-white border-earth-sage' : 'bg-background text-foreground border-border'
              }`}
            >
              {always ? <ChevronUp className="w-5 h-5" strokeWidth={2.5} /> : <ChevronDown className="w-5 h-5" strokeWidth={2.5} />}
              {always ? t('voiceStopListening') : t('voiceAlwaysListening')}
            </button>
          </div>

          <p className="text-muted-foreground text-sm mt-3">{t('voiceCommandHint')}</p>
        </div>
      </div>
    </div>
  );
}