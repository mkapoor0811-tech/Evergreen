import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import DailyFactCard from '@/components/dailyfact/DailyFactCard';
import { Bookmark } from 'lucide-react';

export default function SavedFacts({ saved, onToggleSave }) {
  const { t } = useAppSettings();
  const [facts, setFacts] = useState([]);
  const key = saved.join(',');

  useEffect(() => {
    if (saved.length === 0) {
      setFacts([]);
      return;
    }
    base44.entities.DailyFact.filter({ id: { $in: saved } }, { limit: 100 })
      .then((page) => setFacts(page.items))
      .catch(() => setFacts([]));
  }, [key]);

  return (
    <section className="mb-8">
      <h2 className="flex items-center gap-2 font-heading text-xl text-foreground mb-4">
        <Bookmark className="w-6 h-6 text-earth-marigoldDark" strokeWidth={2.5} />
        {t('savedFacts')}
      </h2>

      {facts.length === 0 ? (
        <p className="text-muted-foreground font-semibold">{t('noSavedFacts')}</p>
      ) : (
        facts.map((fact) => (
          <DailyFactCard
            key={fact.id}
            fact={fact}
            saved
            onToggleSave={onToggleSave}
          />
        ))
      )}
    </section>
  );
}