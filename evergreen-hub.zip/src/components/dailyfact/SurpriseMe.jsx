import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { getFactBySlot, randomSlot } from '@/lib/dailyFact';
import DailyFactCard from '@/components/dailyfact/DailyFactCard';
import { Shuffle } from 'lucide-react';

export default function SurpriseMe({ saved, onToggleSave }) {
  const { t } = useAppSettings();
  const [fact, setFact] = useState(null);
  const [loading, setLoading] = useState(false);

  const surprise = () => {
    setLoading(true);
    getFactBySlot(randomSlot())
      .then((f) => { setFact(f); setLoading(false); })
      .catch(() => setLoading(false));
  };

  return (
    <section className="mb-8">
      <button
        onClick={surprise}
        disabled={loading}
        className="w-full flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-earth-plum hover:bg-earth-plumDark text-white font-bold transition min-h-[56px] disabled:opacity-60"
      >
        <Shuffle className="w-6 h-6" strokeWidth={2.5} />
        {t('surpriseMe')}
      </button>

      {fact && (
        <div className="mt-4">
          <DailyFactCard
            fact={fact}
            saved={saved.includes(fact.id)}
            onToggleSave={onToggleSave}
          />
        </div>
      )}
    </section>
  );
}