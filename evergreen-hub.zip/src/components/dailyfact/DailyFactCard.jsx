import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import ReadAloudButton from '@/components/ReadAloudButton';
import ExternalLinkDialog from '@/components/learn/ExternalLinkDialog';
import { Bookmark, BookmarkCheck, ExternalLink, Info } from 'lucide-react';

export default function DailyFactCard({ fact, label, dateLabel, saved, onToggleSave, showNote = false }) {
  const { t } = useAppSettings();
  const [showLink, setShowLink] = useState(false);

  if (!fact) return null;
  const hasSource = Boolean(fact.source_url);

  return (
    <article className="rounded-3xl bg-card border-2 border-border overflow-hidden mb-5">
      <div className="p-5">
        <div className="flex items-center justify-between gap-3 mb-2 flex-wrap">
          <span className="px-3 py-1 rounded-full bg-earth-marigold/20 text-earth-marigoldDark font-bold">
            {fact.category}
          </span>
          {dateLabel && <span className="text-muted-foreground font-semibold">{dateLabel}</span>}
        </div>

        {label && <p className="font-heading text-lg text-earth-terracotta mb-1">{label}</p>}

        <div className="flex items-start justify-between gap-3 mb-3">
          <h3 className="font-heading text-2xl text-foreground">{fact.title}</h3>
          {onToggleSave && (
            <button
              onClick={() => onToggleSave(fact.id)}
              aria-label={t('learnSave')}
              className={`shrink-0 flex items-center gap-2 px-3 py-2 rounded-xl border-2 font-bold transition min-h-[56px] ${
                saved
                  ? 'bg-earth-marigold/20 border-earth-marigold text-earth-marigoldDark'
                  : 'bg-secondary border-border text-muted-foreground hover:border-earth-marigold'
              }`}
            >
              {saved
                ? <BookmarkCheck className="w-6 h-6" strokeWidth={2.5} />
                : <Bookmark className="w-6 h-6" strokeWidth={2.5} />}
              <span className="hidden sm:inline">{saved ? t('learnSaved') : t('learnSave')}</span>
            </button>
          )}
        </div>

        <p className="text-foreground text-lg leading-relaxed mb-4">{fact.text}</p>

        <ReadAloudButton text={`${fact.title}. ${fact.text}`} />

        {fact.source_name && (
          <p className="text-muted-foreground mb-4">
            <span className="font-bold">{t('learnSource')}: </span>
            {fact.source_name}
          </p>
        )}

        {hasSource && (
          <button
            onClick={() => setShowLink(true)}
            className="w-full flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-earth-navy hover:bg-earth-navyDark text-white font-bold transition min-h-[56px]"
          >
            <ExternalLink className="w-6 h-6" strokeWidth={2.5} />
            {t('readMore')}
          </button>
        )}

        {showNote && (
          <p className="mt-4 flex items-start gap-2 text-muted-foreground">
            <Info className="w-5 h-5 shrink-0 mt-0.5" strokeWidth={2.5} />
            {t('factNote')}
          </p>
        )}
      </div>

      <ExternalLinkDialog
        open={showLink}
        source={fact.source_name}
        url={fact.source_url}
        onClose={() => setShowLink(false)}
      />
    </article>
  );
}