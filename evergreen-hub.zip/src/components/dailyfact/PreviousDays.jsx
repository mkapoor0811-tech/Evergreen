import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { recentDays, getFactsBySlots } from '@/lib/dailyFact';
import DailyFactCard from '@/components/dailyfact/DailyFactCard';
import { Clock } from 'lucide-react';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };
const MAX_DAYS = 30;

export default function PreviousDays({ saved, onToggleSave }) {
  const { t, language } = useAppSettings();
  const [count, setCount] = useState(7);
  const [facts, setFacts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    const slots = recentDays(count).map((d) => d.slot);
    getFactsBySlots(slots)
      .then((items) => {
        if (cancelled) return;
        setFacts(items);
        setLoading(false);
      })
      .catch(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [count]);

  const bySlot = {};
  facts.forEach((f) => { bySlot[f.slot] = f; });
  const days = recentDays(count);

  return (
    <section className="mb-8">
      <h2 className="flex items-center gap-2 font-heading text-xl text-foreground mb-4">
        <Clock className="w-6 h-6 text-earth-terracotta" strokeWidth={2.5} />
        {t('previousDays')}
      </h2>

      {loading && <p className="text-muted-foreground font-semibold mb-4">{t('factLoading')}</p>}

      {days.map(({ date, slot }) => {
        const fact = bySlot[slot];
        if (!fact) return null;
        const dateLabel = date.toLocaleDateString(LOCALES[language] || 'en-US', {
          weekday: 'short', month: 'short', day: 'numeric',
        });
        return (
          <DailyFactCard
            key={slot}
            fact={fact}
            dateLabel={dateLabel}
            saved={saved.includes(fact.id)}
            onToggleSave={onToggleSave}
          />
        );
      })}

      {count < MAX_DAYS && (
        <button
          onClick={() => setCount(count + 7)}
          className="w-full py-4 rounded-2xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
        >
          {t('showOlder')}
        </button>
      )}
    </section>
  );
}