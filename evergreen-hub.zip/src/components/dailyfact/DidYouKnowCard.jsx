import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { getTodayFact } from '@/lib/dailyFact';
import { useSavedIds } from '@/lib/useSavedIds';
import DailyFactCard from '@/components/dailyfact/DailyFactCard';
import { ArrowRight } from 'lucide-react';

export default function DidYouKnowCard() {
  const { t } = useAppSettings();
  const [fact, setFact] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saved, toggleSaved] = useSavedIds('mahika_facts_saved', 'mahika-facts-saved');

  useEffect(() => {
    getTodayFact()
      .then((f) => { setFact(f); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="mb-6 p-5 rounded-3xl bg-card border-2 border-border text-muted-foreground font-semibold">
        {t('factLoading')}
      </div>
    );
  }

  if (!fact) return null;

  return (
    <section className="mb-6">
      <DailyFactCard
        fact={fact}
        label={t('didYouKnow')}
        saved={saved.includes(fact.id)}
        onToggleSave={toggleSaved}
        showNote
      />
      <Link
        to="/daily-boost"
        className="flex items-center justify-center gap-2 py-4 rounded-2xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
      >
        {t('previousDays')}
        <ArrowRight className="w-6 h-6" strokeWidth={2.5} />
      </Link>
    </section>
  );
}