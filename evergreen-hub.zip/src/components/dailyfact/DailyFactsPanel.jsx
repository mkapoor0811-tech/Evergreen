import React from 'react';
import { useSavedIds } from '@/lib/useSavedIds';
import SurpriseMe from '@/components/dailyfact/SurpriseMe';
import PreviousDays from '@/components/dailyfact/PreviousDays';
import SavedFacts from '@/components/dailyfact/SavedFacts';

export default function DailyFactsPanel() {
  const [saved, toggleSaved] = useSavedIds('mahika_facts_saved', 'mahika-facts-saved');

  return (
    <div>
      <SurpriseMe saved={saved} onToggleSave={toggleSaved} />
      <PreviousDays saved={saved} onToggleSave={toggleSaved} />
      <SavedFacts saved={saved} onToggleSave={toggleSaved} />
    </div>
  );
}