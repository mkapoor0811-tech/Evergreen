import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { turnFlashlightOn, turnFlashlightOff } from '@/lib/flashlight';
import { Flashlight, Phone, PhoneCall, ArrowLeft } from 'lucide-react';

export default function NightMode({ onExit }) {
  const { t } = useAppSettings();
  const [time, setTime] = useState(new Date());
  const [phone, setPhone] = useState(() => localStorage.getItem('mahika_caregiver_phone') || '');
  const [flashlightOn, setFlashlightOn] = useState(false);
  const [torchSupported, setTorchSupported] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const onFocus = () => setPhone(localStorage.getItem('mahika_caregiver_phone') || '');
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, []);

  useEffect(() => {
    return () => { turnFlashlightOff(); };
  }, []);

  const toggleFlashlight = async () => {
    if (flashlightOn) {
      await turnFlashlightOff();
      setFlashlightOn(false);
    } else {
      const success = await turnFlashlightOn();
      setTorchSupported(success);
      setFlashlightOn(true);
    }
  };

  const timeStr = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const dateStr = time.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
  const phoneDigits = phone.replace(/[^\d+]/g, '');

  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-between p-6 z-50">
      <button
        onClick={onExit}
        className="self-start flex items-center gap-2 text-gray-400 hover:text-white font-bold transition py-2"
      >
        <ArrowLeft className="w-6 h-6" />
        {t('exitNightMode')}
      </button>

      <div className="text-center">
        <p className="text-white text-7xl sm:text-8xl font-bold tracking-tight">{timeStr}</p>
        <p className="text-gray-400 text-xl mt-2 capitalize">{dateStr}</p>
      </div>

      <div className="w-full max-w-sm space-y-4">
        <button
          onClick={toggleFlashlight}
          className={`w-full flex items-center justify-center gap-3 py-8 rounded-2xl font-bold text-2xl transition min-h-[80px] ${
            flashlightOn
              ? 'bg-yellow-400 text-black'
              : 'bg-white text-black'
          }`}
        >
          <Flashlight className="w-10 h-10" strokeWidth={2.5} />
          {flashlightOn ? t('flashlightOn') : t('flashlightOff')}
        </button>
        {!torchSupported && flashlightOn && (
          <p className="text-gray-500 text-center text-sm">{t('flashlightNotSupported')}</p>
        )}

        {phone ? (
          <a
            href={`tel:${phoneDigits}`}
            className="block w-full p-6 rounded-2xl bg-red-600 hover:bg-red-700 transition text-center"
          >
            <div className="flex items-center justify-center gap-3">
              <PhoneCall className="w-8 h-8 text-white" strokeWidth={2.5} />
              <span className="text-white text-2xl font-bold">{t('emergencyCall')}</span>
            </div>
          </a>
        ) : (
          <Link
            to="/settings"
            className="block w-full p-6 rounded-2xl bg-red-900 border-2 border-dashed border-red-500 transition text-center"
          >
            <div className="flex items-center justify-center gap-3">
              <Phone className="w-8 h-8 text-red-400" strokeWidth={2.5} />
              <span className="text-red-300 text-xl font-bold">{t('setEmergencyContact')}</span>
            </div>
          </Link>
        )}
      </div>
    </div>
  );
}