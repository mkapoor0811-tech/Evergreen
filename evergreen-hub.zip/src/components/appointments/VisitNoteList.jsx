import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import ReadAloudButton from '@/components/ReadAloudButton';
import { formatNoteTime, notesNewestFirst } from '@/lib/visitNotes';
import { StickyNote, Share2 } from 'lucide-react';

/** A visit's saved notes, newest first. Reading only here — the visit page writes them. */
export default function VisitNoteList({ appt }) {
  const { t, language } = useAppSettings();
  const notes = notesNewestFirst(appt);

  const heading = 'font-heading text-lg text-foreground mb-2 flex items-center gap-2';
  const readAloudText = notes
    .map((n) => `${formatNoteTime(n.created_at, language)}. ${n.text}`)
    .join(' ');

  return (
    <div>
      <h3 className={heading}>
        <StickyNote className="w-5 h-5 shrink-0" strokeWidth={2.25} />
        {t('yourNotes')}
      </h3>

      {notes.length === 0 ? (
        <p className="text-lg text-muted-foreground">{t('noNotesYet')}</p>
      ) : (
        <div className="space-y-3">
          <ReadAloudButton text={readAloudText} compact />
          {notes.map((note) => (
            <div key={note.created_at} className="rounded-xl border-2 border-border p-3">
              <p className="text-lg text-muted-foreground mb-1">
                {formatNoteTime(note.created_at, language)}
              </p>
              <p className="text-lg text-foreground leading-snug whitespace-pre-wrap">{note.text}</p>
              {note.share_with_family && (
                <p className="text-lg font-bold text-earth-sageDark flex items-center gap-2 mt-2">
                  <Share2 className="w-5 h-5 shrink-0" strokeWidth={2.5} />
                  {t('sharedWithFamily')}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}