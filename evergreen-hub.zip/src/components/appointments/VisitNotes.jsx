import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { LOCALES, formatShortDay } from '@/lib/timeFormat';
import VisitNoteList from '@/components/appointments/VisitNoteList';
import { HelpCircle, MessageSquare } from 'lucide-react';

/** A past visit's questions and its recap, shown together. */
export default function VisitNotes({ appt }) {
  const { t, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';
  const questions = appt.questions || [];
  const recap = appt.recap || {};
  const hasRecap = !!(recap.doctor_said || recap.next_steps || recap.next_visit_date);

  const heading = 'font-heading text-lg text-foreground mb-2 flex items-center gap-2';

  return (
    <div className="space-y-4">
      <div>
        <h3 className={heading}>
          <HelpCircle className="w-5 h-5 shrink-0" strokeWidth={2.25} />
          {t('questions')}
        </h3>
        {questions.length === 0 ? (
          <p className="text-lg text-muted-foreground">{t('noQuestionsYet')}</p>
        ) : (
          <ul className="space-y-1">
            {questions.map((q, i) => (
              <li key={i} className="text-lg text-foreground leading-snug">• {q.text}</li>
            ))}
          </ul>
        )}
      </div>

      <div>
        <h3 className={heading}>
          <MessageSquare className="w-5 h-5 shrink-0" strokeWidth={2.25} />
          {t('recap')}
        </h3>
        {!hasRecap ? (
          <p className="text-lg text-muted-foreground">{t('noRecapYet')}</p>
        ) : (
          <div className="space-y-2">
            {recap.doctor_said && <p className="text-lg text-foreground leading-snug">{recap.doctor_said}</p>}
            {recap.next_steps && (
              <p className="text-lg text-foreground leading-snug">
                <span className="font-bold">{t('whatToDoNext')}</span> {recap.next_steps}
              </p>
            )}
            {recap.next_visit_date && (
              <p className="text-lg text-muted-foreground">
                {t('nextVisitOptional')} {formatShortDay(recap.next_visit_date, locale)}
              </p>
            )}
            {recap.share_with_family && (
              <p className="text-lg font-bold text-earth-sageDark">{t('shareRecapWithFamily')}</p>
            )}
          </div>
        )}
      </div>

      <VisitNoteList appt={appt} />
    </div>
  );
}