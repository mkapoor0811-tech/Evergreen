import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { sendToCaregivers } from '@/lib/caregiverAlerts';
import { Share2, Check, Loader2, AlertTriangle } from 'lucide-react';
import { LOCALES, formatTime12 } from '@/lib/timeFormat';

/** One big outlined row that emails this visit to the family. */
export default function ShareWithCaregiverButton({ appt }) {
  const { t, language } = useAppSettings();
  const [state, setState] = useState('idle');

  const share = async () => {
    setState('sending');
    const dateLabel = new Date(`${appt.date}T00:00:00`).toLocaleDateString(LOCALES[language] || 'en-US', {
      weekday: 'long', month: 'long', day: 'numeric',
    });
    const lines = [
      `<strong>${appt.doctor_name}</strong> — ${dateLabel} ${t('time')} ${formatTime12(appt.time, LOCALES[language] || 'en-US')}`,
      appt.notes ? `${t('notes')}: ${appt.notes}` : null,
      appt.visit_notes ? `${t('visitNotes')}: ${appt.visit_notes}` : null,
      appt.follow_up_instructions ? `${t('followUpInstructions')}: ${appt.follow_up_instructions}` : null,
    ].filter(Boolean);

    const res = await sendToCaregivers({
      subject: `${appt.doctor_name} — ${dateLabel}`,
      heading: t('shareEmailHeading'),
      intro: t('shareEmailIntro'),
      lines,
      footer: t('shareEmailFooter'),
    });
    setState(res.sent > 0 ? 'sent' : 'failed');
    setTimeout(() => setState('idle'), 5000);
  };

  const Icon = state === 'sending' ? Loader2
    : state === 'sent' ? Check
    : state === 'failed' ? AlertTriangle
    : Share2;
  const label = state === 'sent' ? t('shareSent')
    : state === 'failed' ? t('shareFailed')
    : t('shareWithFamily');

  return (
    <button
      type="button"
      onClick={share}
      disabled={state === 'sending'}
      className="w-full flex items-center gap-4 px-6 py-5 rounded-2xl border-2 border-border bg-card text-foreground font-bold text-xl transition hover:border-earth-lagoon disabled:opacity-60 min-h-[68px]"
    >
      <Icon className={`w-7 h-7 shrink-0 ${state === 'sending' ? 'animate-spin' : ''}`} strokeWidth={2.5} />
      <span className="flex-1 text-left">{label}</span>
    </button>
  );
}