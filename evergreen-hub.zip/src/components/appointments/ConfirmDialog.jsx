import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Trash2 } from 'lucide-react';

/** A plain "Are you sure?" popup. */
export default function ConfirmDialog({ title, message, confirmLabel, onConfirm, onClose }) {
  const { t } = useAppSettings();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onClick={onClose}
    >
      <div
        className="bg-card rounded-3xl p-6 max-w-md w-full border-2 border-border"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="font-heading text-2xl text-foreground mb-2">{title}</h3>
        {message && <p className="text-xl text-muted-foreground mb-5">{message}</p>}

        <div className="flex flex-col gap-3">
          <button
            onClick={onConfirm}
            className="w-full flex items-center justify-center gap-3 py-4 rounded-xl bg-destructive hover:bg-destructive/90 text-white font-bold text-xl min-h-[64px]"
          >
            <Trash2 className="w-6 h-6" strokeWidth={2.5} />
            {confirmLabel}
          </button>
          <button
            onClick={onClose}
            className="w-full py-4 rounded-xl border-2 border-border font-bold text-foreground text-xl min-h-[64px]"
          >
            {t('cancel')}
          </button>
        </div>
      </div>
    </div>
  );
}