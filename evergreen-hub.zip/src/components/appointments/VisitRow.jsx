import React from 'react';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { formatShortDay, formatTime12 } from '@/lib/timeFormat';
import { ChevronRight } from 'lucide-react';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

/**
 * One visit in the list: who, which day, what time. Tapping it opens the visit.
 * Anything passed as children (Prepare, or a past visit's notes) sits underneath.
 */
export default function VisitRow({ appt, children }) {
  const { language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';

  return (
    <div className="rounded-2xl border-2 border-border bg-card overflow-hidden">
      <Link
        to={`/appointments/${appt.id}`}
        className="flex items-center gap-4 p-5 hover:bg-secondary/40 transition min-h-[80px]"
      >
        <span className="flex-1 min-w-0">
          <span className="block font-heading text-2xl text-foreground leading-tight">{appt.doctor_name}</span>
          <span className="block text-xl text-muted-foreground">
            {formatShortDay(appt.date, locale)} · {formatTime12(appt.time, locale)}
          </span>
        </span>
        <ChevronRight className="w-8 h-8 text-muted-foreground shrink-0" strokeWidth={2.5} />
      </Link>

      {children && <div className="px-5 pb-5">{children}</div>}
    </div>
  );
}