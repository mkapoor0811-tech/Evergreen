import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { formatTime12 } from '@/lib/timeFormat';
import { countdownLabel } from '@/lib/appointmentUtils';
import VisitPrepActions from '@/components/appointments/VisitPrepActions';
import { Phone, Pencil, Info } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

const OUTLINE =
  'w-full flex items-center justify-center gap-3 py-5 rounded-2xl border-2 border-border bg-card text-foreground font-bold transition hover:border-section-plum min-h-[68px] text-2xl';

/** The one big card on the Appointments screen: the next visit and its two plain actions. */
export default function NextVisitCard({ appt, onAddNote }) {
  const { t, language } = useAppSettings();
  const look = useSectionLook();
  const locale = LOCALES[language] || 'en-US';
  const [showPhoneHint, setShowPhoneHint] = useState(false);

  if (!appt) {
    return (
      <section className="mb-6 rounded-3xl bg-card border-2 border-border p-6">
        <p className="text-2xl font-heading text-foreground text-center leading-snug">{t('noUpcomingVisits')}</p>
      </section>
    );
  }

  return (
    <section className="mb-6 rounded-3xl bg-card border-2 border-section-plum/40 overflow-hidden">
      <div className={`${look.bar} px-6 py-3`}>
        <h2 className="font-heading text-2xl text-white">{t('nextVisit')}</h2>
      </div>

      <div className="p-6">
        <p className="font-heading text-3xl text-foreground leading-tight mb-2">{appt.doctor_name}</p>
        <p className="text-2xl text-foreground mb-6 leading-snug">
          {countdownLabel(appt.date, t)}, {formatTime12(appt.time, locale)}
        </p>

        {appt.doctor_phone ? (
          <a href={`tel:${appt.doctor_phone}`} className={`${OUTLINE} mb-3`}>
            <Phone className="w-8 h-8" strokeWidth={2.5} />
            {t('callOffice')}
          </a>
        ) : (
          <>
            <button onClick={() => setShowPhoneHint((v) => !v)} className={`${OUTLINE} mb-3`}>
              <Phone className="w-8 h-8" strokeWidth={2.5} />
              {t('callOffice')}
            </button>
            {showPhoneHint && (
              <p className="flex items-start gap-2 text-lg text-muted-foreground mb-3">
                <Info className="w-5 h-5 shrink-0 mt-1" />
                {t('callOfficeHint')}
              </p>
            )}
          </>
        )}

        <button onClick={() => onAddNote(appt)} className={OUTLINE}>
          <Pencil className="w-8 h-8" strokeWidth={2.5} />
          {t('addNote')}
        </button>

        <div className="mt-3">
          <VisitPrepActions appt={appt} />
        </div>
      </div>
    </section>
  );
}