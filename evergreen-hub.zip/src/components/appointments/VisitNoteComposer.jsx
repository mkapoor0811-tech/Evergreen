import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import VoiceButton from '@/components/VoiceButton';
import ActionButton from '@/components/ActionButton';
import { loadNoteDraft, saveNoteDraft, clearNoteDraft } from '@/lib/visitNotes';
import { Plus } from 'lucide-react';

/**
 * The box where a new note about a visit is typed or spoken.
 * Whatever is typed is kept on the device as a draft, so leaving the screen loses nothing.
 */
export default function VisitNoteComposer({ apptId, onAdd }) {
  const { t } = useAppSettings();
  const [text, setText] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setText(loadNoteDraft(apptId));
  }, [apptId]);

  const change = (value) => {
    setText(value);
    saveNoteDraft(apptId, value);
  };

  const add = async () => {
    const body = text.trim();
    if (!body) return;
    setSaving(true);
    await onAdd(body);
    clearNoteDraft(apptId);
    setText('');
    setSaving(false);
  };

  return (
    <div>
      <div className="flex items-start gap-3">
        <textarea
          value={text}
          onChange={(e) => change(e.target.value)}
          placeholder={t('addNoteAboutVisit')}
          aria-label={t('addNoteAboutVisit')}
          className="flex-1 w-full rounded-2xl border-2 border-border bg-card p-4 text-lg text-foreground leading-snug min-h-[140px] focus:border-earth-lagoon focus:outline-none"
        />
        <VoiceButton
          compact
          label={t('sayNote')}
          prompt={t('sayNotePrompt')}
          onResult={(spoken) => change(text ? `${text} ${spoken}` : spoken)}
        />
      </div>

      <ActionButton onClick={add} disabled={!text.trim() || saving} className="w-full mt-3">
        <Plus className="w-6 h-6" strokeWidth={2.5} />
        {t('addNote')}
      </ActionButton>

      {text.trim() !== '' && (
        <p className="text-lg text-muted-foreground mt-3">{t('noteDraftSaved')}</p>
      )}
      <p className="text-lg text-muted-foreground mt-3">{t('recapNotAdvice')}</p>
    </div>
  );
}