import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Plus } from 'lucide-react';

/** Four questions the person can add to their list with one tap. */
export default function StarterQuestions({ onAdd, existing }) {
  const { t } = useAppSettings();
  const starters = [t('starter1'), t('starter2'), t('starter3'), t('starter4')];
  const already = (existing || []).map((q) => q.text);

  return (
    <div>
      <h2 className="font-heading text-xl text-foreground mb-3">{t('starterQuestions')}</h2>
      <div className="space-y-2">
        {starters.map((text) => {
          const used = already.includes(text);
          return (
            <button
              key={text}
              onClick={() => onAdd(text)}
              disabled={used}
              className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl border-2 font-bold text-lg text-left transition min-h-[56px] ${
                used
                  ? 'border-border bg-secondary text-muted-foreground'
                  : 'border-earth-marigold/60 bg-earth-marigold/10 text-foreground hover:bg-earth-marigold/20'
              }`}
            >
              <Plus className="w-6 h-6 shrink-0" strokeWidth={2.5} />
              <span className="flex-1">{text}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}