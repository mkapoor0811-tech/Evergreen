import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import ToggleRow from '@/components/settings/ToggleRow';
import ActionButton from '@/components/ActionButton';
import { formatNoteTime } from '@/lib/visitNotes';
import { Pencil, Trash2, Check, X } from 'lucide-react';

/** One saved note: what it says, when it was written, and Edit, Delete and Share. */
export default function VisitNoteRow({ note, language, onEdit, onDelete, onToggleShare }) {
  const { t } = useAppSettings();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(note.text || '');

  const startEdit = () => {
    setDraft(note.text || '');
    setEditing(true);
  };

  const saveEdit = async () => {
    const body = draft.trim();
    if (!body) return;
    await onEdit(body);
    setEditing(false);
  };

  return (
    <div className="rounded-2xl border-2 border-border bg-card p-4">
      <p className="text-lg text-muted-foreground mb-2">{formatNoteTime(note.created_at, language)}</p>

      {editing ? (
        <>
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            aria-label={t('edit')}
            className="w-full rounded-xl border-2 border-border bg-card p-3 text-lg text-foreground leading-snug min-h-[120px] focus:border-earth-lagoon focus:outline-none"
          />
          <div className="flex gap-3 mt-3">
            <ActionButton size="compact" onClick={saveEdit} disabled={!draft.trim()} className="flex-1">
              <Check className="w-6 h-6" strokeWidth={2.5} />
              {t('save')}
            </ActionButton>
            <ActionButton variant="secondary" size="compact" onClick={() => setEditing(false)} className="flex-1">
              <X className="w-6 h-6" strokeWidth={2.5} />
              {t('cancel')}
            </ActionButton>
          </div>
        </>
      ) : (
        <>
          <p className="text-lg text-foreground leading-snug whitespace-pre-wrap">{note.text}</p>

          <div className="flex gap-3 mt-3">
            <ActionButton variant="secondary" size="compact" onClick={startEdit} className="flex-1">
              <Pencil className="w-6 h-6" strokeWidth={2.5} />
              {t('edit')}
            </ActionButton>
            <ActionButton variant="secondary" size="compact" onClick={onDelete} className="flex-1">
              <Trash2 className="w-6 h-6" strokeWidth={2.5} />
              {t('delete')}
            </ActionButton>
          </div>

          <div className="mt-3">
            <ToggleRow
              label={t('shareNoteWithFamily')}
              on={!!note.share_with_family}
              onToggle={onToggleShare}
            />
          </div>
        </>
      )}
    </div>
  );
}