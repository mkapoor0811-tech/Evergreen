import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { X, Check } from 'lucide-react';

/** One notes field in a popup. */
export default function NoteDialog({ title, value, onSave, onClose }) {
  const { t } = useAppSettings();
  const [text, setText] = useState(value || '');

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onClick={onClose}
    >
      <div
        className="bg-card rounded-3xl p-6 max-w-md w-full border-2 border-border"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-heading text-2xl text-foreground">{title}</h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-secondary" aria-label={t('cancel')}>
            <X className="w-7 h-7 text-muted-foreground" />
          </button>
        </div>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={4}
          className="w-full px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-xl resize-none"
        />

        <div className="flex gap-3 mt-5">
          <button
            onClick={onClose}
            className="flex-1 py-4 rounded-xl border-2 border-border font-bold text-foreground text-xl min-h-[64px]"
          >
            {t('cancel')}
          </button>
          <button
            onClick={() => onSave(text.trim())}
            className="flex-1 flex items-center justify-center gap-2 py-4 rounded-xl bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold text-xl min-h-[64px]"
          >
            <Check className="w-6 h-6" strokeWidth={3} />
            {t('save')}
          </button>
        </div>
      </div>
    </div>
  );
}