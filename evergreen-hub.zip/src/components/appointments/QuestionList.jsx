import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import ConfirmDialog from '@/components/appointments/ConfirmDialog';
import VoiceButton from '@/components/VoiceButton';
import { Plus, Trash2 } from 'lucide-react';

/** The person's own questions for a visit: type or say one, remove one. */
export default function QuestionList({ questions, onChange }) {
  const { t } = useAppSettings();
  const [draft, setDraft] = useState('');
  const [removeAt, setRemoveAt] = useState(null);
  const list = questions || [];

  const add = (text) => {
    const clean = (text || '').trim();
    if (!clean) return;
    onChange([...list, { text: clean }]);
    setDraft('');
  };

  const remove = () => {
    onChange(list.filter((_, i) => i !== removeAt));
    setRemoveAt(null);
  };

  return (
    <div>
      <h2 className="font-heading text-xl text-foreground mb-3">{t('yourQuestions')}</h2>

      {list.length === 0 ? (
        <p className="text-lg text-muted-foreground mb-4">{t('noQuestionsYet')}</p>
      ) : (
        <ul className="space-y-2 mb-4">
          {list.map((q, i) => (
            <li key={i} className="flex items-center gap-3 p-4 rounded-2xl border-2 border-border bg-card">
              <span className="flex-1 text-xl text-foreground leading-snug">{q.text}</span>
              <button
                onClick={() => setRemoveAt(i)}
                aria-label={t('removeLabel')}
                className="shrink-0 w-[56px] h-[56px] flex items-center justify-center rounded-xl border-2 border-destructive/40 text-destructive hover:bg-destructive/10 transition"
              >
                <Trash2 className="w-6 h-6" strokeWidth={2.5} />
              </button>
            </li>
          ))}
        </ul>
      )}

      <div className="flex gap-3">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={t('addQuestionPlaceholder')}
          className="flex-1 min-w-0 px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-xl min-h-[56px]"
        />
        <button
          onClick={() => add(draft)}
          disabled={!draft.trim()}
          className="shrink-0 flex items-center gap-2 px-6 rounded-xl bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold text-xl transition disabled:opacity-40 min-h-[56px]"
        >
          <Plus className="w-6 h-6" strokeWidth={2.5} />
          {t('addQuestion')}
        </button>
      </div>

      <div className="mt-3 flex items-center gap-3">
        <VoiceButton compact label={t('sayQuestion')} onResult={add} />
        <span className="text-lg font-semibold text-muted-foreground">{t('sayQuestion')}</span>
      </div>

      {removeAt !== null && (
        <ConfirmDialog
          title={t('areYouSure')}
          message={list[removeAt]?.text}
          confirmLabel={t('removeLabel')}
          onConfirm={remove}
          onClose={() => setRemoveAt(null)}
        />
      )}
    </div>
  );
}