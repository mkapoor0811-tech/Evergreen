import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { formatTime12 } from '@/lib/timeFormat';
import { countdownLabel } from '@/lib/appointmentUtils';
import { Bell } from 'lucide-react';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

const iso = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

/** A reminder card that appears only when a visit is today or tomorrow. */
export default function UpcomingReminder() {
  const { t, language } = useAppSettings();
  const [appt, setAppt] = useState(null);

  useEffect(() => {
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    base44.entities.Appointment
      .filter(
        { date: { $in: [iso(today), iso(tomorrow)] }, reminders_on: { $ne: false } },
        { sort: 'date', limit: 1 },
      )
      .then(({ items }) => setAppt(items[0] || null))
      .catch(() => {});
  }, []);

  if (!appt) return null;

  const locale = LOCALES[language] || 'en-US';

  return (
    <Link
      to={`/appointments/${appt.id}`}
      className="block mb-8 p-5 rounded-3xl border-2 border-earth-terracotta bg-earth-terracotta/10 hover:bg-earth-terracotta/15 transition"
    >
      <div className="flex items-center gap-4">
        <span className="w-12 h-12 blob bg-earth-terracotta flex items-center justify-center shrink-0">
          <Bell className="w-7 h-7 text-white" strokeWidth={2.5} />
        </span>
        <div className="flex-1 min-w-0">
          <p className="font-heading text-xl text-foreground">{t('apptReminder')}</p>
          <p className="text-lg text-foreground leading-snug">
            {appt.doctor_name} — {countdownLabel(appt.date, t)}, {formatTime12(appt.time, locale)}
          </p>
        </div>
      </div>
    </Link>
  );
}