import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import VoiceButton from '@/components/VoiceButton';

export const FIELD_INPUT = 'w-full px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-xl';
export const FIELD_LABEL = 'block font-bold text-foreground mb-2 text-lg';

/** A large text box that also accepts speech. */
export default function VoiceField({ label, value, onChange, rows = 4, placeholder, voiceLabel }) {
  const { t } = useAppSettings();
  const hint = voiceLabel || t('sayQuestion');

  return (
    <div>
      {label && <label className={FIELD_LABEL}>{label}</label>}
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={rows}
        placeholder={placeholder}
        className={`${FIELD_INPUT} resize-none`}
      />
      <div className="mt-3 flex items-center gap-3">
        <VoiceButton
          compact
          label={hint}
          onResult={(text) => onChange(value ? `${value} ${text}` : text)}
        />
        <span className="text-lg font-semibold text-muted-foreground">{hint}</span>
      </div>
    </div>
  );
}