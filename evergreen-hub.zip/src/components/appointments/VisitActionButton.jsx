import React from 'react';

/** One big outlined row on a visit's own page. */
export default function VisitActionButton({ icon: Icon, label, value, onClick, danger = false }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-6 py-5 rounded-2xl border-2 bg-card font-bold text-xl transition min-h-[68px] ${
        danger
          ? 'border-destructive/40 text-destructive hover:bg-destructive/10'
          : 'border-border text-foreground hover:border-earth-lagoon'
      }`}
    >
      <Icon className="w-7 h-7 shrink-0" strokeWidth={2.5} />
      <span className="flex-1 text-left">{label}</span>
      {value && <span className="shrink-0 text-muted-foreground">{value}</span>}
    </button>
  );
}