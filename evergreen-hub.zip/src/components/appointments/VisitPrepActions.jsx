import React from 'react';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { visitHasPassed } from '@/lib/appointmentUtils';
import { ClipboardList, PenLine } from 'lucide-react';

const BTN = 'flex-1 flex items-center justify-center gap-2 py-4 rounded-xl border-2 font-bold transition min-h-[56px] text-lg';

/** "Prepare" for one visit, plus "Add recap" once the visit time has passed. */
export default function VisitPrepActions({ appt }) {
  const { t } = useAppSettings();

  return (
    <div className="flex gap-2">
      <Link
        to={`/appointments/${appt.id}/prepare`}
        className={`${BTN} border-earth-lagoon/50 bg-card text-earth-lagoonDark hover:bg-earth-lagoon/10`}
      >
        <ClipboardList className="w-6 h-6" strokeWidth={2.5} />
        {t('prepare')}
      </Link>

      {visitHasPassed(appt) && (
        <Link
          to={`/appointments/${appt.id}/recap`}
          className={`${BTN} border-earth-marigold/60 bg-card text-earth-marigoldDark hover:bg-earth-marigold/10`}
        >
          <PenLine className="w-6 h-6" strokeWidth={2.5} />
          {t('addRecap')}
        </Link>
      )}
    </div>
  );
}