import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { formatTime12 } from '@/lib/timeFormat';
import { Bell } from 'lucide-react';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

const iso = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

/** Appears when an appointment today starts within the next hour. */
export default function AppointmentSoonReminder() {
  const { t, language } = useAppSettings();
  const [soon, setSoon] = useState(null);

  useEffect(() => {
    base44.entities.Appointment
      .filter(
        { date: iso(new Date()), reminders_on: { $ne: false } },
        { sort: 'time', limit: 20 },
      )
      .then(({ items }) => {
        const now = new Date();
        const next = (items || [])
          .map((appt) => ({
            appt,
            minutes: Math.round((new Date(`${appt.date}T${appt.time || '09:00'}:00`) - now) / 60000),
          }))
          .filter((row) => row.minutes >= 0 && row.minutes <= 60)
          .sort((a, b) => a.minutes - b.minutes)[0];
        if (next) setSoon(next);
      })
      .catch(() => {});
  }, []);

  if (!soon) return null;

  const { appt, minutes } = soon;
  const when = minutes <= 0 ? t('apptNow') : t('apptInMinutes').replace('{count}', String(minutes));

  return (
    <Link
      to={`/appointments/${appt.id}`}
      className="block mb-8 p-5 rounded-3xl border-4 border-earth-terracotta bg-earth-terracotta/15 hover:bg-earth-terracotta/20 transition"
    >
      <div className="flex items-center gap-4">
        <span className="w-14 h-14 blob bg-earth-terracotta flex items-center justify-center shrink-0">
          <Bell className="w-8 h-8 text-white" strokeWidth={2.5} />
        </span>
        <div className="flex-1 min-w-0">
          <p className="font-heading text-2xl text-foreground">{t('apptSoon')}</p>
          <p className="text-lg text-foreground font-semibold leading-snug">
            {appt.doctor_name} — {formatTime12(appt.time, LOCALES[language] || 'en-US')}
          </p>
          <p className="text-lg text-earth-terracottaDark font-bold">{when}</p>
        </div>
      </div>
    </Link>
  );
}