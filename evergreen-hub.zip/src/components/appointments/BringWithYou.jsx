import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Pill } from 'lucide-react';

/** The medicine list, read from the Medications screen. */
export default function BringWithYou({ meds }) {
  const { t } = useAppSettings();

  return (
    <div>
      <h2 className="font-heading text-xl text-foreground mb-3">{t('bringWithYou')}</h2>
      {meds.length === 0 ? (
        <p className="text-lg text-muted-foreground">{t('noMedicines')}</p>
      ) : (
        <ul className="space-y-2">
          {meds.map((m) => (
            <li key={m.id} className="flex items-center gap-3 p-4 rounded-2xl border-2 border-border bg-card">
              <Pill className="w-6 h-6 text-earth-lagoonDark shrink-0" strokeWidth={2.25} />
              <span className="flex-1 min-w-0">
                <span className="block text-xl text-foreground leading-tight">{m.name}</span>
                {m.dosage && <span className="block text-lg text-muted-foreground">{m.dosage}</span>}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}