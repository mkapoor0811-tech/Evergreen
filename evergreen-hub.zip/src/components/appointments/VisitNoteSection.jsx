import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { useUndo } from '@/lib/UndoContext';
import SectionCard from '@/components/SectionCard';
import ConfirmDialog from '@/components/appointments/ConfirmDialog';
import VisitNoteComposer from '@/components/appointments/VisitNoteComposer';
import VisitNoteRow from '@/components/appointments/VisitNoteRow';
import ReadAloudButton from '@/components/ReadAloudButton';
import { formatNoteTime, notesNewestFirst } from '@/lib/visitNotes';
import { StickyNote } from 'lucide-react';

/**
 * The Notes section on one visit: write a note, then read, edit, delete or share
 * the ones already saved. Notes are private until the share switch is turned on.
 */
export default function VisitNoteSection({ appt, onSaved }) {
  const { t, language } = useAppSettings();
  const { showUndo } = useUndo();
  const [askDelete, setAskDelete] = useState(null);

  const notes = appt.note_list || [];
  const saved = notesNewestFirst(appt);

  const save = async (list) => {
    await base44.entities.Appointment.update(appt.id, { note_list: list });
    onSaved();
  };

  const addNote = (text) =>
    save([...notes, { text, created_at: new Date().toISOString(), share_with_family: false }]);

  const editNote = (index, text) =>
    save(notes.map((n, i) => (i === index ? { ...n, text } : n)));

  const toggleShare = (index) =>
    save(notes.map((n, i) => (i === index ? { ...n, share_with_family: !n.share_with_family } : n)));

  const deleteNote = async () => {
    const index = askDelete;
    const removed = notes[index];
    const remaining = notes.filter((_, i) => i !== index);
    setAskDelete(null);
    await save(remaining);
    showUndo(t('noteDeleted'), async () => {
      const restored = [...remaining];
      restored.splice(index, 0, removed);
      await save(restored);
    });
  };

  const readAloudText = saved
    .map((n) => `${formatNoteTime(n.created_at, language)}. ${n.text}`)
    .join(' ');

  return (
    <>
      <SectionCard title={t('yourNotes')} icon={StickyNote}>
        <VisitNoteComposer apptId={appt.id} onAdd={addNote} />

        {saved.length === 0 ? (
          <p className="text-lg text-muted-foreground mt-5">{t('noNotesYet')}</p>
        ) : (
          <div className="mt-6">
            <ReadAloudButton text={readAloudText} compact />
            <div className="space-y-4 mt-4">
              {saved.map((note) => (
                <VisitNoteRow
                  key={note.created_at}
                  note={note}
                  language={language}
                  onEdit={(text) => editNote(notes.indexOf(note), text)}
                  onDelete={() => setAskDelete(notes.indexOf(note))}
                  onToggleShare={() => toggleShare(notes.indexOf(note))}
                />
              ))}
            </div>
          </div>
        )}
      </SectionCard>

      {askDelete !== null && (
        <ConfirmDialog
          title={t('deleteThisNote')}
          confirmLabel={t('yesDelete')}
          onConfirm={deleteNote}
          onClose={() => setAskDelete(null)}
        />
      )}
    </>
  );
}