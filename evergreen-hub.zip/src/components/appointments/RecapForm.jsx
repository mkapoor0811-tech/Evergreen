import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import VoiceField from '@/components/appointments/VoiceField';

/** The recap boxes, the next-visit date and the family sharing switch. */
export default function RecapForm({ recap, onChange }) {
  const { t } = useAppSettings();
  const set = (patch) => onChange({ ...recap, ...patch });

  return (
    <div className="space-y-7">
      <VoiceField
        label={t('whatDoctorSaid')}
        value={recap.doctor_said || ''}
        onChange={(value) => set({ doctor_said: value })}
        rows={5}
      />

      <VoiceField
        label={t('whatToDoNext')}
        value={recap.next_steps || ''}
        onChange={(value) => set({ next_steps: value })}
        rows={4}
      />

      <div>
        <label className="block font-bold text-foreground mb-2 text-lg">{t('nextVisitOptional')}</label>
        <input
          type="date"
          value={recap.next_visit_date || ''}
          onChange={(e) => set({ next_visit_date: e.target.value })}
          className="w-full px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-xl min-h-[56px]"
        />
      </div>

      <p className="text-lg text-muted-foreground">{t('recapNotAdvice')}</p>

      <button
        onClick={() => set({ share_with_family: !recap.share_with_family })}
        aria-pressed={!!recap.share_with_family}
        className={`w-full flex items-center justify-between gap-3 px-5 py-4 rounded-2xl border-2 transition min-h-[64px] ${
          recap.share_with_family ? 'bg-earth-navy/10 border-earth-navy' : 'bg-card border-border'
        }`}
      >
        <span className="font-bold text-xl text-foreground text-left leading-tight">{t('shareRecapWithFamily')}</span>
        <span className={`w-14 h-8 rounded-full p-1 transition shrink-0 ${recap.share_with_family ? 'bg-foreground' : 'bg-border'}`}>
          <span className={`block w-6 h-6 bg-card rounded-full transition ${recap.share_with_family ? 'translate-x-6' : ''}`} />
        </span>
      </button>
    </div>
  );
}