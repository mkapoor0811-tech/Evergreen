import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import VisitRow from '@/components/appointments/VisitRow';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

const iso = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

/** A month grid of visits. Days with visits are marked; tapping a day shows them below. */
export default function AppointmentCalendar({ appts }) {
  const { t, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';
  const now = new Date();
  const [cursor, setCursor] = useState(() => new Date(now.getFullYear(), now.getMonth(), 1));
  const [selected, setSelected] = useState(() => iso(now));

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const todayIso = iso(now);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const leading = new Date(year, month, 1).getDay();

  const byDate = {};
  appts.forEach((a) => {
    if (!byDate[a.date]) byDate[a.date] = [];
    byDate[a.date].push(a);
  });

  const weekdays = Array.from({ length: 7 }, (_, i) =>
    new Date(2024, 0, 7 + i).toLocaleDateString(locale, { weekday: 'short' }),
  );

  const cells = [
    ...Array.from({ length: leading }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];

  const selectedAppts = byDate[selected] || [];

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => setCursor(new Date(year, month - 1, 1))}
          aria-label={t('previousStep')}
          className="w-[56px] h-[56px] rounded-xl border-2 border-border bg-card flex items-center justify-center hover:border-earth-lagoon transition"
        >
          <ChevronLeft className="w-7 h-7 text-foreground" strokeWidth={2.5} />
        </button>
        <h2 className="font-heading text-2xl text-foreground capitalize text-center">
          {cursor.toLocaleDateString(locale, { month: 'long', year: 'numeric' })}
        </h2>
        <button
          onClick={() => setCursor(new Date(year, month + 1, 1))}
          aria-label={t('nextStep')}
          className="w-[56px] h-[56px] rounded-xl border-2 border-border bg-card flex items-center justify-center hover:border-earth-lagoon transition"
        >
          <ChevronRight className="w-7 h-7 text-foreground" strokeWidth={2.5} />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1.5 sm:gap-2 mb-2">
        {weekdays.map((w) => (
          <span key={w} className="text-center text-base font-bold text-muted-foreground">{w}</span>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
        {cells.map((day, i) => {
          if (day === null) return <span key={`empty-${i}`} />;

          const dateIso = iso(new Date(year, month, day));
          const hasVisit = (byDate[dateIso] || []).length > 0;
          const isToday = dateIso === todayIso;
          const isSelected = dateIso === selected;

          return (
            <button
              key={dateIso}
              onClick={() => setSelected(dateIso)}
              className={`min-h-[64px] rounded-xl border-2 flex flex-col items-center justify-center font-bold transition ${
                isSelected
                  ? 'bg-earth-lagoon border-earth-lagoon text-white'
                  : isToday
                    ? 'bg-earth-lagoon/10 border-earth-lagoon text-foreground'
                    : 'bg-card border-border text-foreground hover:border-earth-lagoon'
              }`}
            >
              <span className="text-lg">{day}</span>
              {hasVisit && (
                <span className={`w-2 h-2 rounded-full mt-1 ${isSelected ? 'bg-white' : 'bg-earth-terracotta'}`} />
              )}
            </button>
          );
        })}
      </div>

      <div className="mt-8">
        <h3 className="font-heading text-2xl text-foreground mb-3">
          {new Date(`${selected}T00:00:00`).toLocaleDateString(locale, {
            weekday: 'long', month: 'long', day: 'numeric',
          })}
        </h3>
        {selectedAppts.length === 0 ? (
          <p className="text-xl text-muted-foreground">{t('nothingOnThisDay')}</p>
        ) : (
          <div className="space-y-3">
            {selectedAppts.map((appt) => <VisitRow key={appt.id} appt={appt} />)}
          </div>
        )}
      </div>
    </div>
  );
}