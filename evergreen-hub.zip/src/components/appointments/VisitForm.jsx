import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import VoiceButton from '@/components/VoiceButton';

const INPUT = 'w-full px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-xl';
const LABEL = 'block font-bold text-foreground mb-2 text-lg';

/** Adds or edits a visit. `onSpeak` adds the small microphone button. */
export default function VisitForm({ form, setForm, onSubmit, onCancel, full = false, onSpeak }) {
  const { t } = useAppSettings();

  return (
    <div className="mb-6 p-5 bg-card rounded-3xl border-2 border-border space-y-5">
      {onSpeak && (
        <div className="flex items-center gap-3">
          <VoiceButton
            compact
            label={t('speakInstead')}
            prompt={t('voiceAppointmentPrompt')}
            onResult={onSpeak}
          />
          <span className="text-lg font-semibold text-muted-foreground">{t('speakInstead')}</span>
        </div>
      )}

      <div>
        <label className={LABEL}>{full ? t('doctorName') : t('visitWith')}</label>
        <input
          value={form.doctor_name}
          onChange={(e) => setForm({ ...form, doctor_name: e.target.value })}
          className={INPUT}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className={LABEL}>{t('date')}</label>
          <input
            type="date"
            value={form.date}
            onChange={(e) => setForm({ ...form, date: e.target.value })}
            className={INPUT}
          />
        </div>
        <div>
          <label className={LABEL}>{t('time')}</label>
          <input
            type="time"
            value={form.time}
            onChange={(e) => setForm({ ...form, time: e.target.value })}
            className={INPUT}
          />
        </div>
      </div>

      {full && (
        <div>
          <label className={LABEL}>{t('officePhone')}</label>
          <input
            type="tel"
            value={form.doctor_phone || ''}
            onChange={(e) => setForm({ ...form, doctor_phone: e.target.value })}
            className={INPUT}
          />
        </div>
      )}

      <div className="flex gap-3">
        <button
          onClick={onSubmit}
          disabled={!form.doctor_name.trim()}
          className="flex-1 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-4 rounded-xl transition disabled:opacity-40 min-h-[64px] text-xl"
        >
          {t('save')}
        </button>
        <button
          onClick={onCancel}
          className="px-6 rounded-xl border-2 border-border font-bold text-foreground min-h-[64px] text-xl"
        >
          {t('cancel')}
        </button>
      </div>
    </div>
  );
}