import React from 'react';
import { ArrowRight } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';
import ReadAloudButton from '@/components/ReadAloudButton';
import EvergreenLogo from '@/components/EvergreenLogo';
import { ILLUSTRATIONS } from '@/lib/illustrations';

// Nine pale leaves that drift down at different speeds, each starting part-way
// along its path so they are spread out from the first moment.
const LEAVES = [
  { left: '6%', size: 22, duration: 19, delay: -2 },
  { left: '16%', size: 16, duration: 23, delay: -9 },
  { left: '28%', size: 26, duration: 16, delay: -5 },
  { left: '38%', size: 18, duration: 21, delay: -14 },
  { left: '49%', size: 24, duration: 18, delay: -11 },
  { left: '60%', size: 15, duration: 25, delay: -3 },
  { left: '70%', size: 21, duration: 17, delay: -18 },
  { left: '81%', size: 25, duration: 22, delay: -7 },
  { left: '91%', size: 17, duration: 20, delay: -16 },
];

/**
 * The first thing shown when the app is opened or the page is refreshed.
 * Nothing else is on screen: no top bar, no bottom tabs.
 */
export default function WelcomeSplash({ onStart }) {
  const { t } = useAppSettings();
  const welcomeText = `${t('welcomeToEvergreen')}. ${t('tagline')}`;

  return (
    <div className="fixed inset-0 z-[60] bg-earth-cream overflow-hidden">
      <div className="welcome-sky absolute inset-0 pointer-events-none" aria-hidden="true">
        {LEAVES.map((leaf, i) => (
          <span
            key={i}
            className="welcome-leaf"
            style={{
              left: leaf.left,
              width: `${leaf.size}px`,
              height: `${leaf.size}px`,
              animationDuration: `${leaf.duration}s`,
              animationDelay: `${leaf.delay}s`,
            }}
          />
        ))}
      </div>

      <ReadAloudButton iconOnly text={welcomeText} className="absolute top-4 right-4 z-20" />

      <div className="relative z-10 h-full flex flex-col px-6 py-8">
        <div className="flex-1 min-h-0 flex flex-col items-center justify-center text-center">
          <EvergreenLogo size={72} className="mb-5" />

          <h1 className="font-heading text-4xl text-foreground leading-tight">
            {t('welcomeToEvergreen')}
          </h1>
          <p className="text-2xl font-semibold text-foreground mt-3">{t('tagline')}</p>
          <p className="text-[18px] text-foreground mt-2">{t('welcomeSubline')}</p>

          <img
            src={ILLUSTRATIONS.walking}
            alt=""
            className="animate-illustration mt-6 h-[240px] max-h-[30vh] w-auto max-w-full"
          />
        </div>

        <button
          type="button"
          onClick={onStart}
          className="shrink-0 w-full max-w-md mx-auto flex items-center justify-center gap-3 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold text-2xl py-5 rounded-2xl transition min-h-[64px] focus-visible:outline focus-visible:outline-4 focus-visible:outline-offset-4 focus-visible:outline-earth-navy"
        >
          {t('start')}
          <ArrowRight className="w-8 h-8" strokeWidth={2.5} />
        </button>
      </div>
    </div>
  );
}