import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { isPastDue, iso } from '@/lib/medSchedule';
import { Check, SkipForward, Activity, Info } from 'lucide-react';

const RATING_KEYS = { good: 'feelGood', okay: 'feltOkay', not_great: 'feelNotGreat', bad: 'feelPoor' };

export default function MedicationAdherence({ meds, doseLogs }) {
  const { t } = useAppSettings();
  const now = new Date();
  const today = iso(now);

  const logsToday = (doseLogs || []).filter((l) => l.date === today);
  const taken = logsToday.filter((l) => l.status === 'taken').length;
  const skipped = logsToday.filter((l) => l.status === 'skipped');
  const expected = (meds || []).filter((m) => isPastDue(today, m.time, now)).length;
  const pct = expected > 0 ? Math.min(1, taken / expected) : 0;

  const weekAgo = new Date(now);
  weekAgo.setDate(weekAgo.getDate() - 7);
  const recentFeel = (doseLogs || [])
    .filter((l) => l.date >= iso(weekAgo) && (l.rating === 'not_great' || l.rating === 'bad' || (l.symptoms || []).length > 0 || l.note))
    .sort((a, b) => (a.date < b.date ? 1 : -1))
    .slice(0, 6);

  return (
    <div className="rounded-3xl bg-card border border-border overflow-hidden mb-6">
      <div className="bg-earth-lagoon px-5 py-2.5">
        <h2 className="font-heading text-xl text-white">{t('medAdherence')}</h2>
      </div>
      <div className="p-5 space-y-5">
        <div>
          {expected === 0 ? (
            <p className="text-muted-foreground">{t('medAdherenceNone')}</p>
          ) : (
            <>
              <p className="text-2xl font-bold text-foreground">
                {taken} <span className="text-lg text-muted-foreground">/ {expected} {t('taken')}</span>
              </p>
              <div className="mt-3 h-3 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-earth-sage rounded-full transition-all" style={{ width: `${pct * 100}%` }} />
              </div>
            </>
          )}
        </div>

        <div>
          <p className="font-bold text-foreground mb-2 flex items-center gap-2">
            <SkipForward className="w-5 h-5 text-earth-plum" strokeWidth={2.25} />
            {t('skippedToday')}
          </p>
          {skipped.length === 0 ? (
            <p className="text-muted-foreground">{t('noSkippedDoses')}</p>
          ) : (
            <ul className="space-y-2">
              {skipped.map((log) => (
                <li key={log.id} className="flex items-start gap-2 rounded-xl bg-earth-plum/10 px-4 py-3">
                  <Check className="w-5 h-5 text-earth-plum shrink-0 mt-0.5" strokeWidth={2.5} />
                  <span className="flex-1 text-foreground">
                    <strong>{log.medication_name}</strong>
                    {log.skip_reason ? ` — ${t(log.skip_reason)}` : ''}
                    {log.note ? ` (${log.note})` : ''}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div>
          <p className="font-bold text-foreground mb-2 flex items-center gap-2">
            <Activity className="w-5 h-5 text-earth-terracotta" strokeWidth={2.25} />
            {t('newSymptoms')}
          </p>
          {recentFeel.length === 0 ? (
            <p className="text-muted-foreground">{t('noSymptomsLogged')}</p>
          ) : (
            <ul className="space-y-2">
              {recentFeel.map((log) => (
                <li key={log.id} className="rounded-xl bg-secondary/50 px-4 py-3">
                  <p className="font-semibold text-foreground">
                    {log.medication_name}
                    {log.rating ? ` · ${t(RATING_KEYS[log.rating])}` : ''}
                  </p>
                  {(log.symptoms || []).length > 0 && (
                    <p className="text-muted-foreground">{(log.symptoms || []).map((s) => t(s)).join(', ')}</p>
                  )}
                  {log.note && <p className="text-foreground">{log.note}</p>}
                </li>
              ))}
            </ul>
          )}
        </div>

        <p className="flex items-start gap-2 text-sm text-muted-foreground">
          <Info className="w-4 h-4 shrink-0 mt-0.5" />
          {t('checkWithPharmacist')}
        </p>
      </div>
    </div>
  );
}