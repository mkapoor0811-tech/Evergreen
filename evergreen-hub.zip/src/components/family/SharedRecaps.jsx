import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { LOCALES, formatShortDay } from '@/lib/timeFormat';
import { sharedNotes } from '@/lib/visitNotes';

/** The recaps the person chose to share. Only family and caregivers can read these. */
export default function SharedRecaps() {
  const { t, language } = useAppSettings();
  const [shared, setShared] = useState(null);
  const [people, setPeople] = useState([]);

  useEffect(() => {
    base44.entities.Appointment.list('-date', 100).then((appts) => {
      setShared(appts.filter((a) => a.recap?.share_with_family || sharedNotes(a).length > 0));
    });
    base44.entities.CaregiverSetting.list().then((rows) => {
      setPeople((rows[0]?.secondary_contacts || []).filter((p) => p.name));
    });
  }, []);

  if (shared === null) return null;

  return (
    <div className="rounded-3xl bg-card border border-border overflow-hidden mb-6">
      <div className="bg-earth-lagoon px-5 py-2.5">
        <h2 className="font-heading text-xl text-white">{t('sharedRecaps')}</h2>
      </div>
      <div className="p-5">
        {people.length > 0 && (
          <p className="text-muted-foreground mb-4">
            {t('sharedRecapsWho')}: {people.map((p) => p.name).join(', ')}
          </p>
        )}

        {shared.length === 0 ? (
          <p className="text-muted-foreground">{t('noSharedRecaps')}</p>
        ) : (
          <div className="space-y-4">
            {shared.map((a) => (
              <div key={a.id} className="border-b border-border last:border-0 pb-4 last:pb-0">
                <p className="font-bold text-foreground">
                  {a.doctor_name} — {formatShortDay(a.date, LOCALES[language] || 'en-US')}
                </p>
                {a.recap?.doctor_said && <p className="text-foreground">{a.recap.doctor_said}</p>}
                {a.recap?.next_steps && (
                  <p className="text-muted-foreground">{t('whatToDoNext')} {a.recap.next_steps}</p>
                )}
                {sharedNotes(a).map((n, i) => (
                  <p key={i} className="text-foreground">
                    <span className="font-bold">{t('notes')}:</span> {n.text}
                  </p>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}