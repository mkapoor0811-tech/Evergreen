import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Heart } from 'lucide-react';

export default function AppetiteAlert({ logs }) {
  const { t } = useAppSettings();
  const list = logs || [];
  const low = list.filter((l) => l.level !== 'good');

  if (low.length < 3) return null;

  return (
    <div className="rounded-3xl bg-card border-2 border-earth-terracotta overflow-hidden mb-6">
      <div className="bg-earth-lagoon px-5 py-2.5 flex items-center gap-3">
        <Heart className="w-6 h-6 text-white" strokeWidth={2.5} />
        <h2 className="font-heading text-xl text-white">{t('appetiteAlertTitle')}</h2>
      </div>
      <div className="p-5">
        <p className="text-foreground mb-2">
          {t('appetiteAlertNote').replace('{days}', String(low.length))}
        </p>
        <p className="text-muted-foreground">{t('appetiteCareTip')}</p>
      </div>
    </div>
  );
}