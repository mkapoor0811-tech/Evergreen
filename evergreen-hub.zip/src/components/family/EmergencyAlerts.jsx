import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { AlertTriangle, Check, MapPin, Loader2 } from 'lucide-react';

/** Emergency alerts raised from the Emergency page, with a "Mark as handled" action. */
export default function EmergencyAlerts() {
  const { t } = useAppSettings();
  const [alerts, setAlerts] = useState(null);
  const [busyId, setBusyId] = useState(null);

  const load = useCallback(async () => {
    const list = await base44.entities.EmergencyAlert.list('-created_date', 20).catch(() => []);
    setAlerts(list);
  }, []);

  useEffect(() => { load(); }, [load]);

  const markHandled = async (alert) => {
    setBusyId(alert.id);
    await base44.entities.EmergencyAlert.update(alert.id, {
      handled: true,
      handled_at: new Date().toISOString(),
    });
    await load();
    setBusyId(null);
  };

  const fmtTime = (iso) =>
    new Date(iso).toLocaleString(undefined, {
      weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
    });

  const open = (alerts || []).filter((a) => !a.handled);
  const handled = (alerts || []).filter((a) => a.handled);

  return (
    <div className="rounded-3xl bg-card border-2 border-border overflow-hidden mb-6">
      <div className="bg-destructive px-5 py-2.5">
        <h2 className="font-heading text-xl text-white">{t('emergencyAlerts')}</h2>
      </div>
      <div className="p-5">
        {alerts === null ? (
          <p className="text-muted-foreground">{t('loading')}</p>
        ) : alerts.length === 0 ? (
          <p className="text-muted-foreground">{t('emergencyNoAlerts')}</p>
        ) : (
          <div className="space-y-4">
            {[...open, ...handled].map((a) => (
              <div
                key={a.id}
                className={`rounded-2xl border-2 p-4 ${a.handled ? 'border-border bg-secondary/40' : 'border-destructive/50 bg-destructive/5'}`}
              >
                <div className="flex items-start gap-3">
                  <span className={`w-11 h-11 blob flex items-center justify-center shrink-0 ${a.handled ? 'bg-earth-sage/20 text-earth-sageDark' : 'bg-destructive/15 text-destructive'}`}>
                    {a.handled
                      ? <Check className="w-6 h-6" strokeWidth={3} />
                      : <AlertTriangle className="w-6 h-6" strokeWidth={2.5} />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-heading text-lg text-foreground leading-tight">
                      {a.alert_time ? fmtTime(a.alert_time) : fmtTime(a.created_date)}
                    </p>
                    <p className="text-muted-foreground">{a.message}</p>
                    {a.location_link ? (
                      <a
                        href={a.location_link}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-2 inline-flex items-center gap-2 font-bold text-earth-navy underline"
                      >
                        <MapPin className="w-5 h-5" />
                        {t('emergencyLocationShared')}
                      </a>
                    ) : null}
                    {a.handled && (
                      <p className="mt-2 text-sm font-bold text-earth-sageDark">
                        {t('emergencyHandled')}{a.handled_at ? ` · ${fmtTime(a.handled_at)}` : ''}
                      </p>
                    )}
                  </div>
                </div>

                {!a.handled && (
                  <button
                    onClick={() => markHandled(a)}
                    disabled={busyId === a.id}
                    className="mt-3 w-full flex items-center justify-center gap-2 bg-earth-sage hover:bg-earth-sageDark text-white font-bold py-3.5 rounded-xl transition min-h-[56px] disabled:opacity-50"
                  >
                    {busyId === a.id ? <Loader2 className="w-5 h-5 animate-spin" /> : <Check className="w-5 h-5" strokeWidth={3} />}
                    {t('emergencyMarkHandled')}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}