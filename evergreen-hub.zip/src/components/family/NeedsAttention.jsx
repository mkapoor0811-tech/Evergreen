import React from 'react';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { daysUntil } from '@/lib/appointmentUtils';
import { AlertTriangle, Pill, Calendar, HandHeart, Check, ArrowRight } from 'lucide-react';
import { todayLocal } from '@/lib/localDate';

export default function NeedsAttention({ isMissed, meds, appts, helpRequested }) {
  const { t } = useAppSettings();
  const today = todayLocal();

  const medsLeft = (meds || []).filter((m) => !(m.taken_today && m.last_taken_date === today)).length;
  const soonAppt = (appts || []).find((a) => {
    const d = daysUntil(a.date);
    return d >= 0 && d <= 3;
  });

  const items = [];
  if (helpRequested) {
    items.push({ key: 'help', icon: HandHeart, tone: 'bg-earth-terracotta', text: t('attnHelp'), to: '/check-in' });
  }
  if (isMissed) {
    items.push({ key: 'checkin', icon: AlertTriangle, tone: 'bg-earth-terracotta', text: t('attnCheckIn'), to: '/check-in' });
  }
  if (medsLeft > 0) {
    items.push({ key: 'meds', icon: Pill, tone: 'bg-earth-marigold', text: t('attnMeds').replace('{count}', medsLeft), to: '/medications' });
  }
  if (soonAppt) {
    items.push({ key: 'appt', icon: Calendar, tone: 'bg-earth-lagoon', text: t('attnApptRide').replace('{name}', soonAppt.doctor_name), to: '/appointments' });
  }

  return (
    <section className="mb-6 rounded-3xl bg-card border-2 border-earth-terracotta/40 overflow-hidden">
      <div className="bg-earth-lagoon px-5 py-2.5">
        <h2 className="font-heading text-xl text-white">{t('needsAttention')}</h2>
      </div>
      <div className="p-5">
        {items.length === 0 ? (
          <p className="flex items-center gap-2 text-earth-sageDark font-semibold">
            <Check className="w-5 h-5" strokeWidth={3} />
            {t('attentionClear')}
          </p>
        ) : (
          <ul className="space-y-3">
            {items.map(({ key, icon: Icon, tone, text, to }) => (
              <li key={key}>
                <Link to={to} className="flex items-center gap-4 rounded-2xl bg-secondary/60 hover:bg-secondary p-3 transition">
                  <span className={`w-11 h-11 blob flex items-center justify-center shrink-0 text-white ${tone}`}>
                    <Icon className="w-6 h-6" strokeWidth={2.25} />
                  </span>
                  <span className="flex-1 font-semibold text-foreground">{text}</span>
                  <ArrowRight className="w-5 h-5 text-muted-foreground shrink-0" />
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}