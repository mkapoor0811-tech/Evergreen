import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { getHelpForRoute } from '@/lib/helpContent';
import { HelpCircle, X, PhoneCall, Phone, ShieldCheck } from 'lucide-react';

export default function HelpButton() {
  const { t, language } = useAppSettings();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [phone, setPhone] = useState(() => localStorage.getItem('mahika_caregiver_phone') || '');
  const helpText = getHelpForRoute(location.pathname, language) || t('helpGeneric');

  useEffect(() => {
    base44.entities.CaregiverSetting.list()
      .then((settings) => {
        const saved = settings[0]?.caregiver_phone;
        if (saved) setPhone(saved);
      })
      .catch(() => {});
  }, []);

  const digits = phone.replace(/[^\d+]/g, '');

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label={t('help')}
        className="shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
      >
        <HelpCircle className="w-6 h-6" strokeWidth={2.5} />
        <span className="hidden sm:inline">{t('help')}</span>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[100] bg-black/50 flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => setOpen(false)}
        >
          <div
            className="bg-card rounded-3xl border-2 border-border max-w-lg w-full p-6 shadow-2xl my-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-3">
                <span className="w-12 h-12 blob bg-earth-lagoon/15 text-earth-lagoon flex items-center justify-center shrink-0">
                  <HelpCircle className="w-7 h-7" strokeWidth={2.5} />
                </span>
                <h2 className="font-heading text-2xl text-foreground">{t('help')}</h2>
              </div>
              <button
                onClick={() => setOpen(false)}
                aria-label={t('cancel')}
                className="shrink-0 flex items-center justify-center w-[56px] h-[56px] rounded-xl hover:bg-muted transition"
              >
                <X className="w-7 h-7 text-muted-foreground" />
              </button>
            </div>

            <p className="text-xl text-foreground leading-relaxed">{helpText}</p>

            <div className="mt-6 pt-5 border-t-2 border-border space-y-3">
              <a
                href="tel:911"
                className="w-full flex items-center justify-center gap-3 bg-destructive hover:bg-destructive/90 text-white font-bold py-5 rounded-2xl text-xl transition min-h-[68px]"
              >
                <PhoneCall className="w-7 h-7" strokeWidth={2.5} />
                {t('callEmergency')}
              </a>

              {digits ? (
                <a
                  href={`tel:${digits}`}
                  className="w-full flex items-center justify-center gap-3 border-2 border-earth-sage text-earth-sageDark bg-card hover:bg-earth-sage/10 font-bold py-5 rounded-2xl text-xl transition min-h-[68px]"
                >
                  <Phone className="w-7 h-7" strokeWidth={2.5} />
                  {t('callMyFamily')}
                </a>
              ) : (
                <Link
                  to="/settings"
                  onClick={() => setOpen(false)}
                  className="block w-full text-center border-2 border-dashed border-earth-sage text-earth-sageDark font-bold py-5 rounded-2xl text-lg min-h-[68px]"
                >
                  {t('noFamilyPhone')}
                </Link>
              )}

              <Link
                to="/emergency-profile"
                onClick={() => setOpen(false)}
                className="w-full flex items-center justify-center gap-3 border-2 border-earth-terracotta text-earth-terracottaDark bg-card hover:bg-earth-terracotta/10 font-bold py-5 rounded-2xl text-xl transition min-h-[68px]"
              >
                <ShieldCheck className="w-7 h-7" strokeWidth={2.5} />
                {t('emergencyProfile')}
              </Link>
            </div>

            <button
              onClick={() => setOpen(false)}
              className="w-full mt-4 py-4 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px] text-lg"
            >
              {t('helpGotIt')}
            </button>
          </div>
        </div>
      )}
    </>
  );
}