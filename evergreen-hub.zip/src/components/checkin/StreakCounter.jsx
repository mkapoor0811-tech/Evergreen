import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Flame } from 'lucide-react';
import { localDate } from '@/lib/localDate';

const iso = (d) => localDate(d);

/** Consecutive days checked in, counting back from today (or yesterday if today is not done yet). */
export function computeStreak(checkIns) {
  const done = new Set((checkIns || []).filter((c) => c.checked_in).map((c) => c.date));
  const cursor = new Date();
  if (!done.has(iso(cursor))) cursor.setDate(cursor.getDate() - 1);
  let streak = 0;
  while (done.has(iso(cursor))) {
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

export default function StreakCounter({ checkIns }) {
  const { t } = useAppSettings();
  const streak = computeStreak(checkIns);

  return (
    <div className="mb-6 flex items-center gap-4 rounded-3xl bg-earth-marigold/15 border-2 border-earth-marigold/40 p-5">
      <span className="w-14 h-14 blob bg-earth-marigold text-white flex items-center justify-center shrink-0">
        <Flame className="w-7 h-7" strokeWidth={2.25} />
      </span>
      <div>
        <p className="text-sm text-muted-foreground font-semibold">{t('streak')}</p>
        <p className="font-body font-bold text-2xl text-foreground leading-tight tabular-nums">
          {streak > 0
            ? (streak === 1 ? t('streakDaysOne') : t('streakDays').replace('{count}', streak))
            : t('streakNone')}
        </p>
      </div>
    </div>
  );
}