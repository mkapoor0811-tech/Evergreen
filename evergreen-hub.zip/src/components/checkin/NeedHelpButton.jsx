import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { sendToCaregivers } from '@/lib/caregiverAlerts';
import { HandHeart, Check, Loader2, AlertTriangle, X } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';
import { todayLocal } from '@/lib/localDate';

export default function NeedHelpButton({ checkIn, onSaved }) {
  const { t } = useAppSettings();
  const look = useSectionLook();
  const [open, setOpen] = useState(false);
  const [note, setNote] = useState(checkIn?.help_note || '');
  const [state, setState] = useState(checkIn?.help_requested ? 'sent' : 'idle');
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (checkIn?.help_requested) setState('sent');
  }, [checkIn]);

  const ask = async () => {
    setState('sending');
    const today = todayLocal();
    const payload = {
      help_requested: true,
      help_note: note.trim(),
      help_requested_at: new Date().toISOString(),
    };
    const saved = checkIn
      ? await base44.entities.CheckIn.update(checkIn.id, payload)
      : await base44.entities.CheckIn.create({ date: today, ...payload });

    const res = await sendToCaregivers({
      subject: t('needHelpSubject'),
      heading: t('needHelpEmailHeading'),
      intro: t('needHelpEmailIntro'),
      lines: note.trim() ? [note.trim()] : [],
      footer: t('needHelpEmailFooter'),
    });

    setState('sent');
    setFailed(res.sent === 0);
    setOpen(false);
    if (onSaved) onSaved(saved);
  };

  return (
    <section className="mt-6 rounded-3xl bg-earth-lagoon/10 border-2 border-earth-lagoon/35 overflow-hidden">
      <div className={`${look.bar} px-5 py-2.5`}>
        <h2 className="font-heading text-xl text-white">{t('needHelp')}</h2>
      </div>
      <div className="p-5">
        {state === 'sent' ? (
          <p className={`flex items-start gap-2 font-semibold ${failed ? 'text-destructive' : 'text-earth-lagoonDark'}`}>
            {failed ? <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" /> : <Check className="w-5 h-5 shrink-0 mt-0.5" strokeWidth={3} />}
            {failed ? t('needHelpFailed') : t('needHelpSent')}
          </p>
        ) : (
          <>
            <p className="text-foreground mb-4">{t('needHelpHelp')}</p>
            <button
              onClick={() => setOpen(true)}
              className="w-full flex items-center justify-center gap-3 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-5 rounded-2xl text-lg transition min-h-[64px]"
            >
              <HandHeart className="w-7 h-7" strokeWidth={2.25} />
              {t('needHelp')}
            </button>
          </>
        )}
      </div>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setOpen(false)}>
          <div className="bg-card rounded-3xl p-6 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-heading text-xl text-foreground">{t('needHelp')}</h3>
              <button onClick={() => setOpen(false)} className="p-2 rounded-lg hover:bg-secondary">
                <X className="w-6 h-6 text-muted-foreground" />
              </button>
            </div>
            <p className="text-foreground mb-4">{t('needHelpHelp')}</p>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
              placeholder={t('needHelpPlaceholder')}
              className="w-full px-4 py-3 rounded-xl border-2 border-border bg-card outline-none focus:border-earth-lagoon resize-none"
            />
            <div className="flex gap-3 mt-4">
              <button
                onClick={() => setOpen(false)}
                className="flex-1 py-4 rounded-xl border-2 border-border font-bold text-foreground min-h-[56px]"
              >
                {t('cancel')}
              </button>
              <button
                onClick={ask}
                disabled={state === 'sending'}
                className="flex-1 flex items-center justify-center gap-2 py-4 rounded-xl bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold disabled:opacity-50 min-h-[56px]"
              >
                {state === 'sending' ? <Loader2 className="w-6 h-6 animate-spin" /> : <HandHeart className="w-6 h-6" strokeWidth={2.25} />}
                {t('needHelpSend')}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}