import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { localDate } from '@/lib/localDate';
import { useSectionLook } from '@/lib/sectionColors';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };
const iso = (d) => localDate(d);

export default function CheckInCalendar({ checkIns, weeks = 4 }) {
  const { t, language } = useAppSettings();
  const look = useSectionLook();
  const locale = LOCALES[language] || 'en-US';
  const checked = new Set((checkIns || []).filter((c) => c.checked_in).map((c) => c.date));

  const total = weeks * 7;
  const start = new Date();
  start.setDate(start.getDate() - (total - 1));

  const lead = start.getDay();
  const days = [];
  for (let i = 0; i < total; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    days.push({ key: iso(d), label: d.toLocaleDateString(locale, { month: 'short', day: 'numeric' }) });
  }

  const sunday = new Date(start);
  sunday.setDate(sunday.getDate() - lead);
  const weekdays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(sunday);
    d.setDate(sunday.getDate() + i);
    return d.toLocaleDateString(locale, { weekday: 'narrow' });
  });

  return (
    <section className="mb-6 rounded-3xl bg-card border border-border overflow-hidden">
      <div className={`${look.bar} px-5 py-2.5`}>
        <h2 className="font-heading text-xl text-white">{t('history')}</h2>
      </div>
      <div className="p-5">
        <p className="text-muted-foreground mb-4">{t('historyHelp')}</p>
        <div className="grid grid-cols-7 gap-1.5 mb-1.5">
          {weekdays.map((w, i) => (
            <span key={i} className="text-center text-xs font-bold text-muted-foreground">{w}</span>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1.5">
          {Array.from({ length: lead }, (_, i) => <span key={`lead-${i}`} />)}
          {days.map((day) => (
            <span
              key={day.key}
              title={day.label}
              className={`aspect-square rounded-lg border ${
                checked.has(day.key) ? 'bg-earth-sage border-earth-sageDark' : 'bg-secondary border-border'
              }`}
            />
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-4 mt-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-2">
            <span className="w-4 h-4 rounded bg-earth-sage border border-earth-sageDark" />
            {t('checkedInLegend')}
          </span>
          <span className="flex items-center gap-2">
            <span className="w-4 h-4 rounded bg-secondary border border-border" />
            {t('notCheckedInLegend')}
          </span>
        </div>
      </div>
    </section>
  );
}