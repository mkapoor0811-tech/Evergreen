import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { getDailyHabits } from '@/lib/dailyContent';
import { Sparkles, Check } from 'lucide-react';
import { todayLocal } from '@/lib/localDate';

const todayStr = todayLocal;
const STORAGE_KEY = `mahika_habits_${todayStr()}`;

export default function DailyHabit() {
  const { t, language } = useAppSettings();
  const habits = getDailyHabits(language);
  const [doneSet, setDoneSet] = useState({});

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      setDoneSet(stored ? JSON.parse(stored) : {});
    } catch { setDoneSet({}); }
  }, []);

  const toggleDone = (index) => {
    setDoneSet((prev) => {
      const next = { ...prev, [index]: !prev[index] };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  };

  const allDone = habits.every((_, i) => doneSet[i]);

  return (
    <div className={`rounded-2xl border-2 p-6 transition ${allDone ? 'bg-green-50 border-green-300' : 'bg-white border-slate-200'}`}>
      <div className="flex items-center gap-3 mb-5">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${allDone ? 'bg-green-100' : 'bg-pink-100'}`}>
          <Sparkles className={`w-7 h-7 ${allDone ? 'text-green-600' : 'text-pink-600'}`} strokeWidth={2.5} />
        </div>
        <h2 className="text-xl font-bold text-slate-900">{t('dailyHabit')}</h2>
      </div>
      <div className="space-y-3">
        {habits.map((habit, i) => {
          const done = !!doneSet[i];
          return (
            <button
              key={i}
              onClick={() => toggleDone(i)}
              className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition text-left min-h-[64px] ${
                done ? 'bg-green-50 border-green-300' : 'bg-slate-50 border-slate-200 hover:border-slate-400'
              }`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border-2 ${done ? 'bg-green-600 border-green-600' : 'border-slate-300'}`}>
                {done && <Check className="w-5 h-5 text-white" strokeWidth={3} />}
              </div>
              <p className={`text-lg leading-relaxed ${done ? 'text-green-700 line-through' : 'text-slate-800'}`}>{habit}</p>
            </button>
          );
        })}
      </div>
      {allDone && (
        <p className="text-center text-green-700 font-semibold mt-4">{t('habitEncouragement')}</p>
      )}
    </div>
  );
}