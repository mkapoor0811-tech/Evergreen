import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { base44 } from '@/api/base44Client';
import { getQuoteOfTheDay, getQuoteReflection } from '@/lib/dailyContent';
import { Quote, Sparkles } from 'lucide-react';

export default function QuoteOfTheDay() {
  const { t, language } = useAppSettings();
  const [profile, setProfile] = useState(null);
  const q = getQuoteOfTheDay(language);

  useEffect(() => {
    base44.auth.me().then((u) => setProfile(u)).catch(() => setProfile({}));
  }, []);

  const reflection = profile ? getQuoteReflection(language, profile) : null;

  return (
    <div className="bg-white rounded-2xl border-2 border-slate-200 p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
          <Quote className="w-7 h-7 text-amber-600" strokeWidth={2.5} />
        </div>
        <h2 className="text-xl font-bold text-slate-900">{t('quoteOfTheDay')}</h2>
      </div>
      <p className="text-xl text-slate-800 leading-relaxed">&ldquo;{q.text}&rdquo;</p>
      {q.author && <p className="text-lg text-slate-500 font-semibold mt-3">&mdash; {q.author}</p>}
      {reflection && (
        <div className="mt-4 p-4 bg-amber-50 rounded-xl border border-amber-200">
          <div className="flex items-start gap-2">
            <Sparkles className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <p className="text-lg text-slate-700 leading-relaxed">{reflection}</p>
          </div>
        </div>
      )}
    </div>
  );
}