import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { base44 } from '@/api/base44Client';
import { getWordsOfTheDay, getWordReflection } from '@/lib/dailyContent';
import { BookOpen, Sparkles } from 'lucide-react';

export default function WordOfTheDay() {
  const { t, language } = useAppSettings();
  const [profile, setProfile] = useState(null);
  const words = getWordsOfTheDay(language);

  useEffect(() => {
    base44.auth.me().then((u) => setProfile(u)).catch(() => setProfile({}));
  }, []);

  const reflection = profile ? getWordReflection(language, words[0].word, profile) : null;

  return (
    <div className="bg-white rounded-2xl border-2 border-slate-200 p-6">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center">
          <BookOpen className="w-7 h-7 text-indigo-600" strokeWidth={2.5} />
        </div>
        <h2 className="text-xl font-bold text-slate-900">{t('wordsOfTheDay')}</h2>
      </div>
      <div className="space-y-5">
        {words.map((w, i) => (
          <div key={i} className={i < words.length - 1 ? 'pb-5 border-b border-slate-100' : ''}>
            <p className="text-2xl font-bold text-indigo-700 mb-2">{w.word}</p>
            <div className="mb-2">
              <p className="text-sm font-bold text-slate-500 uppercase tracking-wide mb-1">{t('definition')}</p>
              <p className="text-lg text-slate-800 leading-relaxed">{w.definition}</p>
            </div>
            <div>
              <p className="text-sm font-bold text-slate-500 uppercase tracking-wide mb-1">{t('exampleSentence')}</p>
              <p className="text-lg text-slate-700 italic leading-relaxed">&ldquo;{w.example}&rdquo;</p>
            </div>
            {i === 0 && reflection && (
              <div className="mt-3 p-4 bg-indigo-50 rounded-xl border border-indigo-200">
                <div className="flex items-start gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                  <p className="text-lg text-slate-700 leading-relaxed">{reflection}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}