import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { base44 } from '@/api/base44Client';
import { getDailyReflection } from '@/lib/dailyContent';
import { Feather } from 'lucide-react';

export default function DailyReflection() {
  const { t, language } = useAppSettings();
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    base44.auth.me().then((u) => setProfile(u)).catch(() => setProfile({}));
  }, []);

  const reflection = profile ? getDailyReflection(language, profile) : null;

  return (
    <div className="bg-white rounded-2xl border-2 border-slate-200 p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
          <Feather className="w-7 h-7 text-emerald-600" strokeWidth={2.5} />
        </div>
        <h2 className="text-xl font-bold text-slate-900">{t('dailyReflection')}</h2>
      </div>
      {reflection ? (
        <p className="text-xl text-slate-800 leading-relaxed">{reflection}</p>
      ) : (
        <p className="text-lg text-slate-500">{t('dailyReflectionEmpty')}</p>
      )}
    </div>
  );
}