import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { readCustomTips, addCustomTip, removeCustomTip, todayTip } from '@/lib/gardenTips';
import ReadAloudButton from '@/components/ReadAloudButton';
import { Sprout, Plus, Trash2 } from 'lucide-react';

/** Today's garden tip, plus any the person has written themselves. */
export default function GardenTip() {
  const { t, language } = useAppSettings();
  const [custom, setCustom] = useState(() => readCustomTips());
  const [draft, setDraft] = useState('');

  const tip = todayTip(language, custom);

  const add = () => {
    setCustom(addCustomTip(draft));
    setDraft('');
  };

  return (
    <div>
      <div className="rounded-2xl border-2 border-earth-sage/50 bg-card p-6 mb-5">
        <div className="flex items-center gap-3 mb-4">
          <span className="w-12 h-12 blob bg-earth-sage/20 text-earth-sageDark flex items-center justify-center shrink-0">
            <Sprout className="w-6 h-6" strokeWidth={2.5} />
          </span>
          <div>
            <p className="text-sm text-muted-foreground">{t('gardenTip')}</p>
            <h2 className="font-heading text-xl text-foreground">{t('todayTip')}</h2>
          </div>
        </div>
        <p className="text-xl text-foreground leading-snug mb-4">{tip}</p>
        <ReadAloudButton text={`${t('gardenTip')}. ${tip}`} />
      </div>

      <div className="rounded-2xl border-2 border-border bg-card p-6">
        <h2 className="font-heading text-xl text-foreground mb-4">{t('addGardenTip')}</h2>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={t('gardenTipPlaceholder')}
          rows={2}
          className="w-full px-4 py-3 rounded-xl border-2 border-input bg-card text-foreground focus:border-earth-sage outline-none text-lg resize-none mb-3"
        />
        <button
          onClick={add}
          disabled={!draft.trim()}
          className="w-full flex items-center justify-center gap-2 bg-earth-sage hover:bg-earth-sageDark text-white font-bold py-4 rounded-xl transition min-h-[56px] disabled:opacity-50"
        >
          <Plus className="w-6 h-6" strokeWidth={2.5} />
          {t('addTip')}
        </button>

        {custom.length > 0 && (
          <div className="mt-5">
            <h3 className="font-heading text-lg text-foreground mb-3">{t('myGardenTips')}</h3>
            <ul className="space-y-3">
              {custom.map((item) => (
                <li key={item} className="flex items-start gap-3 p-4 rounded-xl bg-secondary/60">
                  <p className="flex-1 text-lg text-foreground leading-snug">{item}</p>
                  <button
                    onClick={() => setCustom(removeCustomTip(item))}
                    aria-label={t('delete')}
                    className="shrink-0 p-2 rounded-lg hover:bg-muted"
                  >
                    <Trash2 className="w-5 h-5 text-muted-foreground" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}