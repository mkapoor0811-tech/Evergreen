import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Sun, HeartPulse, ShieldCheck, BookOpen, Users } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';
import SimpleNav from '@/components/SimpleNav';
import { sectionLook } from '@/lib/sectionColors';

/**
 * The five places you can always get to. Each tab wears its own colour, and the
 * tab you are on is filled with that colour, so the bar says where you are.
 */
export const NAV_TABS = [
  { to: '/', icon: Sun, key: 'navToday', section: 'today', match: ['/'] },
  {
    to: '/health', icon: HeartPulse, key: 'navHealth', section: 'medications',
    match: ['/health', '/medications', '/appointments', '/diet', '/exercise', '/groceries'],
  },
  {
    to: '/safety', icon: ShieldCheck, key: 'navSafety', section: 'safety',
    match: ['/safety', '/check-in', '/scam-checker', '/health-summary', '/emergency-profile', '/emergency-readiness'],
  },
  {
    to: '/learn', icon: BookOpen, key: 'navLearn', section: 'learn',
    match: ['/learn', '/daily-boost', '/breathe', '/garden', '/tech-help', '/term-explainer'],
  },
  {
    to: '/family', icon: Users, key: 'navFamily', section: 'family',
    match: ['/family', '/family-dashboard', '/settings'],
  },
];

export function isTabActive(tab, pathname) {
  if (tab.to === '/') return pathname === '/';
  return tab.match.some((m) => pathname === m || pathname.startsWith(`${m}/`));
}

export default function BottomNav() {
  const { t, simpleMode } = useAppSettings();
  const location = useLocation();

  if (simpleMode) return <SimpleNav />;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t-2 border-border shadow-[0_-4px_16px_rgba(0,0,0,0.06)]">
      <div className="max-w-3xl mx-auto grid grid-cols-5">
        {NAV_TABS.map((tab) => {
          const active = isTabActive(tab, location.pathname);
          const look = sectionLook(tab.section);
          const Icon = tab.icon;
          return (
            <Link
              key={tab.to}
              to={tab.to}
              aria-current={active ? 'page' : undefined}
              className={`flex flex-col items-center justify-center gap-1 py-3 min-h-[76px] transition ${
                active ? `text-white ${look.bar}` : 'text-muted-foreground'
              }`}
            >
              <span className={`w-11 h-11 blob flex items-center justify-center shrink-0 ${active ? 'bg-white/25 text-white' : 'bg-muted'}`}>
                <Icon className="w-6 h-6" strokeWidth={2.25} />
              </span>
              <span className="font-bold text-base leading-none">{t(tab.key)}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}