import React from 'react';

/** A coloured band + heading, used to break the About page into clear sections. */
export default function AboutSection({ tone = 'bg-earth-lagoon', title, children }) {
  return (
    <section className="mb-8">
      <div className={`${tone} inline-block rounded-xl px-5 py-2 mb-4 shadow-sm`}>
        <h2 className="font-heading text-2xl text-white">{title}</h2>
      </div>
      <div className="space-y-4">{children}</div>
    </section>
  );
}