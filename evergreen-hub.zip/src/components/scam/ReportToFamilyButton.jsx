import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { sendToCaregivers } from '@/lib/caregiverAlerts';
import { Users, Check, Loader2, AlertTriangle } from 'lucide-react';

const LEVEL_KEYS = { high: 'riskHigh', medium: 'riskMedium', low: 'riskLow' };

export default function ReportToFamilyButton({ message, level, reasons }) {
  const { t } = useAppSettings();
  const [state, setState] = useState('idle');
  const [failed, setFailed] = useState(false);

  const report = async () => {
    setState('sending');
    const lines = [
      `<strong>${t('riskLevel')}: ${t(LEVEL_KEYS[level] || 'riskLow')}</strong>`,
      ...(reasons || []).map((reason) => `${reason}`),
      `<em>“${(message || '').slice(0, 400)}”</em>`,
    ];

    const res = await sendToCaregivers({
      subject: t('reportEmailSubject'),
      heading: t('reportEmailHeading'),
      intro: t('reportEmailIntro'),
      lines,
      footer: t('reportEmailFooter'),
    });

    setState('sent');
    setFailed(res.sent === 0);
  };

  return (
    <button
      onClick={report}
      disabled={state === 'sending'}
      className={`mt-4 inline-flex items-center gap-2 px-5 py-3 rounded-xl font-bold transition disabled:opacity-60 ${
        state === 'sent'
          ? failed ? 'bg-destructive/10 text-destructive' : 'bg-earth-sage/20 text-earth-sageDark'
          : 'bg-earth-terracotta hover:bg-earth-terracottaDark text-white'
      }`}
    >
      {state === 'sending' ? <Loader2 className="w-5 h-5 animate-spin" />
        : state === 'sent' ? (failed ? <AlertTriangle className="w-5 h-5" /> : <Check className="w-5 h-5" strokeWidth={3} />)
        : <Users className="w-5 h-5" strokeWidth={2.25} />}
      {state === 'sent' ? (failed ? t('reportFailed') : t('reported')) : t('reportToFamily')}
    </button>
  );
}