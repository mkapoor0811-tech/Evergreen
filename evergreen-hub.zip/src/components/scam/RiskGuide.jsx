import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { ListChecks } from 'lucide-react';

const STEPS = {
  high: ['guideHigh1', 'guideHigh2', 'guideHigh3'],
  medium: ['guideMedium1', 'guideMedium2', 'guideMedium3'],
  low: ['guideLow1', 'guideLow2'],
};

export default function RiskGuide({ level }) {
  const { t } = useAppSettings();
  const steps = STEPS[level] || STEPS.low;

  return (
    <div className="mt-4 p-4 rounded-xl border border-border bg-card/70">
      <p className="font-bold text-foreground mb-3 flex items-center gap-2">
        <ListChecks className="w-5 h-5" strokeWidth={2.25} />
        {t('whatToDoNext')}
      </p>
      <ol className="space-y-2">
        {steps.map((key, i) => (
          <li key={key} className="flex items-start gap-3">
            <span className="w-7 h-7 rounded-full bg-secondary text-foreground font-bold flex items-center justify-center shrink-0 text-sm">
              {i + 1}
            </span>
            <span className="text-foreground">{t(key)}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}