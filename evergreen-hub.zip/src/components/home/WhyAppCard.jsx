import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import ReadAloudButton from '@/components/ReadAloudButton';
import { Heart, ChevronDown, ChevronUp, ArrowRight } from 'lucide-react';

/** A compact card that says why the app exists. Starts closed so the day's pills and check-in stay at the top. */
export default function WhyAppCard() {
  const { t } = useAppSettings();
  const [open, setOpen] = useState(() => localStorage.getItem('mahika_whyOpen') === 'true');

  const toggle = () => {
    setOpen((v) => {
      localStorage.setItem('mahika_whyOpen', String(!v));
      return !v;
    });
  };

  const title = `${t('whyTitle')} ${t('appName')}`;
  const spoken = [
    title,
    t('whyTagline'),
    t('whyNeed'),
    t('whyDoes'),
    t('whyMatters'),
    t('whySmallPrint'),
    t('aboutWhySource'),
  ].join(' ');

  return (
    <section className="mb-5 rounded-2xl bg-card border-2 border-earth-lagoon/40 overflow-hidden">
      <button
        onClick={toggle}
        className="w-full flex items-center gap-3 px-4 py-3 text-left min-h-[64px]"
      >
        <span className="w-10 h-10 blob bg-earth-lagoon/15 text-earth-lagoon flex items-center justify-center shrink-0">
          <Heart className="w-5 h-5" strokeWidth={2.5} />
        </span>
        <span className="flex-1 font-heading text-lg text-foreground leading-tight">{title}</span>
        {open
          ? <ChevronUp className="w-6 h-6 text-muted-foreground shrink-0" strokeWidth={2.5} />
          : <ChevronDown className="w-6 h-6 text-muted-foreground shrink-0" strokeWidth={2.5} />}
      </button>

      {open && (
        <div className="px-4 pb-4">
          <ReadAloudButton text={spoken} />
          <p className="font-bold text-2xl text-foreground leading-snug mb-3">{t('whyTagline')}</p>
          <p className="text-xl text-foreground leading-snug mb-3">{t('whyNeed')}</p>
          <p className="text-xl text-foreground leading-snug mb-3">{t('whyDoes')}</p>
          <p className="text-xl text-foreground leading-snug mb-3">{t('whyMatters')}</p>
          <p className="text-lg text-foreground leading-snug mb-2">{t('whySmallPrint')}</p>
          <p className="text-lg text-muted-foreground mb-4">{t('aboutWhySource')}</p>
          <Link
            to="/about"
            className="flex items-center justify-center gap-2 py-3 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
          >
            {t('readMore')}
            <ArrowRight className="w-5 h-5" strokeWidth={2.5} />
          </Link>
          <button
            onClick={toggle}
            className="w-full mt-3 py-3 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
          >
            {t('close')}
          </button>
        </div>
      )}
    </section>
  );
}