import React from 'react';
import SectionCard from '@/components/SectionCard';

/** A titled group of cards. Every section uses the same card style and the same
 *  spacing, and wears the colour of the part of the app it belongs to. */
export default function HomeSection({ title, children, layout = 'stack', collapsible = false, defaultOpen = true, color }) {
  return (
    <SectionCard title={title} collapsible={collapsible} defaultOpen={defaultOpen} color={color}>
      <div className={layout === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 gap-3' : 'space-y-3'}>
        {children}
      </div>
    </SectionCard>
  );
}