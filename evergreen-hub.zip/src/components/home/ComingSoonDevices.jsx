import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Watch, HeartPulse, Activity, ShieldCheck, Users, BookOpen } from 'lucide-react';

/** A calm, information-only note at the bottom of Today about the devices
 *  Evergreen could work with later. Nothing on it is tappable. */
export default function ComingSoonDevices() {
  const { t } = useAppSettings();

  const items = [
    { icon: HeartPulse, text: t('comingSoonHealth') },
    { icon: Activity, text: t('comingSoonExercise') },
    { icon: ShieldCheck, text: t('comingSoonSafety') },
    { icon: Users, text: t('comingSoonFamily') },
    { icon: BookOpen, text: t('comingSoonLearn') },
  ];

  return (
    <section className="mb-5 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <div className="px-5 py-3 bg-secondary">
        <div className="flex items-center gap-3">
          <Watch className="w-6 h-6 text-secondary-foreground shrink-0" strokeWidth={2.5} />
          <h2 className="font-heading text-xl font-bold text-secondary-foreground leading-tight">
            {t('comingSoonDevicesTitle')}
          </h2>
        </div>
        <span className="inline-block mt-2 rounded-full border-2 border-border bg-card px-3 py-1 text-xs font-bold text-muted-foreground">
          {t('comingSoonPill')}
        </span>
      </div>

      <div className="p-5">
        <p className="text-sm text-foreground leading-relaxed">{t('comingSoonDevicesText')}</p>

        <ul className="mt-6 space-y-4">
          {items.map(({ icon: Icon, text }) => (
            <li key={text} className="flex items-start gap-3">
              <span className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center shrink-0">
                <Icon className="w-5 h-5 text-muted-foreground" strokeWidth={2.5} />
              </span>
              <span className="text-sm text-foreground leading-snug pt-1">{text}</span>
            </li>
          ))}
        </ul>

        <p className="mt-6 pt-4 border-t-2 border-border text-sm text-muted-foreground leading-snug">
          {t('comingSoonFooter')}
        </p>
      </div>
    </section>
  );
}