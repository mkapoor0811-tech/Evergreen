import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { Pill, Calendar, Check, Heart } from 'lucide-react';
import { formatTime12 } from '@/lib/timeFormat';
import { countdownLabel } from '@/lib/appointmentUtils';
import { applyMedTaken, logDose, isMedTakenToday, todayStr } from '@/lib/medTaken';
import { effectiveMedTime } from '@/lib/daySchedule';
import { useUndo } from '@/lib/UndoContext';
import EmergencyButton from '@/components/emergency/EmergencyButton';
import ActionButton from '@/components/ActionButton';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

/** The one big card on the Today screen: next pill, next visit, and the daily check-in. */
export default function TodayView() {
  const { t, language, dayTimes } = useAppSettings();
  const { showUndo } = useUndo();
  const locale = LOCALES[language] || 'en-US';

  const [meds, setMeds] = useState(null);
  const [nextAppt, setNextAppt] = useState(null);
  const [checkIn, setCheckIn] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const today = todayStr();
    const [medList, apptPage, checkPage] = await Promise.all([
      base44.entities.Medication.list('-created_date', 100),
      base44.entities.Appointment.filter({ date: { $gte: today } }, { sort: 'date', limit: 1 }),
      base44.entities.CheckIn.filter({ date: today }, { limit: 1 }),
    ]);
    setMeds(medList.map((m) => ({ ...m, time: effectiveMedTime(m, dayTimes) })));
    setNextAppt(apptPage.items[0] || null);
    setCheckIn(checkPage.items[0] || null);
  }, [dayTimes]);

  useEffect(() => { load(); }, [load]);

  const untaken = (meds || [])
    .filter((m) => !isMedTakenToday(m))
    .sort((a, b) => (a.time || '').localeCompare(b.time || ''));
  const nextPill = untaken[0] || null;
  const takenCount = (meds || []).filter(isMedTakenToday).length;
  const isCheckedIn = !!checkIn?.checked_in;

  const takePill = async () => {
    if (!nextPill) return;
    const med = nextPill;
    setBusy(true);
    await applyMedTaken(med, true);
    await logDose(med, 'taken');
    await load();
    setBusy(false);
    showUndo(t('undoTakenMsg'), async () => {
      await applyMedTaken(med, false);
      await base44.entities.DoseLog.deleteMany({ medication_id: med.id, date: todayStr() });
      await load();
    });
  };

  const checkInNow = async () => {
    setBusy(true);
    const saved = checkIn
      ? await base44.entities.CheckIn.update(checkIn.id, { checked_in: true, checked_in_at: new Date().toISOString() })
      : await base44.entities.CheckIn.create({ date: todayStr(), checked_in: true, checked_in_at: new Date().toISOString() });
    await load();
    setBusy(false);
    showUndo(t('undoCheckInMsg'), async () => {
      await base44.entities.CheckIn.update(saved.id, { checked_in: false });
      await load();
    });
  };

  return (
    <>
    <section className="mb-8 rounded-3xl bg-card border-2 border-earth-marigold/40 shadow-sm overflow-hidden">
      <div className="bg-earth-lagoon px-6 py-3">
        <h2 className="font-heading text-2xl text-white">{t('yourDay')}</h2>
      </div>

      <div className="p-6 space-y-6">
        <div>
          <div className="flex items-center gap-4 mb-3">
            <span className="w-12 h-12 blob bg-earth-terracotta/15 text-earth-terracotta flex items-center justify-center shrink-0">
              <Pill className="w-6 h-6" strokeWidth={2.25} />
            </span>
            <div className="min-w-0">
              <p className="text-sm text-muted-foreground">{t('nextPill')}</p>
              <p className="text-2xl font-semibold text-foreground leading-tight">
                {meds === null
                  ? '…'
                  : nextPill
                    ? `${nextPill.name} — ${formatTime12(nextPill.time, locale)}`
                    : t('allPillsDone')}
              </p>
            </div>
          </div>

          {nextPill && (
            <button
              onClick={takePill}
              disabled={busy}
              className="w-full flex items-center justify-center gap-3 border-2 border-earth-sage text-earth-sageDark bg-card hover:bg-earth-sage/10 font-bold py-5 rounded-2xl text-xl transition min-h-[68px] disabled:opacity-50"
            >
              <Check className="w-7 h-7" strokeWidth={3} />
              {t('iTookIt')}
            </button>
          )}

          {meds && meds.length > 1 && (
            <p className="mt-3 text-muted-foreground">
              {t('takenTodayCount').replace('{taken}', String(takenCount)).replace('{total}', String(meds.length))}
            </p>
          )}
        </div>

        <div className="border-t-2 border-border" />

        <div className="flex items-center gap-4">
          <span className="w-12 h-12 blob bg-earth-lagoon/15 text-earth-lagoon flex items-center justify-center shrink-0">
            <Calendar className="w-6 h-6" strokeWidth={2.25} />
          </span>
          <div className="min-w-0">
            <p className="text-sm text-muted-foreground">{t('nextAppt')}</p>
            {nextAppt ? (
              <>
                <p className="text-2xl font-semibold text-foreground leading-tight">
                  {countdownLabel(nextAppt.date, t)}, {formatTime12(nextAppt.time, locale)}
                </p>
                <p className="text-lg text-muted-foreground truncate">{nextAppt.doctor_name}</p>
              </>
            ) : (
              <p className="text-xl text-foreground">{t('noUpcomingAppt')}</p>
            )}
          </div>
        </div>

        <div className="border-t-2 border-border" />

        {isCheckedIn ? (
          <div className="flex items-center gap-4 p-5 rounded-2xl bg-earth-sage/15 border-2 border-earth-sage/50">
            <Check className="w-8 h-8 text-earth-sageDark shrink-0" strokeWidth={3} />
            <p className="text-xl font-bold text-earth-sageDark">{t('checkInDone')}</p>
          </div>
        ) : (
          <ActionButton onClick={checkInNow} disabled={busy} size="large" className="w-full text-xl">
            <Heart className="w-8 h-8" strokeWidth={2.5} />
            {t('imOkayToday')}
          </ActionButton>
        )}
      </div>
    </section>
    <EmergencyButton variant="page" />
    </>
  );
}