import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import {
  getTodaySchedule, minutesFromTime, formatTime, nextUpcoming, DAY_TIME_LABELS,
} from '@/lib/daySchedule';
import ReadAloudButton from '@/components/ReadAloudButton';
import TimeEditDialog from '@/components/schedule/TimeEditDialog';
import { Pill, Utensils, Calendar, Dumbbell, Sunrise, Moon } from 'lucide-react';

const CX = 150;
const CY = 150;
const BAND = 104;
/** A circle can sit on the day band or just inside it. */
const RINGS = [104, 56];
/** Closest two circles on the same ring may be, in degrees. */
const MIN_ANGLE = 28;

const KIND_STYLE = {
  medication: { band: 'bg-earth-terracotta', Icon: Pill },
  meal: { band: 'bg-earth-sage', Icon: Utensils },
  appointment: { band: 'bg-earth-plum', Icon: Calendar },
  exercise: { band: 'bg-earth-lagoon', Icon: Dumbbell },
  wake: { band: 'bg-earth-marigold', Icon: Sunrise },
  bed: { band: 'bg-earth-navy', Icon: Moon },
};

const lookFor = (item) => KIND_STYLE[item.kind === 'routine' ? item.label : item.kind];

const labelFor = (item, t) =>
  item.kind === 'meal' || item.kind === 'routine' ? t(DAY_TIME_LABELS[item.label]) : item.label;

const angleFor = (time) => (minutesFromTime(time) / 1440) * 360 - 90;

/** Circles landing on the same time move to a second ring, then along the ring, so none overlap. */
function place(items) {
  const last = RINGS.map(() => -9999);
  return items.map((item) => {
    const angle = angleFor(item.time);
    let ring = -1;
    let room = -Infinity;
    RINGS.forEach((_, i) => {
      const gap = angle - last[i];
      if (gap >= MIN_ANGLE && gap > room) {
        room = gap;
        ring = i;
      }
    });
    if (ring === -1) ring = last.indexOf(Math.min(...last));
    const at = Math.max(angle, last[ring] + MIN_ANGLE);
    last[ring] = at;
    return { ...item, angle: at, radius: RINGS[ring] };
  });
}

/** Today from waking up to going to bed, as a clock you can tap. */
export default function DayDial() {
  const { t, dayTimes, updateDayTimes } = useAppSettings();
  const [raw, setRaw] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);

  const load = () => getTodaySchedule(dayTimes).then(setRaw);

  useEffect(() => {
    load()
      .then(() => setLoading(false))
      .catch(() => setLoading(false));
  }, [dayTimes]);

  // Meal and routine times come straight from the settings, so the circle moves at once.
  const items = raw
    .map((i) => {
      if (i.kind === 'meal' || i.kind === 'routine') return { ...i, time: dayTimes[i.label] };
      if (i.kind === 'exercise') return { ...i, time: dayTimes.exercise };
      return i;
    })
    .sort((a, b) => minutesFromTime(a.time) - minutesFromTime(b.time));
  const placed = place(items);
  const next = nextUpcoming(items);

  const saveTime = async (item, value) => {
    if (item.kind === 'meal' || item.kind === 'routine') {
      // Meals, wake-up and bedtime live in Settings, so the dial and Settings stay in step.
      updateDayTimes({ [item.label]: value });
    } else if (item.kind === 'exercise') {
      updateDayTimes({ exercise: value });
    } else if (item.kind === 'medication') {
      // A pill taken with breakfast always follows the breakfast time.
      if (item.mealLinked) updateDayTimes({ breakfast: value });
      else {
        await base44.entities.Medication.update(item.recordId, { time: value });
        await load();
      }
    } else if (item.kind === 'appointment') {
      await base44.entities.Appointment.update(item.recordId, { time: value });
      await load();
    }
    setEditing(null);
  };

  const spoken = [
    t('todayDial'),
    ...items.map((i) => `${labelFor(i, t)}, ${formatTime(i.time)}`),
    next ? `${t('nextUp')}: ${labelFor(next, t)}, ${formatTime(next.time)}` : t('nothingElseToday'),
  ].join('. ');

  if (loading) {
    return (
      <div className="mb-6 p-5 rounded-3xl bg-card border-2 border-border text-muted-foreground font-semibold">
        {t('loading')}
      </div>
    );
  }

  return (
    <section className="mb-6 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <div className="bg-earth-lagoon px-5 py-3">
        <h2 className="font-heading text-2xl text-white">{t('todayDial')}</h2>
      </div>

      <div className="p-5">
        <div className="relative w-full max-w-[420px] mx-auto aspect-square">
          <svg viewBox="0 0 300 300" className="absolute inset-0 w-full h-full" aria-hidden="true">
            <defs>
              <linearGradient id="dayNight" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1F2B40" />
                <stop offset="50%" stopColor="#2B3A55" />
                <stop offset="100%" stopColor="#D99A2B" />
              </linearGradient>
            </defs>

            <circle cx={CX} cy={CY} r={BAND} fill="none" stroke="url(#dayNight)" strokeWidth="26" />

            <text x={CX} y="30" textAnchor="middle" fontSize="18" className="fill-muted-foreground font-bold">12am</text>
            <text x="294" y={CY + 6} textAnchor="end" fontSize="18" className="fill-muted-foreground font-bold">6am</text>
            <text x={CX} y="296" textAnchor="middle" fontSize="18" className="fill-muted-foreground font-bold">12pm</text>
            <text x="6" y={CY + 6} fontSize="18" className="fill-muted-foreground font-bold">6pm</text>
          </svg>

          {placed.map((item) => {
            const look = lookFor(item);
            const rad = (item.angle * Math.PI) / 180;
            const left = 50 + (item.radius / 300) * 100 * Math.cos(rad);
            const top = 50 + (item.radius / 300) * 100 * Math.sin(rad);
            const isNext = next && next.id === item.id;
            const name = `${labelFor(item, t)}, ${formatTime(item.time)}`;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setEditing(item)}
                aria-label={`${name}. ${t('changeTime')}`}
                style={{ left: `${left}%`, top: `${top}%` }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 w-[15%] min-w-[56px] aspect-square rounded-full flex items-center justify-center text-white border-4 shadow-md transition hover:scale-110 focus-visible:outline focus-visible:outline-4 focus-visible:outline-earth-navy ${look.band} ${
                  isNext ? 'border-earth-marigold ring-4 ring-earth-marigold/40' : 'border-white'
                }`}
              >
                <look.Icon className="w-1/2 h-1/2" strokeWidth={2.5} />
              </button>
            );
          })}
        </div>

        <p className="text-center font-bold text-lg text-foreground mt-2">
          {next
            ? `${t('nextUp')}: ${labelFor(next, t)} — ${formatTime(next.time)}`
            : t('nothingElseToday')}
        </p>

        <p className="text-center text-muted-foreground mt-2">{t('dialHint')}</p>

        <div className="mt-4">
          <ReadAloudButton text={spoken} />
        </div>
      </div>

      {editing && (
        <TimeEditDialog
          title={labelFor(editing, t)}
          value={editing.time}
          onSave={(value) => saveTime(editing, value)}
          onClose={() => setEditing(null)}
        />
      )}
    </section>
  );
}