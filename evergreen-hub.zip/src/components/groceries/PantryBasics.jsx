import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Package, Plus } from 'lucide-react';

const STAPLES = [
  { name: 'Milk', nameEs: 'Leche', icon: '🥛' },
  { name: 'Bread', nameEs: 'Pan', icon: '🍞' },
  { name: 'Eggs', nameEs: 'Huevos', icon: '🥚' },
  { name: 'Butter', nameEs: 'Mantequilla', icon: '🧈' },
  { name: 'Cheese', nameEs: 'Queso', icon: '🧀' },
  { name: 'Bananas', nameEs: 'Plátanos', icon: '🍌' },
  { name: 'Onions', nameEs: 'Cebollas', icon: '🧅' },
  { name: 'Potatoes', nameEs: 'Papas', icon: '🥔' },
  { name: 'Rice', nameEs: 'Arroz', icon: '🍚' },
  { name: 'Pasta', nameEs: 'Pasta', icon: '🍝' },
  { name: 'Coffee', nameEs: 'Café', icon: '☕' },
  { name: 'Tea', nameEs: 'Té', icon: '🍵' },
];

const STORAGE_KEY = 'mahika_pantry_low';

export default function PantryBasics({ onAdd }) {
  const { t, language } = useAppSettings();
  const [lowItems, setLowItems] = useState([]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      setLowItems(stored ? JSON.parse(stored) : []);
    } catch { setLowItems([]); }
  }, []);

  const toggleLow = (name) => {
    setLowItems((prev) => {
      const next = prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  };

  return (
    <div className="mb-5 p-5 bg-white rounded-2xl border-2 border-slate-200">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
          <Package className="w-7 h-7 text-amber-600" strokeWidth={2.5} />
        </div>
        <h2 className="text-lg font-bold text-slate-900">{t('pantryBasics')}</h2>
      </div>
      <p className="text-sm text-slate-500 mb-3">{t('runningLowHint')}</p>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {STAPLES.map((staple) => {
          const isLow = lowItems.includes(staple.name);
          const label = language === 'es' ? staple.nameEs : staple.name;
          return (
            <div key={staple.name} className={`p-3 rounded-xl border-2 transition ${isLow ? 'bg-amber-50 border-amber-300' : 'bg-slate-50 border-slate-200'}`}>
              <button onClick={() => toggleLow(staple.name)} className="w-full flex items-center gap-2 mb-2">
                <span className="text-xl">{staple.icon}</span>
                <span className={`text-sm font-bold flex-1 text-left ${isLow ? 'text-amber-800' : 'text-slate-700'}`}>{label}</span>
              </button>
              {isLow && (
                <button
                  onClick={() => onAdd(label)}
                  className="w-full flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg bg-amber-600 text-white text-sm font-bold hover:bg-amber-700 transition"
                >
                  <Plus className="w-4 h-4" /> {t('addToList')}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}