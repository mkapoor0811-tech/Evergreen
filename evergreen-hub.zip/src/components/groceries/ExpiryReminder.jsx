import React, { useMemo } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { AlertCircle } from 'lucide-react';

const PERISHABLES = {
  en: {
    Produce: ['apple', 'banana', 'tomato', 'lettuce', 'greens', 'spinach', 'avocado', 'berries', 'berry', 'vegetable', 'fruit', 'herb', 'lemon', 'lime', 'onion', 'potato', 'carrot', 'celery', 'cucumber', 'pepper', 'salad', 'broccoli', 'cabbage'],
    Dairy: ['milk', 'cheese', 'yogurt', 'yoghurt', 'butter', 'cream'],
    Meat: ['chicken', 'beef', 'pork', 'fish', 'salmon', 'turkey', 'bacon', 'sausage', 'ham', 'shrimp', 'meat', 'ground'],
  },
  es: {
    Produce: ['manzana', 'plátano', 'tomate', 'lechuga', 'verde', 'espinaca', 'aguacate', 'bayas', 'vegetal', 'fruta', 'hierba', 'limón', 'cebolla', 'papa', 'zanahoria', 'apio', 'pepino', 'pimiento', 'ensalada', 'brócoli', 'repollo'],
    Dairy: ['leche', 'queso', 'yogur', 'mantequilla', 'crema'],
    Meat: ['pollo', 'res', 'cerdo', 'pescado', 'salmón', 'pavo', 'tocino', 'salchicha', 'jamón', 'camarón', 'carne', 'molida'],
  },
};

const TWO_WEEKS = 14 * 24 * 60 * 60 * 1000;

export default function ExpiryReminder({ items }) {
  const { t, language } = useAppSettings();
  const categories = PERISHABLES[language] || PERISHABLES.en;

  const forgotten = useMemo(() => {
    const now = Date.now();
    return (items || [])
      .filter((item) => !item.purchased)
      .filter((item) => {
        const created = new Date(item.created_date).getTime();
        return now - created >= TWO_WEEKS;
      })
      .filter((item) => {
        const text = item.item.toLowerCase();
        return Object.values(categories).some(cats => cats.some(cat => text.includes(cat)));
      })
      .map((item) => {
        const text = item.item.toLowerCase();
        const catEntry = Object.entries(categories).find(([_, cats]) => cats.some(cat => text.includes(cat)));
        return { ...item, category: catEntry ? catEntry[0] : 'Produce' };
      });
  }, [items, categories]);

  if (forgotten.length === 0) return null;

  return (
    <div className="mt-5 p-5 bg-white rounded-2xl border-2 border-orange-200">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-12 h-12 rounded-xl bg-orange-100 flex items-center justify-center">
          <AlertCircle className="w-7 h-7 text-orange-600" strokeWidth={2.5} />
        </div>
        <h2 className="text-lg font-bold text-slate-900">{t('expiryReminder')}</h2>
      </div>
      <div className="space-y-2">
        {forgotten.map((item) => (
          <div key={item.id} className="flex items-center gap-3 p-3 bg-orange-50 rounded-xl border border-orange-200">
            <span className="px-2 py-1 rounded-lg bg-orange-200 text-orange-800 text-xs font-bold shrink-0">{item.category}</span>
            <span className="flex-1 text-slate-800 font-semibold">{item.item}</span>
            <span className="text-sm text-slate-500 text-right">{t('expiryReminderMsg')}</span>
          </div>
        ))}
      </div>
    </div>
  );
}