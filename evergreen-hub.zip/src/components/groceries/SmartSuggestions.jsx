import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Sparkles, Plus } from 'lucide-react';

const SUGGESTIONS = {
  en: {
    diabetic: ['Sugar-free jam', 'Whole grain bread', 'Brown rice', 'Fresh berries', 'Plain yogurt', 'Cinnamon', 'Almonds', 'Sugar-free applesauce'],
    lowSodium: ['Low-sodium broth', 'Fresh herbs (basil, cilantro)', 'Unsalted mixed nuts', 'Lemon (for seasoning)', 'Fresh garlic', 'No-salt-added beans', 'Sweet potatoes'],
    digestive: ['Bananas', 'White rice', 'Oatmeal', 'Plain crackers', 'Chicken breast', 'Eggs', 'Yogurt', 'Applesauce'],
    general: ['Mixed greens', 'Olive oil', 'Fresh salmon', 'Sweet potatoes', 'Quinoa', 'Seasonal fruit', 'Greek yogurt', 'Fresh spinach'],
  },
  es: {
    diabetic: ['Mermelada sin azúcar', 'Pan integral', 'Arroz integral', 'Bayas frescas', 'Yogur natural', 'Canela', 'Almendras', 'Compota sin azúcar'],
    lowSodium: ['Caldo bajo en sodio', 'Hierbas frescas (albahaca, cilantro)', 'Nueces mixtas sin sal', 'Limón (para sazonar)', 'Ajo fresco', 'Frijoles sin sal añadida', 'Camotes'],
    digestive: ['Plátanos', 'Arroz blanco', 'Avena', 'Galletas simples', 'Pechuga de pollo', 'Huevos', 'Yogur', 'Compota de manzana'],
    general: ['Mezcla de verdes', 'Aceite de oliva', 'Salmón fresco', 'Camotes', 'Quinoa', 'Fruta de temporada', 'Yogur griego', 'Espinaca fresca'],
  },
};

const STORAGE_KEY = 'mahika_dietary_needs';

export default function SmartSuggestions({ onAdd }) {
  const { t, language } = useAppSettings();
  const [needs, setNeeds] = useState([]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      setNeeds(stored ? JSON.parse(stored) : []);
    } catch { setNeeds([]); }
  }, []);

  if (needs.length === 0) return null;

  const data = SUGGESTIONS[language] || SUGGESTIONS.en;
  const suggestions = [...new Set(needs.flatMap(key => data[key] || []))].slice(0, 8);

  if (suggestions.length === 0) return null;

  return (
    <div className="mb-5 p-5 bg-white rounded-2xl border-2 border-teal-200">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-xl bg-teal-100 flex items-center justify-center">
          <Sparkles className="w-7 h-7 text-teal-600" strokeWidth={2.5} />
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900">{t('smartSuggestions')}</h2>
          <p className="text-sm text-slate-500">{t('suggestedForYou')}</p>
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        {suggestions.map((item) => (
          <button
            key={item}
            onClick={() => onAdd(item)}
            className="flex items-center gap-1 px-3 py-2 rounded-xl bg-teal-50 border border-teal-200 text-teal-800 font-semibold text-sm hover:bg-teal-100 transition"
          >
            <Plus className="w-4 h-4" /> {item}
          </button>
        ))}
      </div>
    </div>
  );
}