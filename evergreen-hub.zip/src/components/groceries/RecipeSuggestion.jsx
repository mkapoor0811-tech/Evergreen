import React, { useMemo } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { ChefHat } from 'lucide-react';

const RECIPES = {
  en: [
    { name: 'Cheese Omelette', ingredients: ['egg', 'cheese', 'milk'], instructions: 'Whisk eggs with a splash of milk, fold in grated cheese, and cook in a buttered pan over medium heat until set.' },
    { name: 'Chicken Stir-fry', ingredients: ['chicken', 'rice', 'vegetable'], instructions: 'Cook rice. Stir-fry sliced chicken with mixed vegetables in oil, then serve over rice.' },
    { name: 'Garlic Pasta', ingredients: ['pasta', 'garlic', 'olive oil'], instructions: 'Boil pasta. Sauté minced garlic in olive oil, toss with cooked pasta, and season with herbs.' },
    { name: 'Banana Oatmeal', ingredients: ['oatmeal', 'banana', 'milk'], instructions: 'Cook oatmeal with milk, top with sliced bananas and a drizzle of honey.' },
    { name: 'Vegetable Soup', ingredients: ['broth', 'vegetable', 'potato'], instructions: 'Simmer broth with diced vegetables and potatoes until tender. Season with herbs.' },
    { name: 'Fresh Salad', ingredients: ['greens', 'tomato', 'olive oil'], instructions: 'Toss fresh greens with sliced tomatoes, drizzle with olive oil and lemon juice.' },
    { name: 'Salmon with Rice', ingredients: ['salmon', 'rice', 'lemon'], instructions: 'Bake or pan-sear salmon, serve over rice with a squeeze of fresh lemon.' },
    { name: 'Yogurt Parfait', ingredients: ['yogurt', 'berries', 'oatmeal'], instructions: 'Layer yogurt with fresh berries and a sprinkle of oatmeal for a healthy snack.' },
  ],
  es: [
    { name: 'Tortilla de Queso', ingredients: ['huevo', 'queso', 'leche'], instructions: 'Bate huevos con un chorrito de leche, añade queso rallado, y cocina en mantequilla a fuego medio.' },
    { name: 'Salteado de Pollo', ingredients: ['pollo', 'arroz', 'vegetal'], instructions: 'Cocina arroz. Saltea pollo en trozos con vegetales en aceite, sirve sobre el arroz.' },
    { name: 'Pasta al Ajo', ingredients: ['pasta', 'ajo', 'aceite de oliva'], instructions: 'Hierve pasta. Saltea ajo picado en aceite de oliva, mezcla con la pasta y sazona con hierbas.' },
    { name: 'Avena con Plátano', ingredients: ['avena', 'plátano', 'leche'], instructions: 'Cocina avena con leche, cubre con plátano en rodajas y un chorrito de miel.' },
    { name: 'Sopa de Vegetales', ingredients: ['caldo', 'vegetal', 'papa'], instructions: 'Hierve caldo con vegetales en trozos y papas hasta que estén tiernos. Sazona con hierbas.' },
    { name: 'Ensalada Fresca', ingredients: ['verde', 'tomate', 'aceite de oliva'], instructions: 'Mezcla verdes con tomates en rodajas, adereza con aceite de oliva y jugo de limón.' },
    { name: 'Salmón con Arroz', ingredients: ['salmón', 'arroz', 'limón'], instructions: 'Hornea o sella el salmón, sirve sobre arroz con jugo de limón fresco.' },
    { name: 'Yogur con Frutas', ingredients: ['yogur', 'bayas', 'avena'], instructions: 'Capas de yogur con bayas frescas y un poco de avena para un snack saludable.' },
  ],
};

export default function RecipeSuggestion({ items }) {
  const { t, language } = useAppSettings();
  const recipes = RECIPES[language] || RECIPES.en;
  const itemTexts = (items || []).map(i => i.item.toLowerCase());

  const match = useMemo(() => {
    for (const recipe of recipes) {
      const matched = recipe.ingredients.filter(ing =>
        itemTexts.some(text => text.includes(ing))
      );
      if (matched.length >= 3) return { recipe, matched };
    }
    return null;
  }, [itemTexts, recipes]);

  if (!match) return null;

  return (
    <div className="mt-5 p-5 bg-white rounded-2xl border-2 border-purple-200">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
          <ChefHat className="w-7 h-7 text-purple-600" strokeWidth={2.5} />
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900">{t('recipeIdea')}</h2>
          <p className="text-sm text-slate-500">{t('recipeMatch')}</p>
        </div>
      </div>
      <div className="p-4 bg-purple-50 rounded-xl">
        <p className="text-xl font-bold text-purple-800 mb-2">{match.recipe.name}</p>
        <p className="text-slate-700 leading-relaxed">{match.recipe.instructions}</p>
        <div className="mt-3 flex flex-wrap gap-1">
          {match.matched.map((ing) => (
            <span key={ing} className="px-2 py-1 rounded-lg bg-purple-100 text-purple-700 text-sm font-semibold">
              {ing}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}