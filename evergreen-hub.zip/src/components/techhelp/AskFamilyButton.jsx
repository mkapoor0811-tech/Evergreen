import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { sendTechHelpRequest } from '@/lib/techHelpAlerts';
import { LifeBuoy, CheckCircle2, Loader2 } from 'lucide-react';

export default function AskFamilyButton() {
  const { t } = useAppSettings();
  const [state, setState] = useState('idle'); // idle | sending | sent | noContact | error

  const handleAsk = async () => {
    setState('sending');
    try {
      const res = await sendTechHelpRequest();
      setState(res.sent ? 'sent' : 'noContact');
    } catch (e) {
      setState('error');
    }
  };

  if (state === 'sent') {
    return (
      <div className="flex items-start gap-3 p-5 rounded-2xl bg-primary/10 border border-primary/30">
        <CheckCircle2 className="w-7 h-7 text-primary shrink-0 mt-0.5" strokeWidth={2} />
        <p className="text-lg text-foreground">{t('askMyFamilySent')}</p>
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={handleAsk}
        disabled={state === 'sending'}
        className="w-full flex items-center justify-center gap-3 bg-accent hover:bg-accent/90 text-accent-foreground font-bold text-lg py-4 rounded-2xl transition min-h-[60px] disabled:opacity-60"
      >
        {state === 'sending' ? <Loader2 className="w-6 h-6 animate-spin" /> : <LifeBuoy className="w-6 h-6" strokeWidth={2} />}
        {t('askMyFamily')}
      </button>
      {state === 'noContact' && (
        <Link to="/settings" className="block mt-3 text-center text-muted-foreground underline">
          {t('askMyFamilyNoContact')}
        </Link>
      )}
      {state === 'error' && (
        <p className="mt-3 text-center text-destructive">{t('askMyFamilyError')}</p>
      )}
    </div>
  );
}