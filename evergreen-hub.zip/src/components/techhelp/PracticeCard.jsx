import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Phone, PhoneCall, Send, Wifi, Camera, CheckCircle2, RotateCcw } from 'lucide-react';

export default function PracticeCard({ activity }) {
  const { t } = useAppSettings();
  const [feedback, setFeedback] = useState('');
  const [text, setText] = useState('');
  const [wifiOn, setWifiOn] = useState(false);

  const reset = () => {
    setFeedback('');
    setText('');
    setWifiOn(false);
  };

  if (feedback) {
    return (
      <div className="p-6 rounded-2xl bg-primary/10 border border-primary/30 text-center">
        <CheckCircle2 className="w-12 h-12 text-primary mx-auto mb-3" strokeWidth={2} />
        <p className="text-xl text-foreground mb-5">{feedback}</p>
        <button
          onClick={reset}
          className="inline-flex items-center gap-2 bg-card border border-border text-foreground font-bold px-6 py-3 rounded-xl min-h-[56px]"
        >
          <RotateCcw className="w-5 h-5" />
          {t('practiceTryAgain')}
        </button>
      </div>
    );
  }

  const mock = () => {
    switch (activity.id) {
      case 'answer-call':
        return (
          <div className="rounded-2xl bg-secondary p-6 text-center">
            <p className="text-muted-foreground mb-1">Incoming call</p>
            <p className="font-heading text-2xl text-foreground mb-5">Daughter</p>
            <button
              onClick={() => setFeedback('That’s exactly right. Tapping the green button answers a call.')}
              className="inline-flex items-center gap-3 bg-green-600 hover:bg-green-700 text-white font-bold text-xl px-8 py-4 rounded-2xl min-h-[64px]"
            >
              <PhoneCall className="w-7 h-7" strokeWidth={2} /> Answer
            </button>
          </div>
        );
      case 'call-contact':
        return (
          <div className="space-y-2">
            {['Daughter', 'Doctor', 'Neighbor'].map((n) => (
              <button
                key={n}
                onClick={() => setFeedback(`Well done — tapping a name like “${n}” starts the call.`)}
                className="w-full flex items-center gap-3 rounded-xl border border-border bg-card hover:border-primary/40 px-4 py-3 text-left min-h-[56px]"
              >
                <Phone className="w-5 h-5 text-primary" strokeWidth={2} />
                <span className="text-lg text-foreground">{n}</span>
              </button>
            ))}
          </div>
        );
      case 'send-text':
        return (
          <div className="space-y-3">
            <div className="rounded-xl bg-secondary p-4">
              <p className="text-muted-foreground text-sm mb-1">To: Daughter</p>
              <p className="text-foreground">See you on Sunday!</p>
            </div>
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Type a short reply…"
              className="w-full px-4 py-3 rounded-xl border-2 border-border focus:border-primary outline-none text-lg bg-card"
            />
            <button
              onClick={() => setFeedback('Nicely done! That is how you send a text message.')}
              disabled={!text.trim()}
              className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground font-bold py-4 rounded-xl min-h-[56px] disabled:opacity-40"
            >
              <Send className="w-5 h-5" strokeWidth={2} /> Send
            </button>
          </div>
        );
      case 'wifi':
        return (
          <div className="rounded-2xl bg-secondary p-6 text-center">
            <Wifi className={`w-14 h-14 mx-auto mb-4 ${wifiOn ? 'text-primary' : 'text-muted-foreground'}`} strokeWidth={2} />
            <p className="text-lg text-foreground mb-4">{wifiOn ? 'Wi-Fi is on' : 'Wi-Fi is off'}</p>
            <button
              onClick={() => { setWifiOn(true); setFeedback('That’s it — tapping the switch turns Wi-Fi on.'); }}
              className={`inline-flex items-center gap-3 font-bold text-lg px-8 py-4 rounded-2xl min-h-[64px] ${wifiOn ? 'bg-primary text-primary-foreground' : 'bg-card border border-border text-foreground'}`}
            >
              Turn Wi-Fi on
            </button>
          </div>
        );
      case 'photo':
        return (
          <div className="rounded-2xl bg-secondary p-6 text-center">
            <div className="w-full aspect-video rounded-xl bg-primary/10 flex items-center justify-center mb-5">
              <Camera className="w-10 h-10 text-primary" strokeWidth={2} />
            </div>
            <button
              onClick={() => setFeedback('Lovely — tapping the round button takes the photo.')}
              className="w-20 h-20 rounded-full bg-card border-4 border-foreground mx-auto block min-h-[80px]"
              aria-label="Take a pretend photo"
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div>
      <p className="text-lg text-foreground mb-4">{activity.prompt}</p>
      {mock()}
    </div>
  );
}