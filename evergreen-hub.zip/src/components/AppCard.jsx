import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { sectionLook, useSectionColor } from '@/lib/sectionColors';

/** A link card to another screen. It wears the colour of the section it belongs
 *  to, and the same corners and spacing as every other card. */
export default function AppCard({ to, icon: Icon, title, description, color, variant = 'row' }) {
  const inherited = useSectionColor();
  const look = sectionLook(color || inherited);

  if (variant === 'tall') {
    return (
      <Link
        to={to}
        className="flex flex-col gap-3 rounded-3xl bg-card border-2 border-border p-5 hover:shadow-md transition"
      >
        <span className={`w-14 h-14 blob flex items-center justify-center shrink-0 ${look.tint} ${look.ink}`}>
          <Icon className="w-7 h-7" strokeWidth={2.25} />
        </span>
        <span>
          <span className="block font-heading text-xl text-foreground leading-tight">{title}</span>
          {description && <span className="block text-sm text-muted-foreground mt-1">{description}</span>}
        </span>
      </Link>
    );
  }

  return (
    <Link
      to={to}
      className="flex items-stretch gap-4 rounded-3xl bg-card border-2 border-border pr-5 overflow-hidden hover:shadow-md transition"
    >
      <span className={`w-2 shrink-0 ${look.bar}`} />
      <span className={`w-12 h-12 my-4 blob-alt flex items-center justify-center shrink-0 ${look.tint} ${look.ink}`}>
        <Icon className="w-6 h-6" strokeWidth={2.25} />
      </span>
      <span className="flex-1 min-w-0 py-4">
        <span className="block font-heading text-xl text-foreground leading-tight">{title}</span>
        {description && <span className="block text-sm text-muted-foreground mt-0.5">{description}</span>}
      </span>
      <ArrowRight className="w-5 h-5 text-muted-foreground shrink-0 self-center" strokeWidth={2} />
    </Link>
  );
}