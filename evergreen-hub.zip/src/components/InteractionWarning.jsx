import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { AlertTriangle, Stethoscope } from 'lucide-react';

export default function InteractionWarning({ interactions }) {
  const { t } = useAppSettings();
  if (!interactions || interactions.length === 0) return null;

  return (
    <div className="p-4 rounded-xl border-2 border-amber-300 bg-amber-50">
      <div className="flex items-center gap-2 mb-2">
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" strokeWidth={2.5} />
        <p className="font-bold text-amber-800">{t('interactionCheckTitle')}</p>
      </div>
      <ul className="space-y-1 mb-3">
        {interactions.map((i, idx) => (
          <li key={idx} className="text-amber-800 text-lg leading-relaxed">
            {t('mayInteractWith')} <span className="font-bold">{i.existingMed}</span> — {i.note}.
          </li>
        ))}
      </ul>
      <p className="flex items-start gap-2 text-slate-700 font-semibold leading-relaxed">
        <Stethoscope className="w-5 h-5 text-slate-600 shrink-0 mt-0.5" />
        {t('checkWithDoctor')}
      </p>
    </div>
  );
}