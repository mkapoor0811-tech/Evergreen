import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Pill, Heart, PhoneCall, HelpCircle, X } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';

export default function SimpleNav() {
  const { t } = useAppSettings();
  const location = useLocation();
  const navigate = useNavigate();
  const [helpOpen, setHelpOpen] = useState(false);
  const [phone, setPhone] = useState(() => localStorage.getItem('mahika_caregiver_phone') || '');
  const [note, setNote] = useState('');

  useEffect(() => {
    const onFocus = () => setPhone(localStorage.getItem('mahika_caregiver_phone') || '');
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, []);

  useEffect(() => { setNote(''); }, [location.pathname]);

  const callFamily = () => {
    if (!phone) { setNote(t('simpleNoPhone')); return; }
    window.location.href = `tel:${phone.replace(/[^\d+]/g, '')}`;
  };

  const buttons = [
    { key: 'pills', icon: Pill, label: t('simpleMyPills'), tone: 'bg-section-blue', to: '/medications' },
    { key: 'checkin', icon: Heart, label: t('simpleCheckIn'), tone: 'bg-section-navy', to: '/check-in' },
    { key: 'call', icon: PhoneCall, label: t('simpleCallFamily'), tone: 'bg-section-coral', onClick: callFamily },
    { key: 'help', icon: HelpCircle, label: t('simpleHelp'), tone: 'bg-earth-plum', onClick: () => setHelpOpen(true) },
  ];

  return (
    <>
      {note && (
        <div className="fixed bottom-[200px] left-0 right-0 z-40 px-4">
          <div className="max-w-3xl mx-auto rounded-2xl bg-earth-marigold text-white font-bold px-5 py-4 shadow-lg">
            {note}
          </div>
        </div>
      )}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t-2 border-border shadow-[0_-4px_16px_rgba(0,0,0,0.08)]">
        <div className="max-w-3xl mx-auto grid grid-cols-2 gap-3 p-3">
          {buttons.map(({ key, icon: Icon, label, tone, to, onClick }) => {
            const active = to && (location.pathname === to || location.pathname.startsWith(`${to}/`));
            const inner = (
              <>
                <span className={`w-14 h-14 blob flex items-center justify-center shrink-0 ${tone} text-white`}>
                  <Icon className="w-8 h-8" strokeWidth={2.25} />
                </span>
                <span className="font-heading text-lg leading-tight text-foreground">{label}</span>
              </>
            );
            const cls = `flex flex-col items-center justify-center gap-2 rounded-2xl border-2 py-4 min-h-[132px] transition ${
              active ? 'border-earth-navy bg-secondary' : 'border-border bg-card'
            }`;
            return to ? (
              <Link key={key} to={to} className={cls}>{inner}</Link>
            ) : (
              <button key={key} type="button" onClick={onClick} className={cls}>{inner}</button>
            );
          })}
        </div>
      </nav>

      {helpOpen && (
        <div className="fixed inset-0 z-[100] bg-black/50 flex items-center justify-center p-4" onClick={() => setHelpOpen(false)}>
          <div className="bg-card rounded-3xl border-2 border-border max-w-lg w-full p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-heading text-2xl text-foreground">{t('simpleHelpTitle')}</h2>
              <button onClick={() => setHelpOpen(false)} className="p-2 rounded-xl hover:bg-muted transition min-h-[56px] min-w-[48px] flex items-center justify-center">
                <X className="w-7 h-7 text-muted-foreground" />
              </button>
            </div>
            <p className="text-lg text-foreground leading-relaxed">{t('simpleHelpText')}</p>
            <button
              onClick={() => { setHelpOpen(false); navigate('/settings'); }}
              className="w-full mt-5 py-4 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
            >
              {t('settings')}
            </button>
          </div>
        </div>
      )}
    </>
  );
}