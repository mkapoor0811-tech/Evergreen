import React from 'react';
import { sectionLook, useSectionColor } from '@/lib/sectionColors';

/**
 * The one button used across the app.
 *
 * `primary`   – the colour of the section you are in. The main action on a screen.
 * `secondary` – light gray. A second choice, or Cancel.
 * `danger`    – rust red. Emergency actions only.
 *
 * `size` sets the height: `medium` (56px, the everyday button), `large`
 * (72px, the main action on a screen) and `compact` (56px, for buttons that sit
 * side by side). Nothing is ever shorter than 56px, so nothing is hard to tap.
 * Width and text size still come from `className`, so each screen keeps its shape.
 */
const VARIANTS = {
  secondary: 'bg-secondary hover:bg-muted text-foreground',
  danger: 'bg-earth-terracotta hover:bg-earth-terracottaDark text-white',
};

const SIZES = {
  medium: 'min-h-[56px] py-4 gap-2',
  large: 'min-h-[72px] py-6 gap-3',
  compact: 'min-h-[56px] px-5 py-3 gap-2',
};

export default function ActionButton({
  variant = 'primary',
  size = 'medium',
  type = 'button',
  className = '',
  children,
  ...props
}) {
  const look = sectionLook(useSectionColor());
  const look_class = variant === 'primary' ? look.solid : VARIANTS[variant];

  return (
    <button
      type={type}
      className={`flex items-center justify-center font-bold rounded-2xl transition disabled:opacity-50 ${look_class} ${SIZES[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}