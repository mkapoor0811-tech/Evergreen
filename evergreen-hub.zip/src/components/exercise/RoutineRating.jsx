import React from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { Smile, Meh, Frown } from 'lucide-react';
import { todayLocal } from '@/lib/localDate';

const OPTIONS = [
  { key: 'great', labelKey: 'feltGreat', icon: Smile, cls: 'bg-earth-sage/20 border-earth-sage text-earth-sageDark hover:bg-earth-sage/30' },
  { key: 'okay', labelKey: 'feltOkay', icon: Meh, cls: 'bg-earth-marigold/20 border-earth-marigold text-earth-marigoldDark hover:bg-earth-marigold/30' },
  { key: 'hard', labelKey: 'feltHard', icon: Frown, cls: 'bg-earth-plum/12 border-earth-plum text-earth-plum hover:bg-earth-plum/20' },
];

export default function RoutineRating({ exercise, onRated }) {
  const { t } = useAppSettings();
  const today = todayLocal();
  const existing = Array.isArray(exercise.ratings) ? exercise.ratings : [];
  const todayRating = existing.find((r) => r.date === today);

  const rate = async (rating) => {
    const others = existing.filter((r) => r.date !== today);
    await base44.entities.Exercise.update(exercise.id, { ratings: [...others, { date: today, rating }] });
    if (onRated) onRated(rating);
  };

  return (
    <div className="mt-3 p-4 rounded-2xl bg-secondary/60">
      <p className="font-bold text-foreground mb-3">{t('howDidThatFeel')}</p>
      <div className="flex gap-2">
        {OPTIONS.map(({ key, labelKey, icon: Icon, cls }) => (
          <button
            key={key}
            onClick={() => rate(key)}
            className={`flex-1 flex flex-col items-center gap-1 py-3 rounded-xl border-2 font-bold transition ${cls} ${
              todayRating?.rating === key ? 'ring-2 ring-foreground' : ''
            }`}
          >
            <Icon className="w-6 h-6" strokeWidth={2.25} />
            <span className="text-sm">{t(labelKey)}</span>
          </button>
        ))}
      </div>
    </div>
  );
}