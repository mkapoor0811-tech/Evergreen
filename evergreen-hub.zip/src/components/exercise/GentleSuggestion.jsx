import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Leaf } from 'lucide-react';

export default function GentleSuggestion({ mood, lastRating }) {
  const { t } = useAppSettings();
  const lowEnergy = mood === 'not_great' || mood === 'down' || lastRating === 'hard';
  if (!lowEnergy) return null;

  return (
    <section className="mb-6 rounded-3xl bg-earth-sage/15 border-2 border-earth-sage/40 p-5">
      <div className="flex items-start gap-4">
        <span className="w-12 h-12 blob bg-earth-sage/25 text-earth-sageDark flex items-center justify-center shrink-0">
          <Leaf className="w-6 h-6" strokeWidth={2.25} />
        </span>
        <div>
          <h2 className="font-heading text-xl text-foreground">{t('gentleTitle')}</h2>
          <p className="text-foreground mb-3">{t('gentleIntro')}</p>
          <ul className="space-y-1.5">
            {['gentle1', 'gentle2', 'gentle3'].map((key) => (
              <li key={key} className="flex items-start gap-2 text-foreground">
                <span className="w-2 h-2 rounded-full bg-earth-sage mt-2.5 shrink-0" />
                {t(key)}
              </li>
            ))}
          </ul>
          <p className="text-muted-foreground mt-3">{t('gentleNote')}</p>
        </div>
      </div>
    </section>
  );
}