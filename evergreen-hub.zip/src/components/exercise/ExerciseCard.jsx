import React from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { Check, Play, Trash2, Clock } from 'lucide-react';
import RoutineRating from '@/components/exercise/RoutineRating';
import ExerciseVideo from '@/components/exercise/ExerciseVideo';
import ExerciseSteps from '@/components/exercise/ExerciseSteps';

const ABILITY_KEYS = ['seated', 'standing', 'balance'];

export default function ExerciseCard({ exercise: ex, isDone, ytId, onToggle, onDelete, onChanged }) {
  const { t } = useAppSettings();

  const setAbility = async (ability) => {
    await base44.entities.Exercise.update(ex.id, { ability });
    onChanged();
  };

  return (
    <div className={`p-5 rounded-3xl border ${isDone ? 'bg-earth-sage/12 border-earth-sage/50' : 'bg-card border-border'}`}>
      <div className="flex items-center gap-4">
        <button
          onClick={() => onToggle(ex)}
          className={`w-14 h-14 rounded-2xl flex items-center justify-center transition shrink-0 ${
            isDone ? 'bg-earth-sage text-white' : 'bg-card border-2 border-border hover:border-earth-sage'
          }`}
        >
          {isDone ? <Check className="w-8 h-8" strokeWidth={3} /> : <Play className="w-7 h-7 text-muted-foreground" />}
        </button>

        <div className="flex-1 min-w-0">
          <span className={`block text-lg font-bold ${isDone ? 'text-muted-foreground line-through' : 'text-foreground'}`}>
            {ex.name}
          </span>
          {ex.duration_minutes ? (
            <span className="inline-flex items-center gap-1 text-sm text-muted-foreground mt-1">
              <Clock className="w-4 h-4" />
              {ex.duration_minutes} {t('minutesShort')}
            </span>
          ) : null}
        </div>

        <button
          onClick={() => onDelete(ex.id)}
          className="p-3 rounded-xl text-destructive hover:bg-destructive/10 transition shrink-0"
        >
          <Trash2 className="w-6 h-6" />
        </button>
      </div>

      {!ex.ability && (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="text-sm text-muted-foreground font-semibold">{t('ability')}:</span>
          {ABILITY_KEYS.map((key) => (
            <button
              key={key}
              onClick={() => setAbility(key)}
              className="px-3 py-1.5 rounded-full bg-secondary hover:bg-muted text-foreground font-bold text-sm transition"
            >
              {t(key)}
            </button>
          ))}
        </div>
      )}

      {ex.notes && (
        <p className="mt-3 text-foreground bg-earth-marigold/15 border border-earth-marigold/40 rounded-lg px-3 py-2">
          📝 {ex.notes}
        </p>
      )}

      {isDone && <RoutineRating exercise={ex} onRated={onChanged} />}

      {ytId ? (
        <ExerciseVideo title={ex.name} url={ex.youtube_url} />
      ) : (
        <ExerciseSteps name={ex.name} />
      )}
    </div>
  );
}