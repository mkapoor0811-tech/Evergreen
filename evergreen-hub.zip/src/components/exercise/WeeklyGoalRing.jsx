import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Minus, Plus, Target } from 'lucide-react';

const RADIUS = 44;
const CIRC = 2 * Math.PI * RADIUS;

export default function WeeklyGoalRing({ done, goal, onGoalChange }) {
  const { t } = useAppSettings();
  const pct = goal > 0 ? Math.min(done / goal, 1) : 0;
  const reached = goal > 0 && done >= goal;

  return (
    <section className="mb-6 rounded-3xl bg-card border border-border p-5 flex flex-col sm:flex-row items-center gap-5">
      <div className="relative w-28 h-28 shrink-0">
        <svg viewBox="0 0 110 110" className="w-28 h-28 -rotate-90">
          <circle cx="55" cy="55" r={RADIUS} fill="none" stroke="hsl(var(--border))" strokeWidth="12" />
          <circle
            cx="55"
            cy="55"
            r={RADIUS}
            fill="none"
            stroke={reached ? 'hsl(var(--chart-1))' : 'hsl(var(--accent))'}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={CIRC}
            strokeDashoffset={CIRC * (1 - pct)}
            className="transition-all duration-500"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-heading text-3xl text-foreground leading-none">{done}</span>
          <span className="text-sm text-muted-foreground">/ {goal}</span>
        </div>
      </div>

      <div className="flex-1 min-w-0 text-center sm:text-left">
        <div className="flex items-center justify-center sm:justify-start gap-2 mb-1">
          <Target className="w-5 h-5 text-earth-terracotta" strokeWidth={2.25} />
          <h2 className="font-heading text-xl text-foreground">{t('weeklyGoal')}</h2>
        </div>
        <p className="text-muted-foreground mb-3">
          {t('sessionsThisWeek').replace('{count}', done).replace('{goal}', goal)}
        </p>
        <div className="flex items-center justify-center sm:justify-start gap-3">
          <button
            onClick={() => onGoalChange(Math.max(1, goal - 1))}
            className="w-11 h-11 rounded-xl bg-secondary hover:bg-muted flex items-center justify-center text-foreground transition"
          >
            <Minus className="w-5 h-5" strokeWidth={3} />
          </button>
          <span className="font-bold text-foreground">{goal} {t('goalSessions')}</span>
          <button
            onClick={() => onGoalChange(Math.min(14, goal + 1))}
            className="w-11 h-11 rounded-xl bg-secondary hover:bg-muted flex items-center justify-center text-foreground transition"
          >
            <Plus className="w-5 h-5" strokeWidth={3} />
          </button>
        </div>
      </div>
    </section>
  );
}