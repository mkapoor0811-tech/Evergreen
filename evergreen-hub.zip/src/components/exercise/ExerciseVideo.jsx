import React, { useEffect, useRef, useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { loadYouTubeApi } from '@/lib/youtubePlayer';
import { youTubeId, watchUrl } from '@/lib/videoLink';
import { Play } from 'lucide-react';

/**
 * Plays one exercise video inside the app, with a large "Watch on YouTube" button below it.
 * If the video cannot play, only that button is shown.
 */
export default function ExerciseVideo({ title, url }) {
  const { t } = useAppSettings();
  const id = youTubeId(url);
  const holderRef = useRef(null);
  const [failed, setFailed] = useState(!id);
  const [plainEmbed, setPlainEmbed] = useState(false);

  useEffect(() => {
    if (!id || !holderRef.current) return;
    const host = document.createElement('div');
    host.className = 'w-full h-full';
    holderRef.current.appendChild(host);

    let cancelled = false;
    let player = null;

    loadYouTubeApi()
      .then((YT) => {
        if (cancelled) return;
        player = new YT.Player(host, {
          videoId: id,
          width: '100%',
          height: '100%',
          playerVars: { rel: 0, playsinline: 1 },
          events: { onError: () => setFailed(true) },
        });
      })
      .catch(() => {
        if (!cancelled) setPlainEmbed(true);
      });

    return () => {
      cancelled = true;
      try {
        player?.destroy();
      } catch {
        /* the player was never created */
      }
    };
  }, [id]);

  return (
    <div className="mt-4">
      {!failed && (
        <div className="aspect-video rounded-xl overflow-hidden border-2 border-border bg-black">
          {plainEmbed ? (
            <iframe
              src={`https://www.youtube.com/embed/${id}`}
              title={title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              onError={() => setFailed(true)}
              className="w-full h-full"
            />
          ) : (
            <div ref={holderRef} className="w-full h-full" />
          )}
        </div>
      )}

      <a
        href={watchUrl(url)}
        target="_blank"
        rel="noreferrer"
        className="w-full mt-3 flex items-center justify-center gap-3 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-5 rounded-2xl transition min-h-[64px] text-xl"
      >
        <Play className="w-7 h-7" strokeWidth={2.5} />
        {t('watchOnYouTube')}
      </a>
    </div>
  );
}