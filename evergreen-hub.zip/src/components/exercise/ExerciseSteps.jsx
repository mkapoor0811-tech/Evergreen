import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { exerciseSteps } from '@/lib/exerciseSteps';

/** Written steps, shown instead of a video. */
export default function ExerciseSteps({ name }) {
  const { t, language } = useAppSettings();
  const steps = exerciseSteps(name, language);

  return (
    <div className="mt-4 p-5 rounded-2xl bg-secondary/60 border-2 border-border">
      <p className="font-heading text-xl text-foreground mb-3">{t('howToDoIt')}</p>
      <ol className="space-y-3">
        {steps.map((step, index) => (
          <li key={step} className="flex items-start gap-3">
            <span className="w-8 h-8 rounded-full bg-earth-lagoon text-white font-bold flex items-center justify-center shrink-0">
              {index + 1}
            </span>
            <span className="text-lg text-foreground leading-snug">{step}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}