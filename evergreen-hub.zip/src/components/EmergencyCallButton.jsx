import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Phone, PhoneCall } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';

export default function EmergencyCallButton() {
  const { t } = useAppSettings();
  const [phone, setPhone] = useState(() => localStorage.getItem('mahika_caregiver_phone') || '');

  // Re-read when the component regains focus (e.g. returning from Settings)
  useEffect(() => {
    const onFocus = () => setPhone(localStorage.getItem('mahika_caregiver_phone') || '');
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, []);

  if (!phone) {
    return (
      <Link
        to="/settings"
        className="block w-full mb-6 p-5 rounded-2xl border-2 border-dashed border-red-400 bg-red-50 hover:bg-red-100 transition"
      >
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-red-100 flex items-center justify-center shrink-0">
            <Phone className="w-8 h-8 text-red-600" strokeWidth={2.5} />
          </div>
          <div>
            <p className="text-lg font-bold text-red-700">{t('emergencyCall')}</p>
            <p className="text-sm text-red-600">{t('setEmergencyContact')}</p>
          </div>
        </div>
      </Link>
    );
  }

  const digits = phone.replace(/[^\d+]/g, '');
  return (
    <a
      href={`tel:${digits}`}
      className="block w-full mb-6 p-5 rounded-2xl bg-red-600 hover:bg-red-700 shadow-md transition"
    >
      <div className="flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-white/25 flex items-center justify-center shrink-0">
          <PhoneCall className="w-8 h-8 text-white" strokeWidth={2.5} />
        </div>
        <div>
          <p className="text-xl font-bold text-white">{t('callCaregiver')}</p>
          <p className="text-sm text-white/90">{phone}</p>
        </div>
      </div>
    </a>
  );
}