import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { SectionColorProvider, sectionLook, useSectionColor } from '@/lib/sectionColors';

/**
 * The one card style used across the app: a coloured header bar over a white body,
 * the same corners and the same space between cards on every screen.
 *
 * The colour comes from the section the screen belongs to, so a card about
 * medicines is blue and a card about visits is plum, everywhere in the app.
 * A `collapsible` card keeps a secondary section folded until it is tapped.
 */
export default function SectionCard({ title, icon: Icon, color, collapsible = false, defaultOpen = true, children, className = '' }) {
  const [open, setOpen] = useState(defaultOpen);
  const inherited = useSectionColor();
  const key = color || inherited;
  const look = sectionLook(key);
  const expanded = collapsible ? open : true;

  const inner = (
    <>
      {Icon && <Icon className="w-6 h-6 text-white shrink-0" strokeWidth={2.5} />}
      <h2 className="flex-1 text-left font-heading text-xl text-white leading-tight">{title}</h2>
      {collapsible && (
        <ChevronDown
          className={`w-7 h-7 text-white shrink-0 transition-transform ${expanded ? 'rotate-180' : ''}`}
          strokeWidth={2.5}
        />
      )}
    </>
  );

  return (
    <SectionColorProvider value={key}>
      <section className={`mb-5 rounded-3xl bg-card border-2 border-border overflow-hidden ${className}`}>
        {collapsible ? (
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={expanded}
            className={`w-full px-5 py-3 flex items-center gap-3 ${look.bar}`}
          >
            {inner}
          </button>
        ) : (
          <div className={`px-5 py-3 flex items-center gap-3 ${look.bar}`}>{inner}</div>
        )}
        {expanded && <div className="p-5">{children}</div>}
      </section>
    </SectionColorProvider>
  );
}