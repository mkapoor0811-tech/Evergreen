import React, { useState, useRef, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { LOCALES } from '@/lib/timeFormat';
import { Mic, X, Check } from 'lucide-react';

export default function VoiceButton({ onResult, label, prompt, className, compact = false }) {
  const { t, language } = useAppSettings();
  const [open, setOpen] = useState(false);
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState('');
  const recRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    setTranscript('');
    setError('');
    setListening(true);
    const SR = typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition);
    if (!SR) {
      setError('notSupported');
      setListening(false);
      return;
    }
    const rec = new SR();
    rec.lang = LOCALES[language] || 'en-US';
    rec.continuous = false;
    rec.interimResults = true;
    rec.onresult = (e) => {
      let text = '';
      for (let i = 0; i < e.results.length; i++) {
        text += e.results[i][0].transcript;
      }
      setTranscript(text);
    };
    rec.onend = () => setListening(false);
    rec.onerror = (e) => {
      if (e.error === 'no-speech') setError('noSpeech');
      else if (e.error === 'not-allowed' || e.error === 'service-not-allowed') setError('notAllowed');
      else setError('error');
      setListening(false);
    };
    try {
      rec.start();
    } catch {
      setError('error');
      setListening(false);
    }
    recRef.current = rec;
    return () => {
      try { rec.abort(); } catch { /* noop */ }
    };
  }, [open, language]);

  const handleDone = () => {
    const text = transcript.trim();
    if (text) onResult(text);
    setOpen(false);
  };

  return (
    <>
      {compact ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-label={label || t('addByVoice')}
          className={`shrink-0 flex items-center justify-center w-[56px] h-[56px] rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white transition ${className || ''}`}
        >
          <Mic className="w-7 h-7" strokeWidth={2.5} />
        </button>
      ) : (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className={`w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-2xl transition min-h-[56px] ${className || ''}`}
        >
          <Mic className="w-6 h-6" strokeWidth={2.5} />
          {label || t('addByVoice')}
        </button>
      )}

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
          onClick={() => setOpen(false)}
        >
          <div
            className="bg-white rounded-3xl p-6 max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-slate-900">{t('voiceInput')}</h3>
              <button onClick={() => setOpen(false)} className="p-2 rounded-lg hover:bg-slate-100">
                <X className="w-6 h-6 text-slate-500" />
              </button>
            </div>

            {error ? (
              <div className="text-center py-6">
                <p className="text-lg text-red-600 font-semibold">
                  {error === 'notSupported' ? t('voiceNotSupported')
                    : error === 'noSpeech' ? t('voiceNoSpeech')
                    : error === 'notAllowed' ? t('voiceNotAllowed')
                    : t('voiceError')}
                </p>
                <button
                  onClick={() => setOpen(false)}
                  className="mt-4 px-6 py-3 rounded-xl bg-slate-800 text-white font-bold min-h-[56px]"
                >
                  {t('cancel')}
                </button>
              </div>
            ) : (
              <>
                <p className="text-center text-slate-600 mb-4">{prompt || t('voicePromptDefault')}</p>
                <div className="flex justify-center mb-4">
                  <div className={`w-20 h-20 rounded-full flex items-center justify-center transition ${listening ? 'bg-red-500 animate-pulse' : 'bg-indigo-600'}`}>
                    <Mic className="w-10 h-10 text-white" strokeWidth={2.5} />
                  </div>
                </div>
                <p className="text-center text-sm font-bold text-slate-500 mb-2">
                  {listening ? t('voiceListening') : t('voiceDoneListening')}
                </p>
                <div className="min-h-[60px] p-4 bg-slate-50 rounded-xl text-center">
                  <p className="text-lg text-slate-800">{transcript || (listening ? '…' : '')}</p>
                </div>
                <div className="flex gap-3 mt-4">
                  <button
                    onClick={() => setOpen(false)}
                    className="flex-1 py-4 rounded-xl border-2 border-slate-200 font-bold text-slate-700 min-h-[56px]"
                  >
                    {t('cancel')}
                  </button>
                  <button
                    onClick={handleDone}
                    disabled={!transcript.trim()}
                    className="flex-1 flex items-center justify-center gap-2 py-4 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold disabled:opacity-40 min-h-[56px]"
                  >
                    <Check className="w-6 h-6" strokeWidth={2.5} />
                    {t('voiceConfirm')}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}