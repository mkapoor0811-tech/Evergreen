import React from 'react';

/** Every screen opens the same way: a large title, then one short line saying
 *  what the screen is for. */
export default function PageHeader({ title, description }) {
  return (
    <div className="mb-6">
      <h1 className="text-4xl text-foreground leading-tight">{title}</h1>
      {description && <p className="text-lg text-muted-foreground mt-2 leading-snug">{description}</p>}
    </div>
  );
}