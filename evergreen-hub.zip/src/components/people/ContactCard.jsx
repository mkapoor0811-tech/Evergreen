import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Phone, Pencil, Trash2 } from 'lucide-react';

const INPUT = 'w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-lg min-h-[56px]';
const ACTION = 'flex-1 flex items-center justify-center gap-2 font-bold py-3 rounded-xl border-2 transition min-h-[56px]';

/** One person, with Call, Edit and Remove. Removing always asks first. */
export default function ContactCard({ contact, kind, onSave, onRemove }) {
  const { t } = useAppSettings();
  const isEmergency = kind === 'emergency';
  const [editing, setEditing] = useState(!contact.name);
  const [confirming, setConfirming] = useState(false);
  const [draft, setDraft] = useState({
    name: contact.name || '',
    phone: contact.phone || '',
    email: contact.email || '',
    relationship: contact.relationship || '',
  });

  const commit = () => {
    onSave({
      name: draft.name.trim(),
      phone: draft.phone.trim(),
      email: isEmergency ? '' : draft.email.trim(),
      relationship: draft.relationship.trim(),
    });
    setEditing(false);
  };

  if (confirming) {
    return (
      <div className="p-4 rounded-2xl border-2 border-destructive/40 bg-destructive/5 space-y-3">
        <p className="font-heading text-xl text-destructive">{t('areYouSure')}</p>
        <div className="flex gap-3">
          <button onClick={onRemove} className={`${ACTION} bg-destructive border-destructive text-white`}>
            {t('removeLabel')}
          </button>
          <button onClick={() => setConfirming(false)} className={`${ACTION} bg-card border-border text-foreground`}>
            {t('cancel')}
          </button>
        </div>
      </div>
    );
  }

  if (editing) {
    return (
      <div className="p-4 rounded-2xl border-2 border-earth-lagoon bg-card space-y-3">
        <input
          className={INPUT}
          value={draft.name}
          onChange={(e) => setDraft({ ...draft, name: e.target.value })}
          placeholder={t('contactName')}
        />
        <input
          className={INPUT}
          type="tel"
          value={draft.phone}
          onChange={(e) => setDraft({ ...draft, phone: e.target.value })}
          placeholder={t('contactPhone')}
        />
        {!isEmergency && (
          <input
            className={INPUT}
            type="email"
            value={draft.email}
            onChange={(e) => setDraft({ ...draft, email: e.target.value })}
            placeholder={t('contactEmail')}
          />
        )}
        <input
          className={INPUT}
          value={draft.relationship}
          onChange={(e) => setDraft({ ...draft, relationship: e.target.value })}
          placeholder={t('relationshipLabel')}
        />
        <div className="flex gap-3">
          <button
            onClick={commit}
            disabled={!draft.name.trim()}
            className={`${ACTION} bg-earth-lagoon border-earth-lagoon text-white disabled:opacity-50`}
          >
            {t('save')}
          </button>
          <button
            onClick={() => (contact.name ? setEditing(false) : onRemove())}
            className={`${ACTION} bg-card border-border text-foreground`}
          >
            {t('cancel')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 rounded-2xl border-2 border-border bg-card">
      <p className="font-bold text-xl text-foreground">{contact.name}</p>
      {contact.relationship && <p className="text-lg text-muted-foreground">{contact.relationship}</p>}
      {contact.phone && <p className="text-lg text-muted-foreground">{contact.phone}</p>}
      {contact.email && <p className="text-lg text-muted-foreground truncate">{contact.email}</p>}

      <div className={`grid gap-2 mt-4 ${isEmergency && contact.phone ? 'grid-cols-3' : 'grid-cols-2'}`}>
        {isEmergency && contact.phone && (
          <a
            href={`tel:${contact.phone.replace(/[^\d+]/g, '')}`}
            className={`${ACTION} bg-earth-lagoon border-earth-lagoon text-white`}
          >
            <Phone className="w-5 h-5" strokeWidth={2.5} />
            {t('callLabel')}
          </a>
        )}
        <button onClick={() => setEditing(true)} className={`${ACTION} bg-card border-border text-foreground`}>
          <Pencil className="w-5 h-5" strokeWidth={2.5} />
          {t('edit')}
        </button>
        <button onClick={() => setConfirming(true)} className={`${ACTION} bg-card border-border text-earth-terracotta`}>
          <Trash2 className="w-5 h-5" strokeWidth={2.5} />
          {t('removeLabel')}
        </button>
      </div>
    </div>
  );
}