import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import ContactCard from '@/components/people/ContactCard';
import { UserPlus } from 'lucide-react';

/** One simple contact list with a large "add" button. Used on My people and in Settings. */
export default function ContactList({ title, contacts, onChange, kind, addLabel }) {
  const { t } = useAppSettings();
  const list = contacts || [];

  const update = (idx, contact) => onChange(list.map((c, i) => (i === idx ? contact : c)));
  const remove = (idx) => onChange(list.filter((_, i) => i !== idx));
  const add = () => onChange([...list, { name: '', phone: '', email: '', relationship: '' }]);

  return (
    <div className="space-y-3">
      {title && <h2 className="font-heading text-2xl text-foreground">{title}</h2>}

      {list.map((contact, idx) => (
        <ContactCard
          key={idx}
          contact={contact}
          kind={kind}
          onSave={(value) => update(idx, value)}
          onRemove={() => remove(idx)}
        />
      ))}

      <button
        onClick={add}
        className="w-full flex items-center justify-center gap-2 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-4 rounded-2xl transition min-h-[56px]"
      >
        <UserPlus className="w-6 h-6" strokeWidth={2.5} />
        {addLabel || t('addContact')}
      </button>
    </div>
  );
}