import React, { useCallback, useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { sendToCaregivers } from '@/lib/caregiverAlerts';
import { getLocationIfAllowed } from '@/lib/emergency';
import { Users, Check, Loader2, MapPin, X, AlertTriangle } from 'lucide-react';

const COUNTDOWN_FROM = 5;

/**
 * "Tell my family": counts down five seconds with a big Cancel button,
 * then records an in-app alert and emails every linked caregiver.
 */
export default function TellFamilyButton({ allowLocation }) {
  const { t } = useAppSettings();
  const [counting, setCounting] = useState(false);
  const [count, setCount] = useState(COUNTDOWN_FROM);
  const [state, setState] = useState('idle');
  const [sentAt, setSentAt] = useState(null);
  const [locationLink, setLocationLink] = useState(null);

  const doSend = useCallback(async () => {
    setState('sending');
    const link = await getLocationIfAllowed(allowLocation);
    const time = new Date().toISOString();
    const timeLabel = new Date(time).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

    await base44.entities.EmergencyAlert.create({
      message: t('emergencyAlertIntro'),
      alert_time: time,
      location_link: link || '',
    });

    const lines = [`${t('emergencySentAt').replace('{time}', timeLabel)}`];
    if (link) lines.push(`<a href="${link}">${t('emergencyLocationShared')}</a>`);

    await sendToCaregivers({
      subject: t('emergencyAlertSubject'),
      heading: t('emergencyAlertHeading'),
      intro: t('emergencyAlertIntro'),
      lines,
      footer: t('emergencyAlertFooter'),
    }).catch(() => {});

    setSentAt(timeLabel);
    setLocationLink(link);
    setState('sent');
  }, [allowLocation, t]);

  useEffect(() => {
    if (!counting) return undefined;
    if (count <= 0) {
      setCounting(false);
      doSend();
      return undefined;
    }
    const timer = setTimeout(() => setCount((c) => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [counting, count, doSend]);

  if (state === 'sent') {
    return (
      <div className="p-6 rounded-2xl bg-earth-sage/15 border-2 border-earth-sage">
        <p className="flex items-center gap-3 text-2xl font-bold text-earth-sageDark">
          <Check className="w-8 h-8 shrink-0" strokeWidth={3} />
          {t('emergencySent')}
        </p>
        {sentAt && (
          <p className="mt-3 text-xl text-foreground">
            {t('emergencySentAt').replace('{time}', sentAt)}
          </p>
        )}
        <p className="mt-3 flex items-center gap-2 text-lg text-muted-foreground">
          <MapPin className="w-6 h-6 shrink-0" />
          {locationLink ? t('emergencyLocationShared') : t('emergencyLocationOff')}
        </p>
      </div>
    );
  }

  if (counting) {
    return (
      <div className="p-6 rounded-2xl bg-destructive border-4 border-destructive text-center">
        <p className="text-3xl font-heading text-white mb-2">
          {t('emergencySending').replace('{n}', String(count))}
        </p>
        <p className="text-6xl font-bold text-white mb-5">{count}</p>
        <button
          onClick={() => { setCounting(false); setCount(COUNTDOWN_FROM); }}
          className="w-full flex items-center justify-center gap-3 bg-white text-destructive font-bold py-6 rounded-2xl text-2xl transition min-h-[80px]"
        >
          <X className="w-9 h-9" strokeWidth={3} />
          {t('emergencyCancelSend')}
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={() => { setCount(COUNTDOWN_FROM); setCounting(true); }}
      disabled={state === 'sending'}
      className="w-full flex items-center justify-center gap-3 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-6 rounded-2xl text-2xl transition min-h-[84px] disabled:opacity-50"
    >
      {state === 'sending' ? <Loader2 className="w-8 h-8 animate-spin" /> : <Users className="w-8 h-8" strokeWidth={2.5} />}
      {t('emergencyTellFamily')}
    </button>
  );
}