import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { telHref } from '@/lib/emergency';
import { LOCALES, formatTime12 } from '@/lib/timeFormat';
import { PhoneCall, Pill, Users, FileText, Plus, Loader2 } from 'lucide-react';

const INPUT = 'w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-navy outline-none text-lg min-h-[56px]';

/** Medicines, allergies, doctor and contacts — in very large, high-contrast text. */
export default function EmergencyProfileDetails({ setting, meds = [], showHealthSummary = false }) {
  const { t, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';

  const caregiverPhone = setting?.caregiver_phone || localStorage.getItem('mahika_caregiver_phone') || '';
  const contacts = (setting?.secondary_contacts || []).filter((c) => c && c.name);

  // Allergies and doctor can be filled in right here, without leaving the page.
  const [saved, setSaved] = useState({});
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(null);
  const [draft, setDraft] = useState({ allergies: '', doctor_name: '', doctor_phone: '' });

  const allergies = saved.allergies ?? setting?.allergies ?? '';
  const doctorName = saved.doctor_name ?? setting?.doctor_name ?? '';
  const doctorPhone = saved.doctor_phone ?? setting?.doctor_phone ?? '';

  const startEdit = (field) => {
    setDraft({ allergies, doctor_name: doctorName, doctor_phone: doctorPhone });
    setEditing(field);
  };

  const save = async (patch) => {
    setSaving(true);
    try {
      const existing = setting?.id ? setting : (await base44.entities.CaregiverSetting.list())[0];
      if (existing?.id) await base44.entities.CaregiverSetting.update(existing.id, patch);
      else await base44.entities.CaregiverSetting.create(patch);
      setSaved((prev) => ({ ...prev, ...patch }));
      setEditing(null);
    } finally {
      setSaving(false);
    }
  };

  const band = 'inline-block rounded-xl px-5 py-2 mb-4 shadow-sm';

  return (
    <div>
      {/* Family contact */}
      <section className="mb-8">
        <div className={`${band} bg-earth-terracotta`}>
          <h2 className="font-heading text-2xl text-white">{t('emergencyProfileCaregiver')}</h2>
        </div>
        {caregiverPhone ? (
          <a
            href={telHref(caregiverPhone)}
            className="flex items-center gap-4 rounded-2xl bg-earth-terracotta hover:bg-earth-terracottaDark p-5 transition min-h-[88px]"
          >
            <span className="w-14 h-14 blob bg-white/25 flex items-center justify-center shrink-0">
              <PhoneCall className="w-8 h-8 text-white" strokeWidth={2.5} />
            </span>
            <span>
              <span className="block font-heading text-2xl text-white">{t('callFamily')}</span>
              <span className="block text-white/90 text-xl">{caregiverPhone}</span>
            </span>
          </a>
        ) : (
          <Link to="/settings" className="block rounded-2xl border-2 border-dashed border-earth-terracotta p-5 bg-card">
            <p className="text-xl text-foreground font-semibold">{t('emergencyProfileNoContacts')}</p>
          </Link>
        )}
      </section>

      {/* Allergies */}
      <section className="mb-8">
        <div className={`${band} bg-earth-marigold`}>
          <h2 className="font-heading text-2xl text-white">{t('emergencyProfileAllergies')}</h2>
        </div>
        {allergies && <p className="text-3xl font-bold text-foreground leading-snug mb-3">{allergies}</p>}
        {!allergies && editing !== 'allergies' && (
          <p className="text-xl text-muted-foreground mb-3">{t('emergencyProfileNoAllergies')}</p>
        )}

        {editing === 'allergies' ? (
          <div className="space-y-3">
            <input
              className={INPUT}
              value={draft.allergies}
              onChange={(e) => setDraft({ ...draft, allergies: e.target.value })}
              placeholder={t('emergencyProfileAllergies')}
            />
            <div className="flex gap-3">
              <button
                onClick={() => save({ allergies: draft.allergies.trim() })}
                disabled={saving}
                className="flex-1 flex items-center justify-center gap-2 bg-earth-marigold text-white font-bold py-4 rounded-xl transition min-h-[56px] disabled:opacity-60"
              >
                {saving && <Loader2 className="w-6 h-6 animate-spin" />}
                {t('save')}
              </button>
              <button
                onClick={() => setEditing(null)}
                className="flex-1 bg-card border-2 border-border text-foreground font-bold py-4 rounded-xl transition min-h-[56px]"
              >
                {t('cancel')}
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => startEdit('allergies')}
            className="flex items-center justify-center gap-2 bg-earth-marigold/15 border-2 border-earth-marigold text-earth-marigoldDark font-bold px-6 py-4 rounded-xl transition min-h-[56px]"
          >
            <Plus className="w-6 h-6" strokeWidth={2.5} />
            {allergies ? t('edit') : t('add')}
          </button>
        )}
      </section>

      {/* Doctor */}
      <section className="mb-8">
        <div className={`${band} bg-earth-navy`}>
          <h2 className="font-heading text-2xl text-white">{t('emergencyProfileDoctor')}</h2>
        </div>
        {doctorName && editing !== 'doctor' && (
          <div className="rounded-2xl bg-card border-2 border-border p-5">
            <p className="font-heading text-3xl text-foreground leading-tight">{doctorName}</p>
            {doctorPhone ? (
              <a
                href={telHref(doctorPhone)}
                className="mt-4 flex items-center justify-center gap-3 rounded-xl bg-earth-navy hover:bg-earth-navyDark text-white font-bold py-4 transition min-h-[64px] text-xl"
              >
                <PhoneCall className="w-7 h-7" strokeWidth={2.5} />
                {doctorPhone}
              </a>
            ) : null}
          </div>
        )}

        {!doctorName && editing !== 'doctor' && (
          <p className="text-xl text-muted-foreground mb-3">{t('emergencyProfileNoDoctor')}</p>
        )}

        {editing === 'doctor' ? (
          <div className="space-y-3">
            <input
              className={INPUT}
              value={draft.doctor_name}
              onChange={(e) => setDraft({ ...draft, doctor_name: e.target.value })}
              placeholder={t('doctorName')}
            />
            <input
              className={INPUT}
              type="tel"
              value={draft.doctor_phone}
              onChange={(e) => setDraft({ ...draft, doctor_phone: e.target.value })}
              placeholder={t('doctorPhone')}
            />
            <div className="flex gap-3">
              <button
                onClick={() => save({ doctor_name: draft.doctor_name.trim(), doctor_phone: draft.doctor_phone.trim() })}
                disabled={saving}
                className="flex-1 flex items-center justify-center gap-2 bg-earth-navy text-white font-bold py-4 rounded-xl transition min-h-[56px] disabled:opacity-60"
              >
                {saving && <Loader2 className="w-6 h-6 animate-spin" />}
                {t('save')}
              </button>
              <button
                onClick={() => setEditing(null)}
                className="flex-1 bg-card border-2 border-border text-foreground font-bold py-4 rounded-xl transition min-h-[56px]"
              >
                {t('cancel')}
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => startEdit('doctor')}
            className="mt-3 flex items-center justify-center gap-2 bg-earth-navy/10 border-2 border-earth-navy text-earth-navy font-bold px-6 py-4 rounded-xl transition min-h-[56px]"
          >
            <Plus className="w-6 h-6" strokeWidth={2.5} />
            {doctorName ? t('edit') : t('add')}
          </button>
        )}
      </section>

      {/* Other trusted people */}
      {contacts.length > 0 && (
        <section className="mb-8">
          <div className={`${band} bg-earth-lagoon`}>
            <h2 className="font-heading text-2xl text-white">{t('emergencyProfileTrusted')}</h2>
          </div>
          <div className="space-y-3">
            {contacts.map((c, i) => (
              <div key={`${c.name}-${i}`} className="flex items-center gap-4 rounded-2xl bg-card border-2 border-border p-4">
                <span className="w-12 h-12 blob-alt bg-earth-lagoon/12 text-earth-lagoon flex items-center justify-center shrink-0">
                  <Users className="w-6 h-6" strokeWidth={2.25} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="font-heading text-2xl text-foreground leading-tight">{c.name}</p>
                  {c.phone && <p className="text-lg text-muted-foreground">{c.phone}</p>}
                  {c.email && <p className="text-lg text-muted-foreground truncate">{c.email}</p>}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Medicines */}
      <section className="mb-8">
        <div className={`${band} bg-earth-plum`}>
          <h2 className="font-heading text-2xl text-white">{t('emergencyProfileMeds')}</h2>
        </div>
        {meds.length === 0 ? (
          <p className="text-xl text-muted-foreground">{t('emergencyProfileNoMeds')}</p>
        ) : (
          <ul className="space-y-3">
            {meds.map((m) => (
              <li key={m.id} className="flex items-start gap-4 rounded-2xl bg-card border-2 border-border p-4">
                <span className="w-12 h-12 blob bg-earth-plum/12 text-earth-plum flex items-center justify-center shrink-0">
                  <Pill className="w-6 h-6" strokeWidth={2.25} />
                </span>
                <div className="min-w-0">
                  <p className="font-heading text-2xl text-foreground leading-tight">
                    {m.name} {m.dosage ? <span className="text-muted-foreground">· {m.dosage}</span> : null}
                  </p>
                  <p className="text-lg text-muted-foreground">
                    {formatTime12(m.time, locale)}{m.doctor_name ? ` · ${t('prescribingDoctor')}: ${m.doctor_name}` : ''}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {showHealthSummary && (
        <Link
          to="/health-summary"
          className="flex items-center gap-4 rounded-2xl bg-card border-2 border-border p-5 hover:shadow-md transition"
        >
          <span className="w-12 h-12 blob-alt bg-earth-navy/12 text-earth-navy flex items-center justify-center shrink-0">
            <FileText className="w-6 h-6" strokeWidth={2.25} />
          </span>
          <span className="flex-1">
            <span className="block font-heading text-xl text-foreground leading-tight">{t('healthSummary')}</span>
            <span className="block text-muted-foreground">{t('healthSummaryCardDesc')}</span>
          </span>
        </Link>
      )}
    </div>
  );
}