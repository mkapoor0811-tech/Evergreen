import React, { useEffect, useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { loadEmergencyConfig, getEmergencyNumber, getEmergencyContacts, telHref } from '@/lib/emergency';
import TellFamilyButton from '@/components/emergency/TellFamilyButton';
import { PhoneCall, Phone } from 'lucide-react';

/** The calm full-screen confirmation shown before anything is dialled or sent. */
export default function EmergencyConfirm({ onClose }) {
  const { t } = useAppSettings();
  const [config, setConfig] = useState(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    loadEmergencyConfig().then(setConfig).finally(() => setLoaded(true));
  }, []);

  const emergencyNumber = getEmergencyNumber(config);
  const contacts = getEmergencyContacts(config);

  return (
    <div className="fixed inset-0 z-[60] bg-background overflow-y-auto">
      <div className="max-w-3xl mx-auto w-full px-4 pt-6 pb-24">
        <h1 className="font-heading text-3xl text-foreground mb-6">{t('emergencyConfirmTitle')}</h1>

        <a
          href={telHref(emergencyNumber)}
          className="w-full flex items-center justify-center gap-3 bg-destructive hover:bg-destructive/90 text-white font-bold py-6 rounded-2xl text-2xl transition min-h-[80px] mb-4"
        >
          <PhoneCall className="w-9 h-9" strokeWidth={2.5} />
          {t('emergencyYesCall')}
        </a>

        <button
          onClick={onClose}
          className="w-full flex items-center justify-center gap-3 border-2 border-border bg-card hover:bg-secondary text-foreground font-bold py-6 rounded-2xl text-2xl transition min-h-[80px]"
        >
          {t('cancel')}
        </button>

        <p className="mt-5 mb-8 text-xl text-muted-foreground leading-snug">{t('emergencyConfirmNote')}</p>

        {contacts.length > 0 && (
          <>
            <h2 className="font-heading text-2xl text-foreground mb-4">{t('callMyFamily')}</h2>
            {contacts.map((c) => (
              <a
                key={c.key}
                href={telHref(c.phone)}
                className="w-full flex items-center justify-center gap-3 bg-earth-navy hover:bg-earth-navyDark text-white font-bold py-5 rounded-2xl text-xl transition min-h-[64px] mb-4"
              >
                <Phone className="w-7 h-7" strokeWidth={2.5} />
                {c.name ? `${t('emergencyCallName')} ${c.name}` : t('callMyFamily')}
              </a>
            ))}
          </>
        )}

        {loaded && contacts.length === 0 && (
          <p className="mb-6 p-5 rounded-2xl border-2 border-dashed border-earth-navy bg-card text-xl font-semibold text-foreground">
            {t('emergencyNoContacts')}
          </p>
        )}

        <TellFamilyButton allowLocation={!!config?.allow_location} />
        <p className="mt-2 text-lg text-muted-foreground">{t('emergencyTellFamilyHelp')}</p>
      </div>
    </div>
  );
}