import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAppSettings } from '@/lib/AppSettings';
import { AlertTriangle, Phone } from 'lucide-react';
import EmergencyConfirm from '@/components/emergency/EmergencyConfirm';

/**
 * The always-visible red Emergency button.
 * "header" is the small pill in the top bar; "page" is the medium button on the Today screen,
 * which opens a calm full-screen confirmation before anything happens.
 */
export default function EmergencyButton({ variant = 'header' }) {
  const { t } = useAppSettings();
  const [open, setOpen] = useState(false);

  if (variant === 'page') {
    return (
      <>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="w-full flex items-center justify-center gap-3 bg-destructive hover:bg-destructive/90 text-white font-bold rounded-2xl text-xl transition min-h-[64px] mb-8"
        >
          <Phone className="w-6 h-6" strokeWidth={2.5} />
          {t('emergency')}
        </button>
        {open && <EmergencyConfirm onClose={() => setOpen(false)} />}
      </>
    );
  }

  return (
    <Link
      to="/emergency"
      className="shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-destructive hover:bg-destructive/90 text-white font-bold transition min-h-[56px]"
    >
      <AlertTriangle className="w-6 h-6" strokeWidth={2.75} />
      <span className="hidden sm:inline">{t('emergency')}</span>
    </Link>
  );
}