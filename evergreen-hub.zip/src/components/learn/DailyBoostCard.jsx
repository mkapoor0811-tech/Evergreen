import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { readCustomTips, todayTip } from '@/lib/gardenTips';
import AppCard from '@/components/AppCard';
import { Sparkles } from 'lucide-react';

/** The one Daily Boost card, showing today's tip. */
export default function DailyBoostCard() {
  const { t, language } = useAppSettings();
  const tip = todayTip(language, readCustomTips());

  return (
    <AppCard
      to="/daily-boost"
      icon={Sparkles}
      title={t('dailyBoost')}
      description={`${t('todayTip')}: ${tip}`}
      tone="plum"
      variant="tall"
    />
  );
}