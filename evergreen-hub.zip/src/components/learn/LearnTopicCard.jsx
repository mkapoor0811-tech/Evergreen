import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import ReadAloudButton from '@/components/ReadAloudButton';
import ExternalLinkDialog from '@/components/learn/ExternalLinkDialog';
import { Bookmark, BookmarkCheck, ExternalLink, Info } from 'lucide-react';

export default function LearnTopicCard({ topic, saved, onToggleSave }) {
  const { t, language } = useAppSettings();
  const [showLinkDialog, setShowLinkDialog] = useState(false);

  const text = topic.text[language] || topic.text.en;
  const hasSource = Boolean(topic.source && topic.source.url);

  return (
    <article className="rounded-3xl bg-card border-2 border-border overflow-hidden mb-5">
      <div className="p-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <h3 className="font-heading text-2xl text-foreground">{text.title}</h3>
          <button
            onClick={() => onToggleSave(topic.id)}
            aria-label={t('learnSave')}
            className={`shrink-0 flex items-center gap-2 px-3 py-2 rounded-xl border-2 font-bold transition min-h-[56px] ${
              saved
                ? 'bg-earth-marigold/20 border-earth-marigold text-earth-marigoldDark'
                : 'bg-secondary border-border text-muted-foreground hover:border-earth-marigold'
            }`}
          >
            {saved ? <BookmarkCheck className="w-6 h-6" strokeWidth={2.5} /> : <Bookmark className="w-6 h-6" strokeWidth={2.5} />}
            <span className="hidden sm:inline">{saved ? t('learnSaved') : t('learnSave')}</span>
          </button>
        </div>

        <p className="text-foreground text-lg leading-relaxed mb-4">{text.summary}</p>

        <ReadAloudButton text={`${text.title}. ${text.summary}`} />

        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-muted-foreground mb-4">
          {topic.source.name && (
            <span>
              <span className="font-bold">{t('learnSource')}: </span>
              {topic.source.name}
            </span>
          )}
          <span className="flex items-center gap-2">
            <Info className="w-5 h-5" strokeWidth={2.5} />
            {t('learnGeneralInfo')}
          </span>
        </div>

        {hasSource && (
          <button
            onClick={() => setShowLinkDialog(true)}
            className="w-full flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-earth-navy hover:bg-earth-navyDark text-white font-bold transition min-h-[56px]"
          >
            <ExternalLink className="w-6 h-6" strokeWidth={2.5} />
            {t('learnReadMore')}
          </button>
        )}
      </div>

      <ExternalLinkDialog
        open={showLinkDialog}
        source={topic.source.name}
        url={topic.source.url}
        onClose={() => setShowLinkDialog(false)}
      />
    </article>
  );
}