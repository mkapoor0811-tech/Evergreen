import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { ExternalLink } from 'lucide-react';

export default function ExternalLinkDialog({ open, source, url, onClose }) {
  const { t } = useAppSettings();

  const openLink = () => {
    if (url) window.open(url, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(next) => !next && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading text-2xl">{t('externalLinkTitle')}</DialogTitle>
          <DialogDescription className="text-foreground text-lg">
            {t('externalLinkMessage')}
          </DialogDescription>
        </DialogHeader>

        {source && (
          <p className="text-muted-foreground font-semibold">
            {t('externalLinkSource').replace('{source}', source)}
          </p>
        )}

        <div className="flex flex-col sm:flex-row gap-3 mt-2">
          <button
            onClick={openLink}
            className="flex-1 flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-earth-navy hover:bg-earth-navyDark text-white font-bold transition min-h-[56px]"
          >
            <ExternalLink className="w-6 h-6" strokeWidth={2.5} />
            {t('externalLinkContinue')}
          </button>
          <button
            onClick={onClose}
            className="flex-1 px-5 py-4 rounded-2xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
          >
            {t('cancel')}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}