import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Heart, PhoneCall } from 'lucide-react';
import { localDate } from '@/lib/localDate';

function getLast3Days() {
  const days = [];
  for (let i = 0; i < 3; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(localDate(d));
  }
  return days;
}

export default function SupportSuggestion({ checkIns, exercises, dietLogs }) {
  const { t } = useAppSettings();
  const last3 = getLast3Days();
  const last3Set = new Set(last3);

  // Only show if the user was active at some point before the last 3 days,
  // so we detect "reduced" activity rather than a brand-new account.
  const hadPriorActivity =
    checkIns.some((c) => c.checked_in && !last3Set.has(c.date)) ||
    exercises.some((ex) => (Array.isArray(ex.done_dates) ? ex.done_dates : []).some((d) => !last3Set.has(d))) ||
    dietLogs.some((log) => !last3Set.has(log.date));

  if (!hadPriorActivity) return null;

  // Signal 1: Missed check-ins on 2+ of the last 3 days
  const missedCheckIns = last3.filter((date) => {
    const ci = checkIns.find((c) => c.date === date);
    return !ci || !ci.checked_in;
  }).length;
  const checkInSignal = missedCheckIns >= 2;

  // Signal 2: No exercises completed in the last 3 days
  const exerciseSignal = !exercises.some((ex) =>
    (Array.isArray(ex.done_dates) ? ex.done_dates : []).some((d) => last3Set.has(d))
  );

  // Signal 3: No diet log entries in the last 3 days
  const dietSignal = !dietLogs.some((log) => last3Set.has(log.date));

  const signalCount = [checkInSignal, exerciseSignal, dietSignal].filter(Boolean).length;
  if (signalCount < 2) return null;

  return (
    <div className="p-5 rounded-2xl border-2 mb-5 bg-rose-50 border-rose-200">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-rose-400 flex items-center justify-center shrink-0">
          <Heart className="w-7 h-7 text-white" strokeWidth={2.5} />
        </div>
        <div className="flex-1">
          <h2 className="text-lg font-bold text-rose-900 mb-1">{t('thinkingOfYou')}</h2>
          <p className="text-slate-700 leading-relaxed">{t('supportSuggestedMsg')}</p>
          <p className="text-slate-600 font-semibold mt-3 flex items-center gap-2">
            <PhoneCall className="w-5 h-5 text-rose-500" />
            {t('supportSuggestedAction')}
          </p>
        </div>
      </div>
    </div>
  );
}