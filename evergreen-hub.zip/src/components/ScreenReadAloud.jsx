import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Volume2, Square } from 'lucide-react';
import { useAppSettings, speechLocale } from '@/lib/AppSettings';

/** Reads the current screen out loud. Sits in the header on every screen. */
export default function ScreenReadAloud() {
  const { t, language } = useAppSettings();
  const location = useLocation();
  const [speaking, setSpeaking] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) window.speechSynthesis.cancel();
    setSpeaking(false);
  }, [location.pathname]);

  const handleClick = () => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const main = document.querySelector('main');
    const text = (main?.innerText || '').replace(/\s+/g, ' ').trim();
    if (!text) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = speechLocale(language);
    utterance.rate = 0.9;
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={speaking ? t('stopReading') : t('readAloud')}
      className={`shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition min-h-[56px] ${
        speaking ? 'bg-earth-lagoon text-white' : 'bg-secondary hover:bg-muted text-foreground'
      }`}
    >
      {speaking ? <Square className="w-6 h-6" strokeWidth={2.5} /> : <Volume2 className="w-6 h-6" strokeWidth={2.5} />}
      <span className="hidden sm:inline">{speaking ? t('stopReading') : t('readAloud')}</span>
    </button>
  );
}