import React from 'react';

/**
 * One panel on a hub screen: a coloured header bar carrying the section name in
 * white, with the section's rows stacked below it. The same panel the Learn tab
 * uses, so every hub reads the same way.
 */
export default function HubSection({ title, hex, children }) {
  return (
    <section className="mb-5 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <div className="px-5 py-3" style={{ backgroundColor: hex }}>
        <h2 className="font-heading text-xl text-white leading-tight">{title}</h2>
      </div>
      <div className="p-4 space-y-3">{children}</div>
    </section>
  );
}