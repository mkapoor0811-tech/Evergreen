import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

/**
 * One row on a hub screen: a thick colour bar down its left edge, the icon in
 * that same colour on a pale disc, the name in bold, one short line about it,
 * and an arrow. The row stays light so the words are dark and easy to read.
 *
 * The name is drawn in the body sans-serif, the same face as the line under it.
 */
export default function HubRow({ to, icon: Icon, title, description, hex }) {
  return (
    <Link
      to={to}
      className="flex items-stretch gap-4 min-h-[90px] rounded-2xl bg-card border-2 border-border pr-4 overflow-hidden hover:shadow-md transition"
    >
      <span className="w-[8px] shrink-0" style={{ backgroundColor: hex }} />
      <span
        className="w-[56px] h-[56px] self-center rounded-full flex items-center justify-center shrink-0"
        style={{ backgroundColor: `${hex}1F`, color: hex }}
      >
        <Icon className="w-[28px] h-[28px]" strokeWidth={2.25} />
      </span>
      <span className="flex-1 min-w-0 py-3 self-center">
        <span className="block font-body text-xl font-bold text-foreground leading-tight break-words">{title}</span>
        {description && <span className="block text-base text-muted-foreground leading-snug mt-0.5 break-words">{description}</span>}
      </span>
      <ArrowRight className="w-6 h-6 text-muted-foreground shrink-0 self-center" strokeWidth={2.5} />
    </Link>
  );
}