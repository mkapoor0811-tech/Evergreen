import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { useDietaryNeeds } from '@/lib/nutrition/useDietaryNeeds';
import { Heart, Info, Check } from 'lucide-react';

const RECOMMENDATIONS = {
  en: {
    diabetic: {
      label: 'Diabetic-friendly',
      enjoy: ['Whole grains (oats, brown rice)', 'Leafy green vegetables', 'Beans and lentils', 'Fatty fish (salmon, sardines)', 'Nuts and seeds', 'Berries and apples', 'Plain yogurt', 'Avocado'],
      limit: ['Sugary drinks and sodas', 'White bread and white rice', 'Pastries and sweets', 'Sweetened cereals', 'Fruit juice with added sugar'],
    },
    lowSodium: {
      label: 'Low-sodium / Blood pressure',
      enjoy: ['Fresh fruits and vegetables', 'Herbs and spices (instead of salt)', 'Lean poultry and fish', 'Whole grains', 'Dried beans (cooked without salt)', 'Unsalted nuts', 'Potatoes and sweet potatoes'],
      limit: ['Canned soups and frozen meals', 'Processed meats (bacon, deli meats)', 'Salty snacks (chips, pretzels)', 'Pickled foods', 'Soy sauce and table salt', 'Restaurant fast food'],
    },
    digestive: {
      label: 'Digestive-friendly (low gas)',
      enjoy: ['Bananas', 'Rice and oatmeal', 'Cooked vegetables (carrots, zucchini)', 'Lean protein (chicken, fish)', 'Smooth peanut butter', 'Eggs', 'Yogurt with probiotics'],
      limit: ['Beans and lentils (in large amounts)', 'Cabbage, broccoli, and onions', 'Carbonated drinks', 'Dairy (if lactose sensitive)', 'Spicy or very fatty foods'],
    },
    general: {
      label: 'General healthy eating',
      enjoy: ['A colorful variety of fruits and vegetables', 'Whole grains', 'Lean protein (fish, poultry, beans)', 'Low-fat dairy or fortified alternatives', 'Healthy fats (olive oil, nuts)', 'Plenty of water'],
      limit: ['Highly processed foods', 'Excess added sugar', 'Excess salt', 'Fried foods', 'Large amounts of alcohol'],
    },
  },
  es: {
    diabetic: {
      label: 'Para diabéticos',
      enjoy: ['Granos enteros (avena, arroz integral)', 'Vegetales de hojas verdes', 'Frijoles y lentejas', 'Pescado graso (salmón, sardinas)', 'Nueces y semillas', 'Bayas y manzanas', 'Yogur natural', 'Aguacate'],
      limit: ['Bebidas azucaradas y refrescos', 'Pan blanco y arroz blanco', 'Pasteles y dulces', 'Cereales azucarados', 'Jugo de fruta con azúcar añadido'],
    },
    lowSodium: {
      label: 'Bajo en sodio / Presión arterial',
      enjoy: ['Frutas y vegetales frescos', 'Hierbas y especias (en lugar de sal)', 'Pollo y pescado magro', 'Granos enteros', 'Frijoles secos (cocidos sin sal)', 'Nueces sin sal', 'Papas y camotes'],
      limit: ['Sopas enlatadas y comidas congeladas', 'Carnes procesadas (tocino, embutidos)', 'Aperitivos salados (papas, pretzels)', 'Encurtidos', 'Salsa de soya y sal de mesa', 'Comida rápida de restaurante'],
    },
    digestive: {
      label: 'Buena digestión (pocos gases)',
      enjoy: ['Plátanos', 'Arroz y avena', 'Vegetales cocidos (zanahoria, calabacín)', 'Proteína magra (pollo, pescado)', 'Mantequilla de maní suave', 'Huevos', 'Yogur con probióticos'],
      limit: ['Frijoles y lentejas (en grandes cantidades)', 'Repollo, brócoli y cebollas', 'Bebidas carbonatadas', 'Lácteos (si es sensible a la lactosa)', 'Comidas picantes o muy grasosas'],
    },
    general: {
      label: 'Alimentación saludable general',
      enjoy: ['Variedad colorida de frutas y vegetales', 'Granos enteros', 'Proteína magra (pescado, pollo, frijoles)', 'Lácteos bajos en grasa o alternativas fortificadas', 'Grasas saludables (aceite de oliva, nueces)', 'Bastante agua'],
      limit: ['Alimentos ultraprocesados', 'Exceso de azúcar añadido', 'Exceso de sal', 'Alimentos fritos', 'Grandes cantidades de alcohol'],
    },
  },
  hi: {
    diabetic: {
      label: 'मधुमेह-अनुकूल',
      enjoy: ['साबुत अनाज (जई, बासमती चावल)', 'हरी पत्तेदार सब्ज़ियाँ', 'दालें और चने', 'मछली (सामन, सारडिन)', 'नट्स और बीज', 'बेरी और सेब', 'सादा दही', 'एवोकैडो'],
      limit: ['मीठे पेय और सोडा', 'सफ़ेद ब्रेड और सफ़ेद चावल', 'पेस्ट्री और मिठाई', 'मीठे अनाज', 'चीनी मिला फलों का रस'],
    },
    lowSodium: {
      label: 'कम नमक / रक्तचाप',
      enjoy: ['ताज़े फल और सब्ज़ियाँ', 'जड़ी-बूटियाँ (नमक की जगह)', 'दुबला मुर्गा और मछली', 'साबुत अनाज', 'बिना नमक की दालें', 'बिना नमक के नट्स', 'आलू और शकरकंद'],
      limit: ['डिब्बे के सूप और फ़ोज़न भोजन', 'प्रोसेस्ड मीट', 'नमकीन स्नैक्स', 'अचार', 'सोया सॉस और टेबल नमक', 'रेस्टोरेंट फ़ास्ट फूड'],
    },
    digestive: {
      label: 'पाचन-अनुकूल (कम गैस)',
      enjoy: ['केले', 'चावल और जई', 'पकी सब्ज़ियाँ (गाजर, तोरई)', 'दुबला प्रोटीन (मुर्गा, मछली)', 'मूंगफली का मक्खन', 'अंडे', 'प्रोबायोटिक युक्त दही'],
      limit: ['बड़ी मात्रा में दालें', 'गोभी, ब्रोकली और प्याज़', 'कार्बोनेटेड पेय', 'डेयरी (यदि लैक्टोज़ संवेदनशील)', 'मसालेदार या बहुत तैली भोजन'],
    },
    general: {
      label: 'सामान्य स्वस्थ भोजन',
      enjoy: ['रंग-बिरंगे फल और सब्ज़ियाँ', 'साबुत अनाज', 'दुबला प्रोटीन (मछली, मुर्गा, दालें)', 'कम वसा वाली डेयरी', 'स्वस्थ वसा (जैतून का तेल, नट्स)', 'खूब पानी'],
      limit: ['अति-प्रोसेस्ड खाद्य', 'अतिरिक्त चीनी', 'अतिरिक्त नमक', 'तला हुआ भोजन', 'बड़ी मात्रा में शराब'],
    },
  },
  zh: {
    diabetic: {
      label: '适合糖尿病',
      enjoy: ['全谷物（燕麦、糙米）', '绿叶蔬菜', '豆类和扁豆', '鱼类（三文鱼、沙丁鱼）', '坚果和种子', '浆果和苹果', '原味酸奶', '牛油果'],
      limit: ['含糖饮料和汽水', '白面包和白米饭', '糕点和甜食', '加糖谷物', '加糖果汁'],
    },
    lowSodium: {
      label: '低钠 / 血压',
      enjoy: ['新鲜水果和蔬菜', '香草和香料（代替盐）', '瘦肉和鱼', '全谷物', '无盐豆类', '无盐坚果', '土豆和红薯'],
      limit: ['罐头汤和冷冻食品', '加工肉类', '咸味零食', '腌制食品', '酱油和食盐', '快餐'],
    },
    digestive: {
      label: '消化友好（少胀气）',
      enjoy: ['香蕉', '米饭和燕麦', '熟蔬菜（胡萝卜、西葫芦）', '瘦肉蛋白（鸡肉、鱼）', '顺滑花生酱', '鸡蛋', '益生菌酸奶'],
      limit: ['大量豆类', '卷心菜、西兰花和洋葱', '碳酸饮料', '乳制品（如乳糖不耐受）', '辛辣或油腻食物'],
    },
    general: {
      label: '一般健康饮食',
      enjoy: ['五颜六色的水果和蔬菜', '全谷物', '瘦肉蛋白（鱼、鸡、豆类）', '低脂乳制品', '健康脂肪（橄榄油、坚果）', '充足的水'],
      limit: ['高度加工食品', '过量添加糖', '过量盐', '油炸食品', '大量酒精'],
    },
  },
};

const CATEGORIES = [
  { key: 'diabetic', icon: '🩺' },
  { key: 'lowSodium', icon: '❤️' },
  { key: 'digestive', icon: '🌿' },
  { key: 'general', icon: '🥗' },
];

export default function DietRecommendations() {
  const { t, language } = useAppSettings();
  const [selected, setSelected] = useDietaryNeeds();

  const toggleCategory = (key) => {
    setSelected(selected.includes(key) ? selected.filter((k) => k !== key) : [...selected, key]);
  };

  const data = RECOMMENDATIONS[language] || RECOMMENDATIONS.en;

  return (
    <div className="mt-6 p-5 bg-white rounded-2xl border-2 border-slate-200">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-xl bg-teal-100 flex items-center justify-center">
          <Heart className="w-7 h-7 text-teal-600" strokeWidth={2.5} />
        </div>
        <h2 className="text-xl font-bold text-slate-900">{t('dietRecommendations')}</h2>
      </div>

      <p className="text-slate-600 font-semibold mb-3">{t('dietaryNeeds')}</p>
      <div className="grid grid-cols-2 gap-2 mb-5">
        {CATEGORIES.map((cat) => {
          const isActive = selected.includes(cat.key);
          return (
            <button
              key={cat.key}
              onClick={() => toggleCategory(cat.key)}
              className={`flex items-center gap-2 p-3 rounded-xl border-2 font-bold transition min-h-[56px] ${
                isActive ? 'bg-teal-600 border-teal-600 text-white' : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-400'
              }`}
            >
              <span className="text-xl">{cat.icon}</span>
              <span className="text-sm leading-tight text-left">{data[cat.key].label}</span>
            </button>
          );
        })}
      </div>

      {selected.length === 0 ? (
        <p className="text-slate-500 text-center py-4">{t('selectDietaryNeeds')}</p>
      ) : (
        <div className="space-y-4">
          {selected.map((key) => {
            const rec = data[key];
            if (!rec) return null;
            return (
              <div key={key} className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <h3 className="font-bold text-lg text-slate-900 mb-3">{rec.icon} {rec.label}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <p className="font-bold text-green-700 mb-2 flex items-center gap-1">
                      <Check className="w-4 h-4" strokeWidth={3} /> {t('foodsToEnjoy')}
                    </p>
                    <ul className="space-y-1">
                      {rec.enjoy.map((item, i) => (
                        <li key={i} className="text-slate-700 text-sm flex items-start gap-2">
                          <span className="text-green-600 shrink-0">•</span> {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="font-bold text-red-700 mb-2 flex items-center gap-1">
                      <Info className="w-4 h-4" /> {t('foodsToLimit')}
                    </p>
                    <ul className="space-y-1">
                      {rec.limit.map((item, i) => (
                        <li key={i} className="text-slate-700 text-sm flex items-start gap-2">
                          <span className="text-red-500 shrink-0">•</span> {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <p className="mt-5 p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-sm flex items-start gap-2">
        <Info className="w-5 h-5 shrink-0 mt-0.5" />
        <span>{t('dietDisclaimer')}</span>
      </p>
    </div>
  );
}