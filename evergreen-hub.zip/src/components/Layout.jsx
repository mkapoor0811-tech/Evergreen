import React, { useState, useEffect, useRef } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';
import { screenTitleKey } from '@/lib/navConfig';
import { SectionColorProvider, sectionForPath } from '@/lib/sectionColors';
import EvergreenLogo from '@/components/EvergreenLogo';
import HelpButton from '@/components/HelpButton';
import EmergencyButton from '@/components/emergency/EmergencyButton';
import SettingsButton from '@/components/SettingsButton';
import SimpleModePrompt from '@/components/SimpleModePrompt';
import BottomNav from '@/components/BottomNav';
import VoiceModeBar from '@/components/voice/VoiceModeBar';
import ScreenReadAloud from '@/components/ScreenReadAloud';
import UndoBar from '@/components/UndoBar';
import { UndoProvider } from '@/lib/UndoContext';
import { trackStruggle, wasPromptShown, markPromptShown } from '@/lib/struggleTracker';

export default function Layout() {
  const { t, simpleMode, voiceMode, speak, language } = useAppSettings();
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';
  const [showSimplePrompt, setShowSimplePrompt] = useState(false);
  const [voiceOpen, setVoiceOpen] = useState(true);
  const entryTimeRef = useRef(0);
  const clicksRef = useRef([]);

  useEffect(() => {
    const now = Date.now();
    const duration = now - entryTimeRef.current;
    if (duration > 500 && duration < 3000) {
      if (trackStruggle() && !wasPromptShown()) {
        markPromptShown();
        setShowSimplePrompt(true);
      }
    }
    entryTimeRef.current = now;
  }, [location.pathname]);

  useEffect(() => {
    const handler = () => {
      const now = Date.now();
      clicksRef.current = clicksRef.current.filter((ts) => now - ts < 1500);
      clicksRef.current.push(now);
      if (clicksRef.current.length >= 4) {
        clicksRef.current = [];
        if (trackStruggle() && !wasPromptShown()) {
          markPromptShown();
          setShowSimplePrompt(true);
        }
      }
    };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  // Voice mode: read each screen out loud when it opens.
  useEffect(() => {
    if (!voiceMode) return;
    const key = screenTitleKey(location.pathname);
    const title = key ? t(key) : '';
    const timer = setTimeout(() => speak(`${title}. ${t('voiceScreenHint')}`), 600);
    return () => clearTimeout(timer);
  }, [location.pathname, voiceMode, language, speak, t]);

  // Voice mode: open the voice panel as soon as it is switched on.
  useEffect(() => {
    if (voiceMode) setVoiceOpen(true);
  }, [voiceMode]);

  const goBack = () => {
    if (location.key !== 'default') navigate(-1);
    else navigate('/');
  };

  const bottomPad = voiceMode && voiceOpen
    ? (simpleMode ? 'pb-[45rem]' : 'pb-[33rem]')
    : (simpleMode ? 'pb-[21rem]' : 'pb-28');

  return (
    <UndoProvider>
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-50 bg-card border-b-2 border-border shadow-sm">
        {/* Wraps onto a second row when the buttons no longer fit, so the tree
            and the name always lead the first row and no button is ever hidden. */}
        <div className="max-w-3xl mx-auto px-4 py-2.5 flex flex-wrap items-center gap-1.5 sm:gap-2">
          {!isHome && (
            <button
              type="button"
              onClick={goBack}
              aria-label={t('back')}
              className="shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
            >
              <ArrowLeft className="w-6 h-6" strokeWidth={2.5} />
              <span className="hidden sm:inline">{t('back')}</span>
            </button>
          )}
          <span className="flex items-center gap-2 min-w-0 flex-1">
            <EvergreenLogo size={40} className="shrink-0" />
            <span className="font-heading text-[1.6rem] font-bold text-foreground truncate">{t('appName')}</span>
          </span>
          {/* The buttons keep their own row on a phone. */}
          <div className="flex items-center gap-1.5 sm:gap-2 w-full sm:w-auto">
            <ScreenReadAloud />
            <HelpButton />
            <SettingsButton />
            <EmergencyButton />
          </div>
        </div>
      </header>

      <main className={`flex-1 max-w-3xl mx-auto w-full px-4 pt-6 ${bottomPad}`}>
        {/* The screen's section decides the colour of its cards, icons and buttons. */}
        <SectionColorProvider value={sectionForPath(location.pathname)}>
          <Outlet />
        </SectionColorProvider>
      </main>

      {voiceMode && <VoiceModeBar open={voiceOpen} onToggle={() => setVoiceOpen((v) => !v)} simple={simpleMode} />}
      <BottomNav />
      <UndoBar />
      {showSimplePrompt && <SimpleModePrompt />}
    </div>
    </UndoProvider>
  );
}