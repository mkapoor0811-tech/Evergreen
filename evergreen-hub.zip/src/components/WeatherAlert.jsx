import React, { useState, useEffect } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { getWeatherAlert } from '@/lib/weatherAlerts';
import { Sun, Snowflake, CloudLightning } from 'lucide-react';

const ALERT_CONFIG = {
  heat: {
    icon: Sun,
    bg: 'bg-orange-50', border: 'border-orange-300',
    iconBg: 'bg-orange-500', title: 'text-orange-900',
    titleKey: 'weatherHeat', tipKey: 'weatherHeatTip',
  },
  cold: {
    icon: Snowflake,
    bg: 'bg-sky-50', border: 'border-sky-300',
    iconBg: 'bg-sky-500', title: 'text-sky-900',
    titleKey: 'weatherCold', tipKey: 'weatherColdTip',
  },
  storm: {
    icon: CloudLightning,
    bg: 'bg-purple-50', border: 'border-purple-300',
    iconBg: 'bg-purple-500', title: 'text-purple-900',
    titleKey: 'weatherStorm', tipKey: 'weatherStormTip',
  },
};

export default function WeatherAlert() {
  const { t } = useAppSettings();
  const [alert, setAlert] = useState(null);

  useEffect(() => {
    getWeatherAlert().then(setAlert).catch(() => {});
  }, []);

  if (!alert) return null;
  const config = ALERT_CONFIG[alert.type];
  if (!config) return null;
  const Icon = config.icon;

  return (
    <div className={`mb-5 p-4 rounded-2xl border-2 ${config.bg} ${config.border} flex items-center gap-4`}>
      <div className={`w-12 h-12 rounded-xl ${config.iconBg} flex items-center justify-center shrink-0`}>
        <Icon className="w-7 h-7 text-white" strokeWidth={2.5} />
      </div>
      <div>
        <p className={`font-bold text-lg ${config.title}`}>{t(config.titleKey)}</p>
        <p className="text-slate-700">{t(config.tipKey)}</p>
      </div>
    </div>
  );
}