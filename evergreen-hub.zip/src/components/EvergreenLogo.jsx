import React from 'react';

const TREE = '#1F5E5B';
const TRUNK = '#4A3B2B';

/**
 * The Evergreen mark: a flat tree of three rounded triangles on a short trunk.
 * Decorative only — the app name is always written beside it.
 */
export default function EvergreenLogo({ size = 32, className }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      role="presentation"
      aria-hidden="true"
      focusable="false"
      className={className}
    >
      <rect x="27" y="48" width="10" height="12" rx="2" fill={TRUNK} />
      <g fill={TREE} stroke={TREE} strokeWidth="4" strokeLinejoin="round" strokeLinecap="round">
        <path d="M32 6 L45 26 L19 26 Z" />
        <path d="M32 17 L49 40 L15 40 Z" />
        <path d="M32 29 L53 54 L11 54 Z" />
      </g>
    </svg>
  );
}