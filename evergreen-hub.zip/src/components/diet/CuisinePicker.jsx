import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { useCuisines } from '@/lib/nutrition/useDietaryNeeds';
import { CUISINES } from '@/lib/nutrition/mealData';
import { Utensils } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

const LABEL_KEY = {
  american: 'cuisineAmerican',
  mediterranean: 'cuisineMediterranean',
  indian: 'cuisineIndian',
  chinese: 'cuisineChinese',
  mexican: 'cuisineMexican',
};

const ICON = { american: '🍲', mediterranean: '🫒', indian: '🍛', chinese: '🥢', mexican: '🌮' };

export default function CuisinePicker() {
  const { t } = useAppSettings();
  const look = useSectionLook();
  const [cuisines, setCuisines] = useCuisines();

  const toggle = (key) =>
    setCuisines(cuisines.includes(key) ? cuisines.filter((c) => c !== key) : [...cuisines, key]);

  return (
    <div className="mb-6 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <div className={`${look.bar} px-5 py-3 flex items-center gap-3`}>
        <Utensils className="w-6 h-6 text-white" strokeWidth={2.5} />
        <h2 className="font-heading text-xl text-white">{t('cuisinesTitle')}</h2>
      </div>
      <div className="p-5">
        <p className="text-muted-foreground mb-4">{t('cuisinesHelp')}</p>
        <div className="flex flex-wrap gap-2">
          {CUISINES.map((key) => {
            const active = cuisines.includes(key);
            return (
              <button
                key={key}
                onClick={() => toggle(key)}
                className={`flex items-center gap-2 px-4 py-3 rounded-2xl border-2 font-bold transition min-h-[56px] ${
                  active
                    ? 'bg-earth-plum border-earth-plum text-white'
                    : 'bg-secondary border-border text-foreground hover:border-earth-plum'
                }`}
              >
                <span className="text-xl">{ICON[key]}</span>
                {t(LABEL_KEY[key])}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}