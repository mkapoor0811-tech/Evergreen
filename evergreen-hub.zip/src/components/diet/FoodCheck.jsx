import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { useDietaryNeeds } from '@/lib/nutrition/useDietaryNeeds';
import { checkFood, SWAPS } from '@/lib/nutrition/foodCheck';
import { Search, Check, AlertTriangle, XCircle, Lightbulb, HelpCircle, ChevronDown } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

const NEED_LABEL = {
  diabetic: 'needDiabetic',
  lowSodium: 'needLowSodium',
  digestive: 'needDigestive',
  general: 'needGeneral',
};

const VERDICT = {
  green: { icon: Check, tone: 'bg-earth-sage/15 border-earth-sage text-earth-sageDark', titleKey: 'foodCheckGreen' },
  yellow: { icon: AlertTriangle, tone: 'bg-earth-marigold/20 border-earth-marigold text-earth-marigoldDark', titleKey: 'foodCheckYellow' },
  red: { icon: XCircle, tone: 'bg-earth-terracotta/15 border-earth-terracotta text-earth-terracottaDark', titleKey: 'foodCheckRed' },
};

const NOTE_KEY = { green: 'foodCheckGreenNote', yellow: 'foodCheckYellowNote', red: 'foodCheckRedNote' };

export default function FoodCheck() {
  const { t, language } = useAppSettings();
  const look = useSectionLook();
  const [needs] = useDietaryNeeds();
  const [query, setQuery] = useState('');
  const [result, setResult] = useState(null);
  const [open, setOpen] = useState(false);

  const run = () => {
    if (!query.trim()) return;
    setResult(checkFood(query, needs));
  };

  const clear = () => {
    setQuery('');
    setResult(null);
  };

  const style = result && result.verdict ? VERDICT[result.verdict] : null;
  const Icon = style ? style.icon : HelpCircle;
  const foodLabel = result && result.food ? (result.food.text[language] || result.food.text.en) : '';
  const needLabel = result && result.need ? t(NEED_LABEL[result.need]) : '';

  return (
    <div className="mb-5 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={`w-full ${look.bar} px-5 py-3 flex items-center gap-3`}
      >
        <Search className="w-6 h-6 text-white shrink-0" strokeWidth={2.5} />
        <h2 className="flex-1 text-left font-heading text-xl text-white">{t('foodCheckTitle')}</h2>
        <ChevronDown className={`w-7 h-7 text-white shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} strokeWidth={2.5} />
      </button>

      {open && <div className="p-5">
        <p className="text-muted-foreground mb-4">{t('foodCheckHelp')}</p>

        <div className="flex gap-2 mb-4">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && run()}
            placeholder={t('foodCheckPlaceholder')}
            className="flex-1 px-4 py-3 rounded-xl border-2 border-input bg-card text-foreground focus:border-earth-lagoon outline-none text-lg"
          />
          <button
            onClick={run}
            className="px-6 py-3 rounded-xl bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold transition min-h-[56px]"
          >
            {t('foodCheckButton')}
          </button>
        </div>

        {result && result.needsMissing && (
          <p className="p-4 rounded-2xl bg-secondary border-2 border-border text-foreground font-semibold">
            {t('foodCheckNoNeeds')}
          </p>
        )}

        {result && result.found === false && (
          <div className="p-5 rounded-2xl bg-secondary border-2 border-border">
            <p className="flex items-center gap-2 font-bold text-foreground mb-1">
              <HelpCircle className="w-6 h-6 shrink-0" strokeWidth={2.5} />
              {t('foodCheckUnknown')}
            </p>
            <p className="text-muted-foreground">{t('checkWithPharmacist')}</p>
          </div>
        )}

        {result && result.verdict && (
          <div className={`p-5 rounded-2xl border-2 ${style.tone}`}>
            <p className="flex items-center gap-3 font-heading text-xl mb-2">
              <Icon className="w-7 h-7 shrink-0" strokeWidth={2.5} />
              {foodLabel} — {t(style.titleKey)}
            </p>
            <p className="font-semibold mb-3">
              {t(NOTE_KEY[result.verdict]).replace('{food}', foodLabel).replace('{need}', needLabel)}
            </p>
            {result.swap && SWAPS[result.swap] && (
              <p className="flex items-start gap-2">
                <Lightbulb className="w-5 h-5 shrink-0 mt-0.5" strokeWidth={2.5} />
                <span>
                  <span className="font-bold">{t('foodCheckSwap')} </span>
                  {SWAPS[result.swap][language] || SWAPS[result.swap].en}
                </span>
              </p>
            )}
            <button
              onClick={clear}
              className="mt-4 px-4 py-3 rounded-xl bg-card border-2 border-current font-bold transition min-h-[56px]"
            >
              {t('foodCheckClear')}
            </button>
          </div>
        )}
      </div>}
    </div>
  );
}