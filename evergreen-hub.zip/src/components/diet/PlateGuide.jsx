import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Utensils, ChevronDown } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

const SECTORS = [
  { key: 'plateVeg', className: 'w-1/2 h-full bg-earth-sage' },
  { key: 'plateProtein', className: 'h-1/2 bg-earth-terracotta' },
  { key: 'plateGrains', className: 'h-1/2 bg-earth-marigold' },
];

const LEGEND = [
  { key: 'plateVeg', portionKey: 'plateVegPortion', dot: 'bg-earth-sage' },
  { key: 'plateProtein', portionKey: 'plateProteinPortion', dot: 'bg-earth-terracotta' },
  { key: 'plateGrains', portionKey: 'plateGrainsPortion', dot: 'bg-earth-marigold' },
];

export default function PlateGuide() {
  const { t } = useAppSettings();
  const look = useSectionLook();
  const [open, setOpen] = useState(false);

  return (
    <div className="mb-5 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={`w-full ${look.bar} px-5 py-3 flex items-center gap-3`}
      >
        <Utensils className="w-6 h-6 text-white shrink-0" strokeWidth={2.5} />
        <h2 className="flex-1 text-left font-heading text-xl text-white">{t('plateTitle')}</h2>
        <ChevronDown className={`w-7 h-7 text-white shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} strokeWidth={2.5} />
      </button>

      {open && <div className="p-5 flex flex-col sm:flex-row items-center gap-6">
        <div className="w-56 h-56 rounded-full overflow-hidden flex shrink-0 border-[6px] border-card shadow-lg">
          <div className={`${SECTORS[0].className} flex items-center justify-center`}>
            <span className="text-white font-bold text-center px-2">{t('plateVeg')}</span>
          </div>
          <div className="w-1/2 h-full flex flex-col">
            <div className={`${SECTORS[1].className} flex items-center justify-center`}>
              <span className="text-white font-bold text-center px-1 text-sm">{t('plateProtein')}</span>
            </div>
            <div className={`${SECTORS[2].className} flex items-center justify-center`}>
              <span className="text-white font-bold text-center px-1 text-sm">{t('plateGrains')}</span>
            </div>
          </div>
        </div>

        <div className="flex-1">
          <p className="text-muted-foreground mb-4">{t('plateHelp')}</p>
          <ul className="space-y-3">
            {LEGEND.map((item) => (
              <li key={item.key} className="flex items-start gap-3">
                <span className={`w-5 h-5 rounded-full shrink-0 mt-1 ${item.dot}`} />
                <span>
                  <span className="font-bold text-foreground">{t(item.key)}</span>
                  <span className="text-muted-foreground"> — {t(item.portionKey)}</span>
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-muted-foreground">{t('plateNote')}</p>
        </div>
      </div>}
    </div>
  );
}