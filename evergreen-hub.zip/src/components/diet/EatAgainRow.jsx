import React from 'react';

/** The last meals typed, as big buttons, so a meal can be repeated without typing. */
export default function EatAgainRow({ label, meals, onPick }) {
  if (!meals.length) return null;

  return (
    <div className="mt-3">
      <p className="font-bold text-muted-foreground mb-2">{label}</p>
      <div className="flex flex-wrap gap-2">
        {meals.map((meal) => (
          <button
            key={meal}
            onClick={() => onPick(meal)}
            className="px-4 py-3 rounded-2xl border-2 border-border bg-secondary hover:border-earth-lagoon text-foreground font-bold text-lg text-left transition min-h-[56px]"
          >
            {meal}
          </button>
        ))}
      </div>
    </div>
  );
}