import React, { useState, useEffect, useRef } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Check, Lightbulb, BookOpen } from 'lucide-react';
import EatAgainRow from '@/components/diet/EatAgainRow';
import MealIdeasPanel from '@/components/diet/MealIdeasPanel';
import MealRecipePanel from '@/components/diet/MealRecipePanel';
import { fetchMealIdeas, fetchMealRecipe } from '@/lib/nutrition/mealIdeas';

/** One meal of one day: a box to type in, ideas, a recipe and the log button. */
export default function MealSlotCard({ slot, label, entry, isToday, recent, context, onSaveName, onSaveRecipe, onLog }) {
  const { t, language } = useAppSettings();
  const [text, setText] = useState(entry.custom_name || '');
  const [saved, setSaved] = useState(false);
  const [showIdeas, setShowIdeas] = useState(false);
  const [ideas, setIdeas] = useState([]);
  const [ideasLoading, setIdeasLoading] = useState(false);
  const [ideasError, setIdeasError] = useState(false);
  const [showRecipe, setShowRecipe] = useState(false);
  const [recipe, setRecipe] = useState(entry.recipe || null);
  const [recipeLoading, setRecipeLoading] = useState(false);
  const [recipeError, setRecipeError] = useState(false);
  const lastSaved = useRef(entry.custom_name || '');
  const flashTimer = useRef(null);

  const trimmed = text.trim();
  // A stored recipe only counts for the meal it belongs to.
  const matchingRecipe =
    recipe && recipe.name && recipe.name.toLowerCase() === trimmed.toLowerCase() ? recipe : null;

  const flash = () => {
    setSaved(true);
    window.clearTimeout(flashTimer.current);
    flashTimer.current = window.setTimeout(() => setSaved(false), 2000);
  };

  // Typing saves itself a moment after you stop.
  useEffect(() => {
    const value = text.trim();
    if (value === lastSaved.current) return;
    const timer = window.setTimeout(async () => {
      lastSaved.current = value;
      await onSaveName(value);
      flash();
    }, 900);
    return () => window.clearTimeout(timer);
  }, [text]);

  const loadIdeas = async (exclude) => {
    setIdeasLoading(true);
    setIdeasError(false);
    try {
      const next = await fetchMealIdeas({ slot, ...context, typed: trimmed, exclude, language });
      setIdeas((prev) => (exclude.length ? [...prev, ...next] : next));
    } catch {
      setIdeasError(true);
    }
    setIdeasLoading(false);
  };

  const giveIdeas = () => {
    if (showIdeas) {
      setShowIdeas(false);
      return;
    }
    setShowIdeas(true);
    if (!ideas.length && !ideasLoading) loadIdeas([]);
  };

  const addIdea = async (idea) => {
    const next = { name: idea.name, ingredients: idea.ingredients || [], steps: idea.steps || [] };
    setText(idea.name);
    lastSaved.current = idea.name;
    setRecipe(next);
    setShowRecipe(false);
    await onSaveName(idea.name);
    await onSaveRecipe(next);
    flash();
  };

  const openRecipe = async () => {
    if (showRecipe) {
      setShowRecipe(false);
      return;
    }
    setShowRecipe(true);
    if (matchingRecipe) return;
    setRecipeLoading(true);
    setRecipeError(false);
    try {
      setRecipe(
        await fetchMealRecipe({
          name: trimmed,
          needs: context.needs,
          allergies: context.allergies,
          language,
        }),
      );
    } catch {
      setRecipeError(true);
    }
    setRecipeLoading(false);
  };

  const button = 'flex items-center justify-center gap-2 px-4 py-3 rounded-2xl font-bold text-lg transition min-h-[56px]';

  return (
    <div className="rounded-3xl bg-card border-2 border-border p-5">
      <p className="font-heading text-xl text-foreground mb-3">{label}</p>

      <label className="block font-bold text-muted-foreground mb-2">{t('mealWhatEating')}</label>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={2}
        className="w-full px-4 py-3 rounded-xl border-2 border-input bg-card text-foreground focus:border-earth-lagoon outline-none text-lg resize-none min-h-[56px]"
      />
      {saved && (
        <p role="status" className="flex items-center gap-2 mt-2 text-earth-lagoonDark font-bold">
          <Check className="w-5 h-5" strokeWidth={3} />
          {t('saved')}
        </p>
      )}

      <EatAgainRow label={t('mealEatAgain')} meals={recent} onPick={setText} />

      <div className="flex flex-wrap gap-2 mt-4">
        <button
          onClick={giveIdeas}
          className={`${button} bg-earth-marigold hover:bg-earth-marigoldDark text-white`}
        >
          <Lightbulb className="w-5 h-5" strokeWidth={2.5} />
          {t('mealGiveIdeas')}
        </button>

        {trimmed && (
          <button onClick={openRecipe} className={`${button} bg-secondary hover:bg-muted border-2 border-border text-foreground`}>
            <BookOpen className="w-5 h-5" strokeWidth={2.5} />
            {t('mealRecipe')}
          </button>
        )}

        {isToday && onLog && (
          <button
            onClick={() => onLog(trimmed)}
            disabled={entry.logged || !trimmed}
            className={`${button} ${
              entry.logged
                ? 'bg-earth-sage/20 text-earth-sageDark'
                : 'bg-earth-lagoon hover:bg-earth-lagoonDark text-white disabled:opacity-40'
            }`}
          >
            {entry.logged && <Check className="w-5 h-5" strokeWidth={3} />}
            {entry.logged ? t('plannerLogged') : t('plannerLogMeal')}
          </button>
        )}
      </div>

      {showIdeas && (
        <MealIdeasPanel
          ideas={ideas}
          loading={ideasLoading}
          error={ideasError}
          onAdd={addIdea}
          onMore={() => loadIdeas(ideas.map((i) => i.name))}
        />
      )}

      {showRecipe && <MealRecipePanel recipe={matchingRecipe} loading={recipeLoading} error={recipeError} />}
    </div>
  );
}