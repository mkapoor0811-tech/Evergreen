import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { withFoodMeds, isMedTakenToday, applyMedTaken, logDose } from '@/lib/medTaken';
import { Pill, Check, X } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

const SLOT_BY_HOUR = (hour) => {
  if (hour >= 6 && hour < 11) return 'breakfast';
  if (hour >= 11 && hour < 15) return 'lunch';
  if (hour >= 17 && hour < 21) return 'dinner';
  return null;
};

export default function MealMedicationPrompt({ justLoggedSlot }) {
  const { t } = useAppSettings();
  const look = useSectionLook();
  const [meds, setMeds] = useState(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    base44.entities.Medication.list('-created_date', 100).then(setMeds);
  }, [justLoggedSlot]);

  useEffect(() => { setDismissed(false); }, [justLoggedSlot]);

  const pending = withFoodMeds(meds).filter((m) => !isMedTakenToday(m));
  const mealSlot = justLoggedSlot || SLOT_BY_HOUR(new Date().getHours());

  if (dismissed || !mealSlot || pending.length === 0) return null;

  const names = pending.map((m) => m.name).join(', ');
  const message = justLoggedSlot
    ? t('withFoodAfterMeal').replace('{med}', names)
    : t('withFoodTimePrompt').replace('{meal}', t(mealSlot)).replace('{med}', names);

  const markAllTaken = async () => {
    for (const med of pending) {
      const changed = await applyMedTaken(med, true);
      if (changed) await logDose(med, 'taken');
    }
    setMeds(await base44.entities.Medication.list('-created_date', 100));
  };

  return (
    <div className="mb-6 rounded-3xl bg-earth-lagoon/10 border-2 border-earth-lagoon/40 overflow-hidden">
      <div className={`${look.bar} px-5 py-3 flex items-center gap-3`}>
        <Pill className="w-6 h-6 text-white" strokeWidth={2.5} />
        <h2 className="font-heading text-xl text-white">{t('withFoodTitle')}</h2>
      </div>
      <div className="p-5">
        <p className="text-foreground mb-4">{message}</p>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={markAllTaken}
            className="flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-earth-sage hover:bg-earth-sageDark text-white font-bold transition min-h-[56px]"
          >
            <Check className="w-6 h-6" strokeWidth={3} />
            {t('withFoodYes')}
          </button>
          <button
            onClick={() => setDismissed(true)}
            className="flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px]"
          >
            <X className="w-6 h-6" strokeWidth={2.5} />
            {t('withFoodNotYet')}
          </button>
        </div>
      </div>
    </div>
  );
}