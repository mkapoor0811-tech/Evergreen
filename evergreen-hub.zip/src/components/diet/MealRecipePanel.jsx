import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Loader2 } from 'lucide-react';

/** Ingredients and short steps for the meal in the box. */
export default function MealRecipePanel({ recipe, loading, error }) {
  const { t } = useAppSettings();

  if (loading) {
    return (
      <p className="flex items-center gap-2 mt-4 text-muted-foreground font-bold">
        <Loader2 className="w-5 h-5 animate-spin" />
        {t('mealRecipeLoading')}
      </p>
    );
  }

  if (error) {
    return <p className="mt-4 text-earth-terracottaDark font-bold">{t('mealRecipeError')}</p>;
  }

  if (!recipe) return null;

  return (
    <div className="mt-4 pt-4 border-t-2 border-border">
      <h4 className="font-bold text-lg text-foreground mb-2">{t('recipeIngredients')}</h4>
      <ul className="mb-5 space-y-1">
        {recipe.ingredients.map((item, i) => (
          <li key={i} className="flex items-start gap-2 text-lg text-foreground">
            <span className="text-earth-terracotta shrink-0">•</span>
            {item}
          </li>
        ))}
      </ul>

      <h4 className="font-bold text-lg text-foreground mb-2">{t('recipeSteps')}</h4>
      <ol className="space-y-3">
        {recipe.steps.map((step, i) => (
          <li key={i} className="flex items-start gap-3 text-lg text-foreground">
            <span className="w-8 h-8 rounded-full bg-earth-terracotta text-white font-bold flex items-center justify-center shrink-0">
              {i + 1}
            </span>
            <span>{step}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}