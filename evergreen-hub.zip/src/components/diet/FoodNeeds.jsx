import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { useDietaryNeeds } from '@/lib/nutrition/useDietaryNeeds';
import { FOODS } from '@/lib/nutrition/foodCheck';
import { Check, ThumbsUp, ThumbsDown } from 'lucide-react';

const NEEDS = [
  { id: 'diabetic', labelKey: 'needDiabeticFood' },
  { id: 'lowSodium', labelKey: 'needLowSalt' },
  { id: 'digestive', labelKey: 'needEasyStomach' },
  { id: 'general', labelKey: 'needGeneralHealthy' },
];

const nameOf = (food, language) => food.text[language] || food.text.en;

/** Pick what suits you, then see foods to enjoy and foods to limit. */
export default function FoodNeeds() {
  const { t, language } = useAppSettings();
  const [needs, setNeeds] = useDietaryNeeds();

  const toggle = (id) => {
    setNeeds(needs.includes(id) ? needs.filter((n) => n !== id) : [...needs, id]);
  };

  const enjoy = needs.length
    ? FOODS.filter((f) => needs.every((n) => (f.verdicts[n] || 'green') === 'green')).slice(0, 8)
    : [];
  const limit = needs.length
    ? FOODS.filter((f) => needs.some((n) => (f.verdicts[n] || 'green') === 'red')).slice(0, 8)
    : [];

  return (
    <section className="mb-6">
      <h2 className="font-heading text-2xl text-foreground mb-4">{t('myFoodNeeds')}</h2>

      <div className="grid grid-cols-2 gap-3 mb-5">
        {NEEDS.map(({ id, labelKey }) => {
          const on = needs.includes(id);
          return (
            <button
              key={id}
              onClick={() => toggle(id)}
              className={`flex items-center justify-center gap-2 px-4 py-4 rounded-2xl border-2 transition min-h-[68px] ${
                on ? 'bg-earth-lagoon border-earth-lagoon text-white' : 'bg-card border-border text-foreground hover:border-earth-lagoon'
              }`}
            >
              {on && <Check className="w-6 h-6 shrink-0" strokeWidth={3} />}
              <span className="font-bold leading-tight">{t(labelKey)}</span>
            </button>
          );
        })}
      </div>

      {needs.length > 0 && (
        <div className="space-y-4 mb-5">
          <div className="rounded-2xl border-2 border-earth-sage/50 bg-card p-5">
            <h3 className="flex items-center gap-2 font-heading text-xl text-foreground mb-3">
              <ThumbsUp className="w-6 h-6 text-earth-sageDark" strokeWidth={2.5} />
              {t('foodsToEnjoy')}
            </h3>
            <ul className="space-y-2">
              {enjoy.map((food) => (
                <li key={food.id} className="text-lg text-foreground leading-snug">• {nameOf(food, language)}</li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border-2 border-earth-terracotta/50 bg-card p-5">
            <h3 className="flex items-center gap-2 font-heading text-xl text-foreground mb-3">
              <ThumbsDown className="w-6 h-6 text-earth-terracotta" strokeWidth={2.5} />
              {t('foodsToLimit')}
            </h3>
            <ul className="space-y-2">
              {limit.map((food) => (
                <li key={food.id} className="text-lg text-foreground leading-snug">• {nameOf(food, language)}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      <p className="p-4 rounded-2xl bg-earth-marigold/15 border-2 border-earth-marigold/50 text-lg text-foreground font-semibold leading-snug">
        {t('foodNeedsNote')}
      </p>
    </section>
  );
}