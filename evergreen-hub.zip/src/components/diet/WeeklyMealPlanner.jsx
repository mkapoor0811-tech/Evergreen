import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { useDietaryNeeds, useCuisines } from '@/lib/nutrition/useDietaryNeeds';
import MealSlotCard from '@/components/diet/MealSlotCard';
import { CalendarDays } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';
import { todayLocal, localDate } from '@/lib/localDate';
import { readRecentMeals, rememberMeal } from '@/lib/nutrition/recentMeals';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

const SLOTS = [
  { key: 'breakfast', label: 'breakfast' },
  { key: 'lunch', label: 'lunch' },
  { key: 'dinner', label: 'dinner' },
  { key: 'snack', label: 'snack' },
];

const todayStr = todayLocal;

function startOfWeek() {
  const d = new Date();
  const offset = (d.getDay() + 6) % 7; // Monday first
  d.setDate(d.getDate() - offset);
  return localDate(d);
}

function weekDays(weekStart) {
  const first = new Date(`${weekStart}T00:00:00`);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(first);
    d.setDate(first.getDate() + i);
    return d;
  });
}

export default function WeeklyMealPlanner({ onLogMeal }) {
  const { t, language } = useAppSettings();
  const look = useSectionLook();
  const [needs] = useDietaryNeeds();
  const [cuisines] = useCuisines();
  const [plan, setPlan] = useState(null);
  const [recent, setRecent] = useState(() => readRecentMeals());
  const [allergies, setAllergies] = useState('');
  const [dayIndex, setDayIndex] = useState(() => (new Date().getDay() + 6) % 7);

  const weekStart = startOfWeek();
  const days = weekDays(weekStart);

  useEffect(() => {
    base44.entities.CaregiverSetting.list()
      .then((rows) => setAllergies(rows[0]?.allergies || ''))
      .catch(() => {});
  }, []);

  // Every day of the week starts empty and waits to be filled in.
  const load = async () => {
    const page = await base44.entities.MealPlan.filter(
      { week_start: weekStart },
      { sort: 'day_index', limit: 40 },
    );
    let items = page.items || [];
    const have = new Set(items.map((p) => `${p.day_index}-${p.slot}`));

    const missing = [];
    for (let day = 0; day < 7; day++) {
      SLOTS.forEach(({ key }) => {
        if (!have.has(`${day}-${key}`)) missing.push({ day, slot: key });
      });
    }

    if (missing.length) {
      const created = await base44.entities.MealPlan.bulkCreate(
        missing.map(({ day, slot }) => ({
          week_start: weekStart,
          day_index: day,
          slot,
          meal_id: 'custom',
          custom_name: '',
          logged: false,
        })),
      );
      items = [...items, ...created];
    }
    setPlan(items);
  };

  useEffect(() => {
    load();
  }, [weekStart]);

  const saveName = async (entry, name) => {
    await base44.entities.MealPlan.update(entry.id, { custom_name: name });
    setRecent(rememberMeal(name));
    load();
  };

  const saveRecipe = async (entry, recipe) => {
    await base44.entities.MealPlan.update(entry.id, { recipe });
    load();
  };

  const logMeal = (entry, name) => {
    if (!name) return;
    base44.entities.MealPlan.update(entry.id, { logged: true }).then(load);
    // The food log calls this meal "snacks".
    if (onLogMeal) onLogMeal(entry.slot === 'snack' ? 'snacks' : entry.slot, name, selectedDate);
  };

  const selectedDate = localDate(days[dayIndex]);
  const isToday = selectedDate === todayStr();
  const context = { cuisines, needs, allergies };

  const entriesForDay = plan
    ? SLOTS.map(({ key, label }) => ({
        entry: plan.find((p) => p.day_index === dayIndex && p.slot === key),
        label: t(label),
      })).filter((row) => row.entry)
    : [];

  return (
    <div className="mb-6 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <div className={`${look.bar} px-5 py-3 flex items-center gap-3`}>
        <CalendarDays className="w-6 h-6 text-white" strokeWidth={2.5} />
        <h2 className="font-heading text-xl text-white">{t('plannerTitle')}</h2>
      </div>

      <div className="p-5">
        <p className="text-muted-foreground mb-4">{t('plannerHelp')}</p>

        <div className="flex gap-2 overflow-x-auto pb-2 mb-5">
          {days.map((d, i) => {
            const active = i === dayIndex;
            const isTodayChip = localDate(d) === todayStr();
            return (
              <button
                key={i}
                onClick={() => setDayIndex(i)}
                className={`shrink-0 px-4 py-3 rounded-2xl border-2 font-bold transition min-h-[56px] ${
                  active
                    ? 'bg-earth-marigold border-earth-marigold text-white'
                    : 'bg-secondary border-border text-foreground hover:border-earth-marigold'
                }`}
              >
                <span className="block text-sm">
                  {d.toLocaleDateString(LOCALES[language] || 'en-US', { weekday: 'short' })}
                </span>
                <span className="block">{d.getDate()}</span>
                {isTodayChip && <span className="block text-xs">{t('today')}</span>}
              </button>
            );
          })}
        </div>

        {plan === null ? (
          <p className="text-center text-muted-foreground py-6">{t('loading')}</p>
        ) : (
          <div className="space-y-5">
            {entriesForDay.map(({ entry, label }) => (
              <MealSlotCard
                key={entry.id}
                slot={entry.slot}
                label={label}
                entry={entry}
                isToday={isToday}
                recent={recent.slice(0, 5)}
                context={context}
                onSaveName={(name) => saveName(entry, name)}
                onSaveRecipe={(recipe) => saveRecipe(entry, recipe)}
                onLog={(name) => logMeal(entry, name)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}