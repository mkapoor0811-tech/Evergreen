import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { useCuisines } from '@/lib/nutrition/useDietaryNeeds';
import { Utensils, Check, X } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

const CHOICES = [
  { key: 'indian', icon: '🍛', label: 'cuisineIndian' },
  { key: 'chinese', icon: '🥢', label: 'cuisineChinese' },
  { key: 'mediterranean', icon: '🫒', label: 'cuisineMediterranean' },
  { key: 'american', icon: '🍲', label: 'cuisineAmerican' },
  { key: 'mexican', icon: '🌮', label: 'cuisineMexican' },
  { key: 'middleEastern', icon: '🧆', label: 'cuisineMiddleEastern' },
];

const KNOWN = CHOICES.map((c) => c.key);

/** Asked once at the top of the Diet screen, and easy to change later. */
export default function FoodSetupCard() {
  const { t } = useAppSettings();
  const look = useSectionLook();
  const [cuisines, setCuisines] = useCuisines();
  const [open, setOpen] = useState(() => cuisines.length === 0);
  const [other, setOther] = useState('');
  const [saved, setSaved] = useState(false);

  const mine = cuisines.filter((c) => !KNOWN.includes(c));

  const write = (next) => {
    setCuisines(next);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2000);
  };

  const toggle = (key) =>
    write(cuisines.includes(key) ? cuisines.filter((c) => c !== key) : [...cuisines, key]);

  const addOther = () => {
    const text = other.trim();
    if (!text) return;
    write([...cuisines, text]);
    setOther('');
  };

  const chosenLabels = [
    ...CHOICES.filter((c) => cuisines.includes(c.key)).map((c) => `${c.icon} ${t(c.label)}`),
    ...mine,
  ];

  return (
    <div className="mb-6 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <div className={`${look.bar} px-5 py-3 flex items-center gap-3`}>
        <Utensils className="w-6 h-6 text-white" strokeWidth={2.5} />
        <h2 className="font-heading text-xl text-white">{t('foodSetupTitle')}</h2>
      </div>

      <div className="p-5">
        {open ? (
          <>
            <p className="text-muted-foreground mb-4">{t('foodSetupHelp')}</p>

            <div className="flex flex-wrap gap-2">
              {CHOICES.map((choice) => {
                const active = cuisines.includes(choice.key);
                return (
                  <button
                    key={choice.key}
                    onClick={() => toggle(choice.key)}
                    className={`flex items-center gap-2 px-4 py-3 rounded-2xl border-2 font-bold text-lg transition min-h-[56px] ${
                      active
                        ? 'bg-earth-lagoon border-earth-lagoon text-white'
                        : 'bg-secondary border-border text-foreground hover:border-earth-lagoon'
                    }`}
                  >
                    <span className="text-xl">{choice.icon}</span>
                    {t(choice.label)}
                  </button>
                );
              })}
            </div>

            {mine.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {mine.map((name) => (
                  <button
                    key={name}
                    onClick={() => write(cuisines.filter((c) => c !== name))}
                    className="flex items-center gap-2 px-4 py-3 rounded-2xl border-2 border-earth-lagoon bg-earth-lagoon/10 text-foreground font-bold text-lg min-h-[56px]"
                  >
                    {name}
                    <X className="w-5 h-5" strokeWidth={3} />
                  </button>
                ))}
              </div>
            )}

            <p className="font-bold text-muted-foreground mt-5 mb-2">{t('foodSetupOther')}</p>
            <div className="flex flex-wrap gap-2">
              <input
                value={other}
                onChange={(e) => setOther(e.target.value)}
                placeholder={t('foodSetupOtherPlaceholder')}
                className="flex-1 min-w-[12rem] px-4 py-3 rounded-xl border-2 border-input bg-card text-foreground text-lg outline-none focus:border-earth-lagoon min-h-[56px]"
              />
              <button
                onClick={addOther}
                className="px-5 py-3 rounded-2xl bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold text-lg min-h-[56px]"
              >
                {t('mealAdd')}
              </button>
            </div>

            <button
              onClick={() => setOpen(false)}
              className="w-full mt-5 py-4 rounded-2xl bg-secondary hover:bg-muted border-2 border-border text-foreground font-bold min-h-[56px]"
            >
              {t('foodSetupDone')}
            </button>
          </>
        ) : (
          <div className="flex items-center justify-between gap-4">
            <p className="text-lg text-foreground font-semibold min-w-0">
              {chosenLabels.length ? chosenLabels.join(' · ') : t('foodSetupOther')}
            </p>
            <button
              onClick={() => setOpen(true)}
              className="shrink-0 px-5 py-3 rounded-2xl bg-secondary hover:bg-muted border-2 border-border text-foreground font-bold min-h-[56px]"
            >
              {t('foodSetupChange')}
            </button>
          </div>
        )}

        {saved && (
          <p role="status" className="flex items-center gap-2 mt-3 text-earth-lagoonDark font-bold">
            <Check className="w-5 h-5" strokeWidth={3} />
            {t('saved')}
          </p>
        )}
      </div>
    </div>
  );
}