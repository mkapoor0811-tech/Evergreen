import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Droplet } from 'lucide-react';
import { todayLocal } from '@/lib/localDate';

const GLASSES = 8;
const key = () => `mahika_water_${todayLocal()}`;

/** Eight glasses to tap through the day. */
export default function WaterTracker() {
  const { t } = useAppSettings();
  const [count, setCount] = useState(() => {
    const stored = parseInt(localStorage.getItem(key()) || '0', 10);
    return Number.isFinite(stored) ? Math.min(GLASSES, Math.max(0, stored)) : 0;
  });

  const tap = (index) => {
    const next = index + 1 === count ? index : index + 1;
    setCount(next);
    localStorage.setItem(key(), String(next));
  };

  return (
    <section className="mb-6">
      <h2 className="font-heading text-2xl text-foreground mb-4">{t('waterTitle')}</h2>
      <div className="rounded-2xl border-2 border-border bg-card p-5">
        <p className="text-lg font-bold text-foreground mb-4">
          {t('waterCount').replace('{n}', String(count))}
        </p>
        <div className="grid grid-cols-4 gap-3">
          {Array.from({ length: GLASSES }, (_, i) => {
            const filled = i < count;
            return (
              <button
                key={i}
                onClick={() => tap(i)}
                aria-label={`${t('waterTitle')} ${i + 1}`}
                className={`flex flex-col items-center justify-center gap-1 rounded-2xl border-2 transition min-h-[80px] ${
                  filled
                    ? 'bg-earth-lagoon border-earth-lagoon text-white'
                    : 'bg-card border-border text-muted-foreground hover:border-earth-lagoon'
                }`}
              >
                <Droplet className="w-7 h-7" strokeWidth={2.5} fill={filled ? 'currentColor' : 'none'} />
                <span className="font-bold">{i + 1}</span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}