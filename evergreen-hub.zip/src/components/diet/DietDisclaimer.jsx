import React from 'react';
import { Info } from 'lucide-react';
import { useAppSettings } from '@/lib/AppSettings';

export default function DietDisclaimer() {
  const { t } = useAppSettings();
  return (
    <p className="mb-5 p-4 rounded-2xl bg-earth-marigold/15 border-2 border-earth-marigold/50 text-foreground flex items-start gap-3">
      <Info className="w-6 h-6 shrink-0 mt-0.5 text-earth-marigoldDark" strokeWidth={2.5} />
      <span className="font-semibold">{t('nutritionDisclaimer')}</span>
    </p>
  );
}