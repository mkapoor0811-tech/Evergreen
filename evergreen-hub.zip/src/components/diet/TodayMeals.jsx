import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { parseDiet } from '@/lib/voiceParse';
import VoiceButton from '@/components/VoiceButton';
import { Check, Loader2, Copy } from 'lucide-react';
import { todayLocal, localDate } from '@/lib/localDate';

const todayStr = todayLocal;
const yesterdayStr = () => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return localDate(d);
};

const SLOTS = [
  { key: 'breakfast', labelKey: 'breakfast' },
  { key: 'lunch', labelKey: 'lunch' },
  { key: 'dinner', labelKey: 'dinner' },
];

/** Log today's three meals by typing, by voice, or by copying yesterday. */
export default function TodayMeals() {
  const { t } = useAppSettings();
  const [log, setLog] = useState(null);
  const [yesterday, setYesterday] = useState(null);
  const [openSlot, setOpenSlot] = useState(null);
  const [savedSlot, setSavedSlot] = useState(null);
  const [voiceProcessing, setVoiceProcessing] = useState(false);

  useEffect(() => {
    Promise.all([
      base44.entities.DietLog.filter({ date: todayStr() }, { limit: 1 }),
      base44.entities.DietLog.filter({ date: yesterdayStr() }, { limit: 1 }),
    ]).then(([todayPage, yesterdayPage]) => {
      setLog(todayPage.items[0] || { date: todayStr(), breakfast: '', lunch: '', dinner: '' });
      setYesterday(yesterdayPage.items[0] || null);
    });
  }, []);

  const persist = async (next) => {
    if (next.id) {
      await base44.entities.DietLog.update(next.id, {
        breakfast: next.breakfast, lunch: next.lunch, dinner: next.dinner,
      });
    } else {
      const created = await base44.entities.DietLog.create({
        date: next.date, breakfast: next.breakfast, lunch: next.lunch, dinner: next.dinner,
      });
      next = { ...next, id: created.id };
    }
    return next;
  };

  const saveSlot = async (slot) => {
    const next = await persist(log);
    setLog(next);
    setSavedSlot(slot);
    setOpenSlot(null);
    setTimeout(() => setSavedSlot(null), 2500);
  };

  const sameAsYesterday = async (slot) => {
    const text = yesterday?.[slot] || '';
    const next = { ...log, [slot]: text };
    setLog(next);
    await persist(next);
    setSavedSlot(slot);
    setOpenSlot(null);
    setTimeout(() => setSavedSlot(null), 2500);
  };

  const handleVoiceResult = async (transcript) => {
    setVoiceProcessing(true);
    try {
      const parsed = await parseDiet(transcript);
      if (parsed.meal && parsed.content) {
        setLog((prev) => {
          const existing = prev[parsed.meal] || '';
          return { ...prev, [parsed.meal]: existing ? `${existing} ${parsed.content}` : parsed.content };
        });
        setOpenSlot(parsed.meal);
      }
    } catch (e) { /* the person can type it instead */ }
    setVoiceProcessing(false);
  };

  if (!log) {
    return (
      <div className="mb-6 p-6 rounded-2xl bg-card border-2 border-border text-muted-foreground font-semibold">
        {t('loading')}
      </div>
    );
  }

  return (
    <section className="mb-6">
      <h2 className="font-heading text-2xl text-foreground mb-4">{t('todayMeals')}</h2>

      {voiceProcessing && (
        <div className="mb-4 flex items-center justify-center gap-2 p-4 bg-earth-lagoon/10 rounded-2xl text-earth-lagoonDark font-bold">
          <Loader2 className="w-5 h-5 animate-spin" />
          {t('voiceProcessing')}
        </div>
      )}

      <div className="space-y-4">
        {SLOTS.map(({ key, labelKey }) => {
          const open = openSlot === key;
          const text = log[key] || '';
          return (
            <div key={key} className="rounded-2xl border-2 border-border bg-card overflow-hidden">
              <button
                onClick={() => setOpenSlot(open ? null : key)}
                className="w-full text-left px-5 py-5 min-h-[76px]"
              >
                <span className="block font-heading text-xl text-foreground">{t(labelKey)}</span>
                <span className={`block mt-1 ${text ? 'text-lg text-foreground' : 'text-lg text-muted-foreground'}`}>
                  {text || t('whatDidYouEat')}
                </span>
                {savedSlot === key && (
                  <span className="mt-2 flex items-center gap-2 text-earth-sageDark font-bold">
                    <Check className="w-5 h-5" strokeWidth={3} /> {t('saved')}
                  </span>
                )}
              </button>

              {open && (
                <div className="px-5 pb-5 space-y-3">
                  <textarea
                    value={text}
                    onChange={(e) => setLog({ ...log, [key]: e.target.value })}
                    placeholder={t('whatDidYouEat')}
                    rows={2}
                    className="w-full px-4 py-3 rounded-xl border-2 border-input bg-card text-foreground focus:border-earth-terracotta outline-none text-lg resize-none"
                  />
                  <button
                    onClick={() => saveSlot(key)}
                    className="w-full flex items-center justify-center gap-2 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-4 rounded-xl transition min-h-[56px]"
                  >
                    <Check className="w-6 h-6" strokeWidth={3} />
                    {t('save')}
                  </button>
                  <VoiceButton
                    label={t('addByVoice')}
                    prompt={t('voiceDietPrompt')}
                    onResult={handleVoiceResult}
                  />
                  {yesterday?.[key] && (
                    <button
                      onClick={() => sameAsYesterday(key)}
                      className="w-full flex items-center justify-center gap-2 bg-secondary hover:bg-muted text-foreground font-bold py-4 rounded-xl transition min-h-[56px]"
                    >
                      <Copy className="w-6 h-6" strokeWidth={2.5} />
                      {t('sameAsYesterday')}
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}