import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Loader2 } from 'lucide-react';

/** Four meal ideas at a time, with a gentle note that these are only ideas. */
export default function MealIdeasPanel({ ideas, loading, error, onAdd, onMore }) {
  const { t } = useAppSettings();

  return (
    <div className="mt-4">
      {loading && (
        <p className="flex items-center gap-2 text-muted-foreground font-bold py-3">
          <Loader2 className="w-5 h-5 animate-spin" />
          {t('mealIdeasLoading')}
        </p>
      )}

      {!loading && error && (
        <p className="text-earth-terracottaDark font-bold py-3">{t('mealIdeasError')}</p>
      )}

      <div className="space-y-3">
        {ideas.map((idea) => (
          <div
            key={idea.name}
            className="flex items-center justify-between gap-3 p-4 rounded-2xl border-2 border-border bg-secondary/60"
          >
            <div className="min-w-0">
              <p className="font-bold text-lg text-foreground leading-snug">{idea.name}</p>
              <p className="text-muted-foreground font-semibold">
                {idea.minutes} {t('recipeMinutes')}
              </p>
            </div>
            <button
              onClick={() => onAdd(idea)}
              className="shrink-0 px-5 py-3 rounded-2xl bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold min-h-[56px]"
            >
              {t('mealAdd')}
            </button>
          </div>
        ))}
      </div>

      {!loading && !error && ideas.length > 0 && (
        <button
          onClick={onMore}
          className="w-full mt-3 py-4 rounded-2xl bg-secondary hover:bg-muted border-2 border-border text-foreground font-bold min-h-[56px]"
        >
          {t('mealMoreIdeas')}
        </button>
      )}

      <p className="mt-3 text-muted-foreground font-semibold">{t('mealIdeasDisclaimer')}</p>
    </div>
  );
}