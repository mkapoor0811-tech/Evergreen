import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAppSettings } from '@/lib/AppSettings';
import { Utensils, Check, Heart } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';
import { todayLocal, localDate } from '@/lib/localDate';

const todayStr = todayLocal;

const OPTIONS = [
  { key: 'good', labelKey: 'appetiteGood', tone: 'bg-earth-sage border-earth-sage' },
  { key: 'less', labelKey: 'appetiteLess', tone: 'bg-earth-marigold border-earth-marigold' },
  { key: 'veryLittle', labelKey: 'appetiteVeryLittle', tone: 'bg-earth-terracotta border-earth-terracotta' },
];

export default function AppetiteTracker() {
  const { t } = useAppSettings();
  const look = useSectionLook();
  const [entry, setEntry] = useState(null);
  const [recent, setRecent] = useState([]);
  const [saved, setSaved] = useState(false);

  const load = async () => {
    const since = new Date();
    since.setDate(since.getDate() - 4);
    const page = await base44.entities.AppetiteLog.filter(
      { date: { $gte: localDate(since) } },
      { sort: '-date', limit: 10 },
    );
    const items = page.items || [];
    setRecent(items);
    setEntry(items.find((l) => l.date === todayStr()) || null);
  };

  useEffect(() => { load(); }, []);

  const choose = async (level) => {
    if (entry) {
      await base44.entities.AppetiteLog.update(entry.id, { level });
    } else {
      await base44.entities.AppetiteLog.create({ date: todayStr(), level });
    }
    setSaved(true);
    load();
  };

  const lowDays = recent.filter((l) => l.level !== 'good').length;

  return (
    <div className="mb-6 rounded-3xl bg-card border-2 border-border overflow-hidden">
      <div className={`${look.bar} px-5 py-3 flex items-center gap-3`}>
        <Utensils className="w-6 h-6 text-white" strokeWidth={2.5} />
        <h2 className="font-heading text-xl text-white">{t('appetiteTitle')}</h2>
      </div>

      <div className="p-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {OPTIONS.map((option) => {
            const active = entry && entry.level === option.key;
            return (
              <button
                key={option.key}
                onClick={() => choose(option.key)}
                className={`flex items-center justify-center gap-2 px-4 py-4 rounded-2xl border-2 font-bold transition min-h-[56px] ${
                  active ? `${option.tone} text-white` : 'bg-secondary border-border text-foreground hover:border-earth-terracotta'
                }`}
              >
                {active && <Check className="w-6 h-6" strokeWidth={3} />}
                {t(option.labelKey)}
              </button>
            );
          })}
        </div>

        {saved && (
          <p className="mt-4 flex items-center gap-2 text-earth-sageDark font-bold">
            <Check className="w-5 h-5" strokeWidth={3} />
            {t('appetiteSaved')}
          </p>
        )}

        {lowDays >= 3 && (
          <p className="mt-4 p-4 rounded-2xl bg-earth-terracotta/10 border-2 border-earth-terracotta/40 text-foreground flex items-start gap-3">
            <Heart className="w-6 h-6 shrink-0 mt-0.5 text-earth-terracotta" strokeWidth={2.5} />
            <span>{t('appetiteLowNote')}</span>
          </p>
        )}
      </div>
    </div>
  );
}