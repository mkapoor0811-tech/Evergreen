import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Info } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

const RATING_KEYS = { good: 'feelGood', okay: 'feltOkay', not_great: 'feelNotGreat', bad: 'feelPoor' };
const RATING_STYLE = {
  good: 'bg-earth-sage/20 text-earth-sageDark',
  okay: 'bg-earth-marigold/25 text-earth-marigoldDark',
  not_great: 'bg-earth-plum/15 text-earth-plum',
  bad: 'bg-earth-terracotta/15 text-earth-terracottaDark',
};

export default function FeelHistory({ doseLogs, limit = 12 }) {
  const { t, language } = useAppSettings();
  const look = useSectionLook();
  const locale = LOCALES[language] || 'en-US';

  const entries = (doseLogs || [])
    .filter((l) => l.rating || l.note || (l.symptoms || []).length)
    .slice()
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0))
    .slice(0, limit);

  const symptomCounts = {};
  entries.forEach((l) => (l.symptoms || []).forEach((s) => { symptomCounts[s] = (symptomCounts[s] || 0) + 1; }));
  const patterns = Object.entries(symptomCounts).sort((a, b) => b[1] - a[1]);

  const fmtDate = (d) => new Date(`${d}T00:00:00`).toLocaleDateString(locale, { month: 'short', day: 'numeric' });

  return (
    <section className="mb-6 rounded-3xl bg-card border border-border overflow-hidden">
      <div className={`${look.bar} px-5 py-2.5`}>
        <h2 className="font-heading text-xl text-white">{t('feelLog')}</h2>
      </div>
      <div className="p-5">
        <p className="text-muted-foreground mb-4">{t('feelLogHelp')}</p>

        {entries.length === 0 ? (
          <p className="text-muted-foreground">{t('feelLogEmpty')}</p>
        ) : (
          <>
            {patterns.length > 0 && (
              <div className="mb-5">
                <p className="font-bold text-foreground mb-2">{t('patterns')}</p>
                <div className="flex flex-wrap gap-2">
                  {patterns.map(([key, count]) => (
                    <span key={key} className="rounded-full bg-secondary px-4 py-1.5 font-semibold text-foreground">
                      {t(key)} · {count}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <ul className="space-y-3">
              {entries.map((log) => (
                <li key={log.id} className="rounded-2xl bg-secondary/50 p-4">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="font-bold text-foreground">{fmtDate(log.date)}</span>
                    <span className="text-muted-foreground">·</span>
                    <span className="text-muted-foreground truncate">{log.medication_name}</span>
                    {log.rating && (
                      <span className={`rounded-full px-3 py-0.5 text-sm font-bold ${RATING_STYLE[log.rating] || ''}`}>
                        {t(RATING_KEYS[log.rating])}
                      </span>
                    )}
                  </div>
                  {(log.symptoms || []).length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-1">
                      {log.symptoms.map((key) => (
                        <span key={key} className="rounded-full bg-card border border-border px-3 py-0.5 text-sm text-foreground">
                          {t(key)}
                        </span>
                      ))}
                    </div>
                  )}
                  {log.note && <p className="text-foreground">{log.note}</p>}
                </li>
              ))}
            </ul>
          </>
        )}

        <p className="flex items-start gap-2 text-sm text-muted-foreground mt-4">
          <Info className="w-4 h-4 shrink-0 mt-0.5" />
          {t('checkWithPharmacist')}
        </p>
      </div>
    </section>
  );
}