import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { INSTRUCTION_OPTIONS, INSTRUCTION_KEYS } from '@/lib/medInstructions';
import { checkInteractions } from '@/lib/medInteractions';
import InteractionWarning from '@/components/InteractionWarning';

const INPUT = 'w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none text-lg';
const LABEL = 'block font-bold text-foreground mb-1';

export default function MedicationForm({ form, setForm, onSubmit, onCancel, meds, editing }) {
  const { t } = useAppSettings();
  const instructions = Array.isArray(form.instructions) ? form.instructions : [];

  const toggleInstruction = (key) => {
    setForm({
      ...form,
      instructions: instructions.includes(key) ? instructions.filter((k) => k !== key) : [...instructions, key],
    });
  };

  const others = (meds || []).filter((m) => m.id !== editing);

  return (
    <div className="mb-5 p-5 bg-card rounded-3xl border border-border space-y-4">
      <div>
        <label className={LABEL}>{t('medicationName')}</label>
        <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={INPUT} />
        {form.name.trim() && (
          <div className="mt-3">
            <InteractionWarning interactions={checkInteractions(form.name, others)} />
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className={LABEL}>{t('dosage')}</label>
          <input
            value={form.dosage}
            onChange={(e) => setForm({ ...form, dosage: e.target.value })}
            placeholder="e.g. 10mg"
            className={INPUT}
          />
        </div>
        <div>
          <label className={LABEL}>{t('time')}</label>
          <input
            type="time"
            value={form.time}
            onChange={(e) => setForm({ ...form, time: e.target.value })}
            className={INPUT}
          />
        </div>
      </div>

      <div>
        <label className={LABEL}>{t('howToTake')}</label>
        <div className="flex flex-wrap gap-2">
          {INSTRUCTION_OPTIONS.map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => toggleInstruction(key)}
              className={`px-4 py-2.5 rounded-full border-2 font-semibold transition ${
                instructions.includes(key)
                  ? 'bg-earth-lagoon text-white border-earth-lagoon'
                  : 'bg-card border-border text-foreground hover:border-earth-lagoon'
              }`}
            >
              {t(INSTRUCTION_KEYS[key])}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className={LABEL}>{t('notes')}</label>
        <textarea
          value={form.notes || ''}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
          rows={2}
          className={`${INPUT} resize-none`}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className={LABEL}>{t('pillsRemaining')}</label>
          <input
            type="number"
            min="0"
            value={form.pill_count}
            onChange={(e) => setForm({ ...form, pill_count: e.target.value })}
            placeholder="e.g. 30"
            className={INPUT}
          />
        </div>
        <div>
          <label className={LABEL}>{t('refillAt')}</label>
          <input
            type="number"
            min="0"
            value={form.refill_threshold}
            onChange={(e) => setForm({ ...form, refill_threshold: e.target.value })}
            className={INPUT}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className={LABEL}>{t('pharmacyName')}</label>
          <input
            value={form.pharmacy_name}
            onChange={(e) => setForm({ ...form, pharmacy_name: e.target.value })}
            className={INPUT}
          />
        </div>
        <div>
          <label className={LABEL}>{t('pharmacyPhone')}</label>
          <input
            type="tel"
            value={form.pharmacy_phone}
            onChange={(e) => setForm({ ...form, pharmacy_phone: e.target.value })}
            className={INPUT}
          />
        </div>
        <div>
          <label className={LABEL}>{t('prescribingDoctor')}</label>
          <input
            value={form.doctor_name}
            onChange={(e) => setForm({ ...form, doctor_name: e.target.value })}
            className={INPUT}
          />
        </div>
        <div>
          <label className={LABEL}>{t('doctorPhone')}</label>
          <input
            type="tel"
            value={form.doctor_phone}
            onChange={(e) => setForm({ ...form, doctor_phone: e.target.value })}
            className={INPUT}
          />
        </div>
      </div>

      <div className="flex gap-3">
        <button
          onClick={onSubmit}
          className="flex-1 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-4 rounded-xl transition min-h-[56px]"
        >
          {t('save')}
        </button>
        {onCancel && (
          <button
            onClick={onCancel}
            className="px-6 rounded-xl border-2 border-border font-bold text-foreground min-h-[56px]"
          >
            {t('cancel')}
          </button>
        )}
      </div>
    </div>
  );
}