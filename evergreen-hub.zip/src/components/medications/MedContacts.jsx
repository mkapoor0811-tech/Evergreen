import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { sendToCaregivers } from '@/lib/caregiverAlerts';
import { Phone, RefreshCw, Loader2, Check, AlertTriangle, Info } from 'lucide-react';

export default function MedContacts({ med }) {
  const { t } = useAppSettings();
  const [state, setState] = useState('idle');
  const [failed, setFailed] = useState(false);

  const rows = [];
  if (med.pharmacy_name || med.pharmacy_phone) {
    rows.push({ key: 'pharmacy', label: t('pharmacy'), name: med.pharmacy_name, phone: med.pharmacy_phone });
  }
  if (med.doctor_name || med.doctor_phone) {
    rows.push({ key: 'doctor', label: t('prescribingDoctor'), name: med.doctor_name, phone: med.doctor_phone });
  }

  if (rows.length === 0) return null;

  const requestRefill = async () => {
    setState('sending');
    const res = await sendToCaregivers({
      subject: `${t('requestRefill')} — ${med.name}`,
      heading: t('refillEmailHeading'),
      intro: t('refillEmailIntro'),
      lines: [
        `<strong>${med.name}</strong> — ${med.dosage || ''}`,
        med.pharmacy_name || med.pharmacy_phone
          ? `${t('pharmacy')}: ${med.pharmacy_name || ''} ${med.pharmacy_phone || ''}`.trim()
          : null,
        med.pill_count != null ? `${t('pillsRemaining')}: ${med.pill_count}` : null,
      ].filter(Boolean),
      footer: t('refillEmailFooter'),
    });
    setState('sent');
    setFailed(res.sent === 0);
  };

  return (
    <div className="mt-4 space-y-2">
      {rows.map(({ key, label, name, phone }) => {
        const content = (
          <>
            <Phone className="w-5 h-5 text-earth-lagoon shrink-0" strokeWidth={2.25} />
            <span className="flex-1 min-w-0 text-foreground truncate">
              {label}{name ? ` · ${name}` : ''}
            </span>
            {phone && <span className="font-bold text-earth-lagoonDark shrink-0">{phone}</span>}
          </>
        );
        return phone ? (
          <a
            key={key}
            href={`tel:${phone}`}
            className="flex items-center gap-3 rounded-xl bg-secondary/60 hover:bg-secondary px-4 py-3 transition"
          >
            {content}
          </a>
        ) : (
          <div key={key} className="flex items-center gap-3 rounded-xl bg-secondary/40 px-4 py-3">
            {content}
          </div>
        );
      })}

      <button
        onClick={requestRefill}
        disabled={state === 'sending'}
        className={`inline-flex items-center gap-2 px-4 py-3 rounded-xl font-bold transition disabled:opacity-60 ${
          state === 'sent'
            ? failed ? 'bg-destructive/10 text-destructive' : 'bg-earth-sage/20 text-earth-sageDark'
            : 'bg-earth-marigold/20 text-earth-marigoldDark hover:bg-earth-marigold/30'
        }`}
      >
        {state === 'sending' ? <Loader2 className="w-5 h-5 animate-spin" />
          : state === 'sent' ? (failed ? <AlertTriangle className="w-5 h-5" /> : <Check className="w-5 h-5" strokeWidth={3} />)
          : <RefreshCw className="w-5 h-5" strokeWidth={2.25} />}
        {state === 'sent' ? (failed ? t('refillFailed') : t('refillRequested')) : t('requestRefill')}
      </button>

      <p className="flex items-start gap-2 text-sm text-muted-foreground">
        <Info className="w-4 h-4 shrink-0 mt-0.5" />
        {t('checkWithPharmacist')}
      </p>
    </div>
  );
}