import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { formatTime12 } from '@/lib/timeFormat';
import { Check, Pill } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

/** The one big card on the Medications screen: the next pill and a single "I took it" action. */
export default function NextPillCard({ med, onTake }) {
  const { t, language } = useAppSettings();
  const look = useSectionLook();
  const locale = LOCALES[language] || 'en-US';

  if (!med) {
    return (
      <section className="mb-6 rounded-3xl bg-earth-sage/15 border-2 border-earth-sage/50 p-6">
        <p className="text-2xl font-heading text-earth-sageDark text-center leading-snug">{t('allPillsDone')}</p>
      </section>
    );
  }

  return (
    <section className="mb-6 rounded-3xl bg-card border-2 border-earth-terracotta/50 overflow-hidden">
      <div className={`${look.bar} px-6 py-3`}>
        <h2 className="font-heading text-2xl text-white">{t('nextPill')}</h2>
      </div>

      <div className="p-6">
        <div className="flex items-center gap-4 mb-5">
          <span className="w-16 h-16 blob bg-earth-terracotta/15 text-earth-terracotta flex items-center justify-center shrink-0">
            <Pill className="w-9 h-9" strokeWidth={2.25} />
          </span>
          <div className="min-w-0">
            <p className="font-heading text-3xl text-foreground leading-tight">{med.name}</p>
            <p className="text-2xl text-muted-foreground">{formatTime12(med.time, locale)}</p>
          </div>
        </div>

        <button
          onClick={() => onTake(med)}
          className="w-full flex items-center justify-center gap-3 bg-earth-sage hover:bg-earth-sageDark text-white font-bold py-6 rounded-2xl transition min-h-[76px] text-2xl"
        >
          <Check className="w-9 h-9" strokeWidth={3} />
          {t('iTookIt')}
        </button>
      </div>
    </section>
  );
}