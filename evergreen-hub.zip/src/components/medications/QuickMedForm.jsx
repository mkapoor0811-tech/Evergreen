import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';

const INPUT = 'w-full px-4 py-4 rounded-xl border-2 border-border bg-card focus:border-earth-terracotta outline-none text-xl';
const LABEL = 'block font-bold text-foreground mb-2 text-lg';

/** The three-field form for adding a pill: name, time, notes. */
export default function QuickMedForm({ form, setForm, onSubmit, onCancel }) {
  const { t } = useAppSettings();

  return (
    <div className="mb-6 p-5 bg-card rounded-3xl border-2 border-border space-y-5">
      <div>
        <label className={LABEL}>{t('pillName')}</label>
        <input
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className={INPUT}
        />
      </div>

      <div>
        <label className={LABEL}>{t('time')}</label>
        <input
          type="time"
          value={form.time}
          onChange={(e) => setForm({ ...form, time: e.target.value })}
          className={INPUT}
        />
      </div>

      <div>
        <label className={LABEL}>{t('notes')}</label>
        <textarea
          value={form.notes}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
          rows={2}
          className={`${INPUT} resize-none`}
        />
      </div>

      <div className="flex gap-3">
        <button
          onClick={onSubmit}
          disabled={!form.name.trim()}
          className="flex-1 bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold py-4 rounded-xl transition disabled:opacity-40 min-h-[60px]"
        >
          {t('save')}
        </button>
        <button
          onClick={onCancel}
          className="px-6 rounded-xl border-2 border-border font-bold text-foreground min-h-[60px]"
        >
          {t('cancel')}
        </button>
      </div>
    </div>
  );
}