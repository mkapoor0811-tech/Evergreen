import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Pill, AlertTriangle, RefreshCw, Trash2, Pencil, Check, SkipForward } from 'lucide-react';
import { INSTRUCTION_KEYS } from '@/lib/medInstructions';
import MedContacts from '@/components/medications/MedContacts';
import { LOCALES, formatTime12 } from '@/lib/timeFormat';

export default function MedicationCard({ med, isTaken, isOverdue, isLow, isSkipped, onToggle, onSkip, onEdit, onRefill, onDelete }) {
  const { t, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';
  const instructions = (med.instructions || []).map((key) => INSTRUCTION_KEYS[key]).filter(Boolean);

  const cardTone = isTaken
    ? 'bg-earth-sage/12 border-earth-sage/50'
    : isSkipped
      ? 'bg-earth-plum/10 border-earth-plum/40'
      : isOverdue
        ? 'bg-earth-terracotta/10 border-earth-terracotta/40'
        : 'bg-card border-border';

  return (
    <div className={`p-5 rounded-3xl border ${cardTone}`}>
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 blob bg-earth-terracotta/15 text-earth-terracotta flex items-center justify-center shrink-0">
          <Pill className="w-7 h-7" strokeWidth={2.25} />
        </div>

        <div className="flex-1 min-w-0">
          <p className="font-heading text-lg text-foreground">{med.name}</p>
          <p className="text-muted-foreground">{med.dosage} • {formatTime12(med.time, locale)}</p>

          {instructions.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {instructions.map((key) => (
                <span key={key} className="rounded-full bg-earth-lagoon/12 text-earth-lagoonDark px-3 py-1 text-sm font-semibold">
                  {t(key)}
                </span>
              ))}
            </div>
          )}

          <div className="flex flex-wrap gap-2 mt-2">
            {isSkipped && (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-earth-plum/15 text-earth-plum font-bold text-sm">
                <SkipForward className="w-4 h-4" /> {t('organizerSkipped')}
              </span>
            )}
            {isOverdue && !isSkipped && (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-earth-terracotta/15 text-earth-terracottaDark font-bold text-sm">
                <AlertTriangle className="w-4 h-4" /> {t('overdue')}
              </span>
            )}
            {isLow && (
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-earth-marigold/25 text-earth-marigoldDark font-bold text-sm">
                <AlertTriangle className="w-4 h-4" /> {t('refillSoon')}
              </span>
            )}
          </div>

          {med.pill_count != null && (
            <p className="text-muted-foreground mt-2">{t('pillsRemaining')}: {med.pill_count}</p>
          )}
        </div>

        <button
          onClick={() => onToggle(med)}
          className={`flex items-center gap-2 px-5 py-4 rounded-2xl font-bold transition min-h-[56px] shrink-0 ${
            isTaken ? 'bg-earth-sage text-white' : 'bg-secondary hover:bg-muted text-foreground'
          }`}
        >
          {isTaken ? <Check className="w-6 h-6" strokeWidth={3} /> : null}
          {isTaken ? t('done') : t('markTaken')}
        </button>
      </div>

      <MedContacts med={med} />

      <div className="mt-3 flex flex-wrap items-center gap-2">
        {!isTaken && !isSkipped && (
          <button
            onClick={() => onSkip(med)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition"
          >
            <SkipForward className="w-5 h-5" strokeWidth={2.25} />
            {t('markSkipped')}
          </button>
        )}
        <button
          onClick={() => onEdit(med)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition"
        >
          <Pencil className="w-5 h-5" strokeWidth={2.25} />
          {t('edit')}
        </button>
        <button
          onClick={() => onRefill(med)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition"
        >
          <RefreshCw className="w-5 h-5" strokeWidth={2.25} />
          {t('refill')}
        </button>
        <button
          onClick={() => onDelete(med.id)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-destructive hover:bg-destructive/10 font-bold transition ml-auto"
        >
          <Trash2 className="w-5 h-5" strokeWidth={2.25} />
          {t('delete')}
        </button>
      </div>
    </div>
  );
}