import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { SLOTS, SLOT_EMOJI, weekDates, slotForTime, isPastDue, iso } from '@/lib/medSchedule';
import { Info } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

const STATUS_STYLE = {
  taken: { dot: 'bg-earth-sage', text: 'text-earth-sageDark', labelKey: 'organizerTaken' },
  skipped: { dot: 'bg-earth-plum', text: 'text-earth-plum', labelKey: 'organizerSkipped' },
  missed: { dot: 'bg-earth-terracotta', text: 'text-earth-terracottaDark', labelKey: 'organizerMissed' },
  due: { dot: 'bg-border', text: 'text-muted-foreground', labelKey: 'organizerDue' },
};

export default function PillOrganizer({ meds, doseLogs }) {
  const { t, language } = useAppSettings();
  const look = useSectionLook();
  const locale = LOCALES[language] || 'en-US';
  const now = new Date();
  const today = iso(now);
  const week = weekDates();

  const statusFor = (med, date, slot) => {
    const log = (doseLogs || []).find(
      (l) => l.medication_id === med.id && l.date === date && l.slot === slot,
    );
    if (log) return log.status;
    return isPastDue(date, med.time, now) ? 'missed' : 'due';
  };

  const dayLabel = (date) => {
    const d = new Date(`${date}T00:00:00`);
    return {
      weekday: d.toLocaleDateString(locale, { weekday: 'narrow' }),
      day: d.getDate(),
    };
  };

  return (
    <section className="mb-6 rounded-3xl bg-card border border-border overflow-hidden">
      <div className={`${look.bar} px-5 py-2.5`}>
        <h2 className="font-heading text-xl text-white">{t('pillOrganizer')}</h2>
      </div>
      <div className="p-5">
        <p className="text-muted-foreground mb-4">{t('pillOrganizerHelp')}</p>

        <div className="overflow-x-auto">
          <div className="min-w-[620px]">
            <div className="grid grid-cols-8 gap-1.5 mb-1.5">
              <span />
              {week.map((date) => {
                const { weekday, day } = dayLabel(date);
                return (
                  <span
                    key={date}
                    className={`text-center text-xs font-bold rounded-lg py-1 ${
                      date === today ? 'bg-earth-marigold/25 text-earth-marigoldDark' : 'text-muted-foreground'
                    }`}
                  >
                    {weekday} {day}
                  </span>
                );
              })}
            </div>

            {SLOTS.map((slot) => (
              <div key={slot} className="grid grid-cols-8 gap-1.5 mb-1.5">
                <span className="flex items-center gap-1 text-sm font-bold text-foreground">
                  <span aria-hidden="true">{SLOT_EMOJI[slot]}</span>
                  <span className="truncate">{t(slot)}</span>
                </span>
                {week.map((date) => {
                  const due = (meds || []).filter((m) => slotForTime(m.time) === slot);
                  return (
                    <div
                      key={date}
                      className={`rounded-xl border p-1.5 min-h-[56px] ${
                        date === today ? 'border-earth-marigold bg-earth-marigold/10' : 'border-border bg-secondary/40'
                      }`}
                    >
                      {due.length === 0 ? (
                        <span className="block text-center text-xs text-muted-foreground">—</span>
                      ) : (
                        due.map((med) => {
                          const status = statusFor(med, date, slot);
                          const style = STATUS_STYLE[status] || STATUS_STYLE.due;
                          return (
                            <span key={med.id} className="flex items-center gap-1 mb-0.5" title={`${med.name} — ${t(style.labelKey)}`}>
                              <span className={`w-2 h-2 rounded-full shrink-0 ${style.dot}`} />
                              <span className={`text-xs truncate ${style.text}`}>{med.name}</span>
                            </span>
                          );
                        })
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 mt-4 text-sm">
          {[
            { key: 'organizerTaken', style: STATUS_STYLE.taken },
            { key: 'organizerMissed', style: STATUS_STYLE.missed },
            { key: 'organizerSkipped', style: STATUS_STYLE.skipped },
            { key: 'organizerDue', style: STATUS_STYLE.due },
          ].map(({ key, style }) => (
            <span key={key} className="flex items-center gap-2 text-muted-foreground">
              <span className={`w-3.5 h-3.5 rounded-full ${style.dot}`} />
              {t(key)}
            </span>
          ))}
        </div>

        <p className="flex items-start gap-2 text-sm text-muted-foreground mt-4">
          <Info className="w-4 h-4 shrink-0 mt-0.5" />
          {t('checkWithPharmacist')}
        </p>
      </div>
    </section>
  );
}