import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { formatTime12 } from '@/lib/timeFormat';
import { Check, ChevronDown } from 'lucide-react';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

/** One pill in today's list: name, time, a big tick, and a small "More" for everything else. */
export default function TodayPillRow({ med, taken, skipped, overdue, open, onToggleTaken, onToggleMore, children }) {
  const { t, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';

  return (
    <div className={`rounded-2xl border-2 overflow-hidden ${taken ? 'border-earth-sage/60 bg-earth-sage/15' : 'border-border bg-card'}`}>
      <div className="flex items-stretch">
        <button
          type="button"
          onClick={() => onToggleTaken(med)}
          className="flex-1 flex items-center gap-4 p-5 text-left min-h-[88px]"
        >
          <span className={`w-12 h-12 rounded-xl border-2 flex items-center justify-center shrink-0 ${taken ? 'bg-earth-sage border-earth-sage' : 'border-border bg-card'}`}>
            {taken && <Check className="w-7 h-7 text-white" strokeWidth={3} />}
          </span>
          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <span className="font-heading text-2xl text-foreground leading-tight">{med.name}</span>
              {taken && (
                <span className="rounded-full bg-earth-sage text-white text-sm font-bold px-3 py-1">{t('takenTag')}</span>
              )}
              {!taken && skipped && (
                <span className="rounded-full bg-earth-plum text-white text-sm font-bold px-3 py-1">{t('organizerSkipped')}</span>
              )}
              {!taken && !skipped && overdue && (
                <span className="rounded-full bg-earth-terracotta text-white text-sm font-bold px-3 py-1">{t('overdue')}</span>
              )}
            </span>
            <span className="block text-xl text-muted-foreground">{formatTime12(med.time, locale)}</span>
          </span>
        </button>

        <button
          type="button"
          onClick={() => onToggleMore(med)}
          className="self-center mr-4 flex items-center gap-1 px-4 py-3 rounded-xl bg-secondary hover:bg-muted text-foreground font-bold transition min-h-[56px] shrink-0"
        >
          {t('more')}
          <ChevronDown className={`w-5 h-5 transition ${open ? 'rotate-180' : ''}`} strokeWidth={2.5} />
        </button>
      </div>

      {open && <div className="border-t-2 border-border p-5 bg-earth-cream/70">{children}</div>}
    </div>
  );
}