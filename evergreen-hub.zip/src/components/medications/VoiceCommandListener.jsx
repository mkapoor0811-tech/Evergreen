import React, { useEffect, useRef, useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { Mic, MicOff } from 'lucide-react';

const LANGS = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };

export default function VoiceCommandListener({ onCommand }) {
  const { t, language } = useAppSettings();
  const [listening, setListening] = useState(false);
  const [error, setError] = useState('');
  const activeRef = useRef(false);
  const onCommandRef = useRef(onCommand);
  onCommandRef.current = onCommand;

  useEffect(() => {
    if (!listening) return;

    const SR = typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition);
    if (!SR) {
      setError('notSupported');
      setListening(false);
      return;
    }

    const rec = new SR();
    rec.lang = LANGS[language] || 'en-US';
    rec.continuous = true;
    rec.interimResults = false;

    rec.onresult = (e) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) {
          onCommandRef.current(e.results[i][0].transcript);
        }
      }
    };
    rec.onerror = (e) => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        setError('notAllowed');
        activeRef.current = false;
        setListening(false);
      }
    };
    rec.onend = () => {
      if (activeRef.current) {
        try { rec.start(); } catch { /* restart failed; stop quietly */ }
      }
    };

    activeRef.current = true;
    try {
      rec.start();
    } catch {
      setError('error');
      activeRef.current = false;
      setListening(false);
    }

    return () => {
      activeRef.current = false;
      try { rec.abort(); } catch { /* noop */ }
    };
  }, [listening, language]);

  return (
    <div className={`p-5 rounded-2xl border-2 ${listening ? 'bg-green-50 border-green-300' : 'bg-card border-border'}`}>
      <button
        onClick={() => { setError(''); setListening((v) => !v); }}
        className={`w-full flex items-center justify-center gap-3 font-bold text-lg py-4 rounded-2xl transition min-h-[60px] ${
          listening ? 'bg-green-600 text-white' : 'bg-primary text-primary-foreground'
        }`}
      >
        {listening ? <Mic className="w-7 h-7 animate-pulse" strokeWidth={2.5} /> : <MicOff className="w-7 h-7" strokeWidth={2.5} />}
        {t('handsFreeTitle')}
      </button>

      <p className="mt-3 text-center text-foreground">{t('handsFreeHint')}</p>

      {error && (
        <p className="mt-2 text-center text-destructive font-semibold">
          {error === 'notSupported' ? t('voiceNotSupported')
            : error === 'notAllowed' ? t('voiceNotAllowed')
            : t('voiceError')}
        </p>
      )}
    </div>
  );
}