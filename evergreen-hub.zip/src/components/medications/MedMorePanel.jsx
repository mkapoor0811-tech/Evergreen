import React from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { formatTime12 } from '@/lib/timeFormat';
import { INSTRUCTION_KEYS } from '@/lib/medInstructions';
import MedContacts from '@/components/medications/MedContacts';
import { HeartPulse, Pencil, RefreshCw, SkipForward, Trash2 } from 'lucide-react';

const LOCALES = { en: 'en-US', es: 'es-ES', hi: 'hi-IN', zh: 'zh-CN', tl: 'fil-PH', vi: 'vi-VN' };
const ACTION = 'inline-flex items-center gap-2 px-4 py-3 rounded-xl bg-card border-2 border-border hover:border-earth-lagoon text-foreground font-bold transition min-h-[56px]';

/** Everything about one pill that is not needed at a glance. */
export default function MedMorePanel({ med, taken, onFeel, onSkip, onRefill, onEdit, onDelete }) {
  const { t, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';
  const instructions = (med.instructions || []).map((key) => INSTRUCTION_KEYS[key]).filter(Boolean);

  return (
    <div className="space-y-5">
      <div>
        <p className="font-bold text-foreground mb-1">{t('doseNotes')}</p>
        <p className="text-lg text-foreground">
          {[med.dosage, formatTime12(med.time, locale)].filter(Boolean).join(' · ')}
        </p>
        {instructions.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {instructions.map((key) => (
              <span key={key} className="rounded-full bg-earth-lagoon/15 text-earth-lagoonDark px-3 py-1 font-semibold">
                {t(key)}
              </span>
            ))}
          </div>
        )}
        {med.notes && <p className="mt-2 text-lg text-foreground whitespace-pre-wrap">{med.notes}</p>}
        {med.pill_count != null && (
          <p className="mt-1 text-muted-foreground">{t('pillsRemaining')}: {med.pill_count}</p>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        <button onClick={() => onFeel(med)} className={ACTION}>
          <HeartPulse className="w-5 h-5" strokeWidth={2.25} />
          {t('howIFeel')}
        </button>
        {!taken && (
          <button onClick={() => onSkip(med)} className={ACTION}>
            <SkipForward className="w-5 h-5" strokeWidth={2.25} />
            {t('markSkipped')}
          </button>
        )}
        <button onClick={() => onRefill(med)} className={ACTION}>
          <RefreshCw className="w-5 h-5" strokeWidth={2.25} />
          {t('refill')}
        </button>
        <button onClick={() => onEdit(med)} className={ACTION}>
          <Pencil className="w-5 h-5" strokeWidth={2.25} />
          {t('edit')}
        </button>
        <button
          onClick={() => onDelete(med.id)}
          className="inline-flex items-center gap-2 px-4 py-3 rounded-xl border-2 border-destructive/40 text-destructive hover:bg-destructive/10 font-bold transition min-h-[56px] ml-auto"
        >
          <Trash2 className="w-5 h-5" strokeWidth={2.25} />
          {t('delete')}
        </button>
      </div>

      <MedContacts med={med} />
    </div>
  );
}