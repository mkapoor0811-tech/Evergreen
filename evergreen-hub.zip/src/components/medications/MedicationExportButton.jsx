import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { generateMedicationListPDF, buildMedicationListText } from '@/lib/medicationList';
import { FileDown, Copy, Check, Loader2, Info } from 'lucide-react';
import { useSectionLook } from '@/lib/sectionColors';

export default function MedicationExportButton({ meds }) {
  const { t } = useAppSettings();
  const look = useSectionLook();
  const [state, setState] = useState('idle');
  const [copied, setCopied] = useState(false);

  const empty = !meds || meds.length === 0;

  const download = async () => {
    setState('working');
    try {
      await generateMedicationListPDF(meds, t);
      setState('done');
      setTimeout(() => setState('idle'), 3000);
    } catch (e) {
      setState('idle');
    }
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(buildMedicationListText(meds, t));
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch (e) { /* clipboard unavailable */ }
  };

  return (
    <section className="mb-6 rounded-3xl bg-card border border-border overflow-hidden">
      <div className={`${look.bar} px-5 py-2.5`}>
        <h2 className="font-heading text-xl text-white">{t('exportList')}</h2>
      </div>
      <div className="p-5">
        <p className="text-muted-foreground mb-4">{t('exportListHelp')}</p>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={download}
            disabled={empty || state === 'working'}
            className="flex-1 flex items-center justify-center gap-2 bg-earth-navy hover:bg-earth-navyDark text-white font-bold py-4 rounded-xl transition min-h-[56px] disabled:opacity-50"
          >
            {state === 'working' ? <Loader2 className="w-6 h-6 animate-spin" />
              : state === 'done' ? <Check className="w-6 h-6" strokeWidth={3} />
              : <FileDown className="w-6 h-6" strokeWidth={2.25} />}
            {state === 'working' ? t('exportGenerating') : state === 'done' ? t('exportDone') : t('exportDownload')}
          </button>
          <button
            onClick={copy}
            disabled={empty}
            className="flex-1 flex items-center justify-center gap-2 bg-secondary hover:bg-muted text-foreground font-bold py-4 rounded-xl transition min-h-[56px] disabled:opacity-50"
          >
            {copied ? <Check className="w-6 h-6" strokeWidth={3} /> : <Copy className="w-6 h-6" strokeWidth={2.25} />}
            {copied ? t('exportCopied') : t('exportCopy')}
          </button>
        </div>

        {empty && <p className="text-muted-foreground mt-3">{t('exportEmpty')}</p>}

        <p className="flex items-start gap-2 text-sm text-muted-foreground mt-4">
          <Info className="w-4 h-4 shrink-0 mt-0.5" />
          {t('checkWithPharmacist')}
        </p>
      </div>
    </section>
  );
}