import React, { useState } from 'react';
import { useAppSettings } from '@/lib/AppSettings';
import { X, Check, Info, Loader2 } from 'lucide-react';
import { LOCALES, formatTime12 } from '@/lib/timeFormat';

const RATINGS = [
  { key: 'good', labelKey: 'feelGood', cls: 'bg-earth-sage/20 border-earth-sage text-earth-sageDark' },
  { key: 'okay', labelKey: 'feltOkay', cls: 'bg-earth-marigold/20 border-earth-marigold text-earth-marigoldDark' },
  { key: 'not_great', labelKey: 'feelNotGreat', cls: 'bg-earth-plum/12 border-earth-plum text-earth-plum' },
  { key: 'bad', labelKey: 'feelPoor', cls: 'bg-earth-terracotta/15 border-earth-terracotta text-earth-terracottaDark' },
];

const SYMPTOMS = ['symptomDizziness', 'symptomNausea', 'symptomDrowsiness', 'symptomHeadache', 'symptomUpsetStomach', 'symptomOther'];

const SKIP_REASONS = ['skipForgot', 'skipUnwell', 'skipRanOut', 'skipDoctorSaid', 'skipOther'];

export default function DoseDialog({ med, mode, onClose, onSave }) {
  const { t, language } = useAppSettings();
  const locale = LOCALES[language] || 'en-US';
  const [rating, setRating] = useState(null);
  const [symptoms, setSymptoms] = useState([]);
  const [reason, setReason] = useState(null);
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const toggleSymptom = (key) => {
    setSymptoms((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  };

  const save = async () => {
    setSaving(true);
    try {
      if (mode === 'feel') {
        await onSave({ rating: rating || undefined, symptoms, note: note.trim() });
      } else {
        await onSave({ skip_reason: reason || '', note: note.trim() });
      }
    } finally {
      setSaving(false);
    }
  };

  const chip = (active) =>
    `px-4 py-2.5 rounded-full border-2 font-semibold transition ${
      active ? 'bg-earth-navy text-white border-earth-navy' : 'bg-card border-border text-foreground hover:border-earth-navy'
    }`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="bg-card rounded-3xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-start gap-4 mb-4">
          <div>
            <h3 className="font-heading text-xl text-foreground">
              {mode === 'feel' ? t('howAreYouFeeling') : t('skipDoseTitle')}
            </h3>
            <p className="text-muted-foreground">{med.name} • {med.dosage} • {formatTime12(med.time, locale)}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-secondary shrink-0">
            <X className="w-6 h-6 text-muted-foreground" />
          </button>
        </div>

        {mode === 'feel' ? (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-5">
              {RATINGS.map(({ key, labelKey, cls }) => (
                <button
                  key={key}
                  onClick={() => setRating(key)}
                  className={`py-4 rounded-2xl border-2 font-bold transition ${cls} ${
                    rating === key ? 'ring-2 ring-foreground' : ''
                  }`}
                >
                  {t(labelKey)}
                </button>
              ))}
            </div>

            <p className="font-bold text-foreground mb-2">{t('anySymptoms')}</p>
            <div className="flex flex-wrap gap-2 mb-4">
              {SYMPTOMS.map((key) => (
                <button key={key} onClick={() => toggleSymptom(key)} className={chip(symptoms.includes(key))}>
                  {t(key)}
                </button>
              ))}
            </div>

            <label className="block font-bold text-foreground mb-1">{t('symptomNote')}</label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
              className="w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none resize-none"
            />
          </>
        ) : (
          <>
            <p className="font-bold text-foreground mb-2">{t('skipReason')}</p>
            <div className="flex flex-wrap gap-2 mb-4">
              {SKIP_REASONS.map((key) => (
                <button key={key} onClick={() => setReason(key)} className={chip(reason === key)}>
                  {t(key)}
                </button>
              ))}
            </div>
            <label className="block font-bold text-foreground mb-1">{t('symptomNote')}</label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
              className="w-full px-4 py-3 rounded-xl border-2 border-border bg-card focus:border-earth-lagoon outline-none resize-none"
            />
          </>
        )}

        <p className="flex items-start gap-2 text-sm text-muted-foreground mt-4">
          <Info className="w-4 h-4 shrink-0 mt-0.5" />
          {t('checkWithPharmacist')}
        </p>

        <div className="flex gap-3 mt-4">
          <button
            onClick={onClose}
            className="flex-1 py-4 rounded-xl border-2 border-border font-bold text-foreground min-h-[56px]"
          >
            {mode === 'feel' ? t('skipThisTime') : t('cancel')}
          </button>
          <button
            onClick={save}
            disabled={saving}
            className="flex-1 flex items-center justify-center gap-2 py-4 rounded-xl bg-earth-lagoon hover:bg-earth-lagoonDark text-white font-bold disabled:opacity-50 min-h-[56px]"
          >
            {saving ? <Loader2 className="w-6 h-6 animate-spin" /> : <Check className="w-6 h-6" strokeWidth={3} />}
            {t('saveFeel')}
          </button>
        </div>
      </div>
    </div>
  );
}